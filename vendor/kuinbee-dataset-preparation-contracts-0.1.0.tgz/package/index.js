"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetPreparationsListResponseSchema = exports.DatasetPreparationResponseSchema = exports.DatasetPreparationReadinessSchema = exports.DatasetPreparationCatalogLabelsResponseSchema = exports.DatasetPreparationCatalogLabelsQuerySchema = exports.DatasetPreparationsListQuerySchema = exports.DatasetPreparationIdParamsSchema = exports.DatasetPreparationPatchBodySchema = exports.DatasetPreparationCreateBodySchema = exports.DatasetPreparationMetadataSchema = exports.DatasetPreparationSampleSchema = exports.DatasetDeclaredMeasurementSchema = exports.DatasetDeclaredUnitSchema = exports.DatasetDeclaredMetricSchema = exports.DatasetPreparationProfilesSchema = exports.DATASET_MODALITIES = exports.DATASET_UPLOAD_CHOICES = exports.DatasetContextSchema = exports.DatasetModalitySchema = exports.DatasetUploadChoiceSchema = exports.DATASET_PREPARATION_LIMITS = exports.DATASET_PREPARATION_CONTRACT_VERSION = void 0;
exports.getDatasetPreparationReadiness = getDatasetPreparationReadiness;
const zod_1 = require("zod");
// Supplier declarations only. Receipt, inspection, files, grants and business
// transitions deliberately have no writable representation in this first slice.
exports.DATASET_PREPARATION_CONTRACT_VERSION = 1;
exports.DATASET_PREPARATION_LIMITS = {
    metadataBytes: 65_536,
    draftsPerSupplier: 50,
    requestsPerDraft: 128,
};
exports.DatasetUploadChoiceSchema = zod_1.z.enum([
    "SAMPLE_ONLY", "FULL_ONLY", "FULL_AND_SAMPLE",
]);
exports.DatasetModalitySchema = zod_1.z.enum([
    "TABULAR", "AUDIO", "IMAGE", "VIDEO", "TEXT", "SENSOR",
]);
exports.DatasetContextSchema = zod_1.z.enum(["HEALTHCARE", "EGOCENTRIC"]);
exports.DATASET_UPLOAD_CHOICES = [
    { value: "SAMPLE_ONLY", label: "Sample only", help: "Upload a prepared sample and describe the collection it represents." },
    { value: "FULL_ONLY", label: "Full dataset only", help: "Upload the complete collection you describe. A sample is optional in a different upload choice." },
    { value: "FULL_AND_SAMPLE", label: "Full dataset + sample", help: "Provide the complete collection and a prepared sample for buyers to inspect." },
];
exports.DATASET_MODALITIES = [
    { value: "TABULAR", label: "Tables and spreadsheets", help: "Rows, records, sheets and related tables." },
    { value: "AUDIO", label: "Speech and other audio", help: "Conversations, music, environmental sound or other recordings." },
    { value: "IMAGE", label: "Images", help: "Photographs, frames, illustrations or other image collections." },
    { value: "VIDEO", label: "Video", help: "Clips or recordings, with or without audio." },
    { value: "TEXT", label: "Text and documents", help: "Text is the main data, rather than a transcript supporting a recording." },
    { value: "SENSOR", label: "Sensor readings", help: "Measurements and streams such as temperature, motion or device logs." },
];
const text = zod_1.z.string().trim().max(4_000).nullable().optional();
const shortText = zod_1.z.string().trim().max(500).nullable().optional();
// Existing catalog IDs are bounded opaque strings, including legacy imports.
// Validate existence/ownership on the server rather than inventing a new ID rule.
const catalogId = zod_1.z.string().min(1).max(128);
const reference = catalogId.nullable().optional();
const unique = (values) => new Set(values).size === values.length;
const languageList = zod_1.z.array(zod_1.z.string().trim().min(1).max(100)).max(30)
    .refine(unique, "Languages must be unique").optional();
const availability = zod_1.z.enum(["PRESENT", "ABSENT", "UNKNOWN"]).nullable().optional();
const DatasetStudyStructureSchema = zod_1.z.enum([
    "CROSS_SECTIONAL", "TIME_SERIES", "PANEL", "POOLED_CROSS_SECTIONAL",
    "REPEATED_CROSS_SECTIONS", "SPATIAL", "SPATIO_TEMPORAL", "EXPERIMENTAL",
    "OBSERVATIONAL", "BIG_DATA", "EVENT_HISTORY_SURVIVAL", "HIERARCHICAL_MULTILEVEL",
]);
exports.DatasetPreparationProfilesSchema = zod_1.z.object({
    tabular: zod_1.z.object({
        recordUnit: text, columnMeaningNotes: text, unitNotes: text,
        missingValueConventions: text, tableRelationshipNotes: text,
        dictionaryAvailability: availability,
    }).strict().nullable().optional(),
    audio: zod_1.z.object({
        content: zod_1.z.enum(["SPEECH", "NON_SPEECH", "MIXED", "UNKNOWN"]).nullable().optional(),
        languages: languageList, recordingContext: text,
        transcriptAvailability: availability, transcriptMeaning: text,
        annotationAvailability: availability, annotationMeaning: text,
        speakerCoverage: text, alignmentNotes: text,
    }).strict().nullable().optional(),
    images: zod_1.z.object({
        subject: text, captureContext: text, annotationAvailability: availability,
        annotationMeaning: text, classDefinitions: text, coverage: text,
    }).strict().nullable().optional(),
    video: zod_1.z.object({
        content: text, viewpoint: shortText, audioContext: text,
        annotationAvailability: availability, annotationMeaning: text, timingConvention: text,
    }).strict().nullable().optional(),
    text: zod_1.z.object({
        recordUnit: text, languages: languageList, annotationAvailability: availability,
        annotationMeaning: text, recordConvention: text,
    }).strict().nullable().optional(),
    sensors: zod_1.z.object({
        channels: zod_1.z.array(zod_1.z.object({
            name: zod_1.z.string().trim().min(1).max(200),
            meaning: text, unit: shortText,
        }).strict()).max(100).optional(),
        channelNotes: text, sessionRelationships: text, timestampMeaning: text,
        timeOrigin: text,
        synchronization: zod_1.z.enum(["NO_CLAIM", "DESCRIBED", "UNKNOWN"]).nullable().optional(),
        synchronizationNotes: text, calibrationAvailability: availability,
        calibrationMeaning: text, coordinateConventions: text,
    }).strict().nullable().optional(),
    egocentric: zod_1.z.object({
        mounting: shortText, activities: text, environment: text, additionalStreams: text,
    }).strict().nullable().optional(),
    healthcare: zod_1.z.object({
        recordMeaning: text, setting: text, identifierHandling: text, participantCoverage: text,
    }).strict().nullable().optional(),
}).strict();
exports.DatasetDeclaredMetricSchema = zod_1.z.enum([
    "RECORD_COUNT", "ROW_COUNT", "COLUMN_COUNT", "AUDIO_DURATION", "IMAGE_COUNT",
    "VIDEO_DURATION", "DOCUMENT_COUNT", "SESSION_COUNT", "PARTICIPANT_COUNT",
    "STREAM_COUNT", "BYTE_SIZE",
]);
exports.DatasetDeclaredUnitSchema = zod_1.z.enum(["COUNT", "SECOND", "MINUTE", "HOUR", "BYTE"]);
const measurementBase = {
    metric: exports.DatasetDeclaredMetricSchema,
    unit: exports.DatasetDeclaredUnitSchema,
};
exports.DatasetDeclaredMeasurementSchema = zod_1.z.discriminatedUnion("state", [
    zod_1.z.object({ ...measurementBase, state: zod_1.z.literal("UNKNOWN") }).strict(),
    zod_1.z.object({
        ...measurementBase, state: zod_1.z.enum(["KNOWN", "ESTIMATED"]),
        value: zod_1.z.string().regex(/^(0|[1-9]\d{0,14})(\.\d{1,6})?$/, "Use a nonnegative decimal value"),
    }).strict(),
]).superRefine((measurement, ctx) => {
    const duration = measurement.metric === "AUDIO_DURATION" || measurement.metric === "VIDEO_DURATION";
    const allowedUnits = duration ? ["SECOND", "MINUTE", "HOUR"]
        : measurement.metric === "BYTE_SIZE" ? ["BYTE"] : ["COUNT"];
    if (!allowedUnits.includes(measurement.unit)) {
        ctx.addIssue({ code: "custom", path: ["unit"], message: "Unit does not match the quantity" });
    }
    if (!duration && measurement.state !== "UNKNOWN" && measurement.value.includes(".")) {
        ctx.addIssue({ code: "custom", path: ["value"], message: "Counts and byte quantities must be integers" });
    }
});
exports.DatasetPreparationSampleSchema = zod_1.z.object({
    selectionMethod: text, coverage: text,
    omissions: zod_1.z.enum(["DESCRIBED", "NONE_KNOWN", "UNKNOWN"]).nullable().optional(),
    omissionNotes: text,
    transformations: zod_1.z.enum(["NONE_DECLARED", "DESCRIBED", "UNKNOWN"]).nullable().optional(),
    transformationNotes: text, relationshipNotes: text,
}).strict();
const declaredMeasurements = zod_1.z.array(exports.DatasetDeclaredMeasurementSchema).max(12)
    .refine((values) => unique(values.map((value) => value.metric)), "Declare each quantity once within its scope");
exports.DatasetPreparationMetadataSchema = zod_1.z.object({
    title: zod_1.z.string().trim().min(1).max(200),
    uploadChoice: exports.DatasetUploadChoiceSchema.nullable().optional(),
    primaryCategoryId: reference, sourceId: reference,
    license: zod_1.z.string().trim().min(1).max(1_000).nullable().optional(),
    modalities: zod_1.z.array(exports.DatasetModalitySchema).max(6).refine(unique, "Data types must be unique").optional(),
    contexts: zod_1.z.array(exports.DatasetContextSchema).max(2).refine(unique, "Contexts must be unique").optional(),
    superType: DatasetStudyStructureSchema.nullable().optional(),
    collectionBoundary: text, overview: text, description: text,
    dataQuality: text, limitations: text, collectionMethod: text, possibleUses: text,
    tags: zod_1.z.array(zod_1.z.string().trim().min(1).max(80)).max(20).refine(unique, "Tags must be unique").optional(),
    secondaryCategoryIds: zod_1.z.array(catalogId).max(10).refine(unique, "Categories must be unique").optional(),
    collectionMeasurements: declaredMeasurements.optional(),
    fullMeasurements: declaredMeasurements.optional(),
    sampleMeasurements: declaredMeasurements.optional(),
    sample: exports.DatasetPreparationSampleSchema.nullable().optional(),
    fullCompleteness: zod_1.z.boolean().nullable().optional(),
    profiles: exports.DatasetPreparationProfilesSchema.nullable().optional(),
}).strict();
const requestId = zod_1.z.string().uuid().transform((value) => value.toLowerCase());
exports.DatasetPreparationCreateBodySchema = zod_1.z.object({
    requestId, metadata: exports.DatasetPreparationMetadataSchema,
}).strict();
exports.DatasetPreparationPatchBodySchema = zod_1.z.object({
    requestId, expectedGeneration: zod_1.z.number().int().min(0).max(Number.MAX_SAFE_INTEGER),
    changes: exports.DatasetPreparationMetadataSchema.partial().refine((changes) => Object.keys(changes).length > 0, "Provide at least one change"),
}).strict();
exports.DatasetPreparationIdParamsSchema = zod_1.z.object({ draftId: zod_1.z.string().cuid() }).strict();
exports.DatasetPreparationsListQuerySchema = zod_1.z.object({
    page: zod_1.z.coerce.number().int().min(1).max(10_000).default(1),
    limit: zod_1.z.coerce.number().int().min(1).max(50).default(20),
    q: zod_1.z.string().trim().min(1).max(200).optional(),
}).strict();
exports.DatasetPreparationCatalogLabelsQuerySchema = zod_1.z.object({
    primaryCategoryId: catalogId.optional(), sourceId: catalogId.optional(),
}).strict().refine((query) => Boolean(query.primaryCategoryId || query.sourceId), "Choose a category or source to look up");
const catalogLabel = zod_1.z.object({ id: catalogId, name: zod_1.z.string().min(1).max(1_000) }).strict();
exports.DatasetPreparationCatalogLabelsResponseSchema = zod_1.z.object({
    primaryCategory: catalogLabel.nullable(), source: catalogLabel.nullable(),
}).strict();
exports.DatasetPreparationReadinessSchema = zod_1.z.object({
    canSubmit: zod_1.z.literal(false),
    issues: zod_1.z.array(zod_1.z.object({ code: zod_1.z.string().min(1), field: zod_1.z.string().optional(), message: zod_1.z.string().min(1) }).strict()).max(100),
}).strict();
exports.DatasetPreparationResponseSchema = zod_1.z.object({
    contractVersion: zod_1.z.literal(exports.DATASET_PREPARATION_CONTRACT_VERSION), id: zod_1.z.string().cuid(),
    generation: zod_1.z.number().int().min(0).max(Number.MAX_SAFE_INTEGER),
    metadata: exports.DatasetPreparationMetadataSchema,
    createdAt: zod_1.z.string().datetime(), updatedAt: zod_1.z.string().datetime(),
    readiness: exports.DatasetPreparationReadinessSchema,
}).strict();
exports.DatasetPreparationsListResponseSchema = zod_1.z.object({
    items: zod_1.z.array(exports.DatasetPreparationResponseSchema).max(50),
    page: zod_1.z.number().int().positive(), limit: zod_1.z.number().int().min(1).max(50),
    total: zod_1.z.number().int().nonnegative(),
}).strict();
function getDatasetPreparationReadiness(metadata) {
    const issues = [];
    const missing = (field, message) => issues.push({ code: "MISSING_INFORMATION", field, message });
    for (const [field, label] of [
        ["uploadChoice", "Choose what you are uploading."],
        ["primaryCategoryId", "Choose a primary category."], ["sourceId", "Choose your data source."],
        ["license", "State the dataset license."], ["collectionBoundary", "Define the collection this dataset represents."],
        ["overview", "Add a short overview."], ["description", "Explain how the collection is organized."],
        ["dataQuality", "Describe quality checks, or state that quality has not been assessed."],
    ]) {
        if (!metadata[field])
            missing(field, label);
    }
    if (!metadata.modalities?.length)
        missing("modalities", "Choose the main types of data.");
    if (!metadata.collectionMeasurements?.length)
        missing("collectionMeasurements", "Describe a collection quantity, or explicitly state that it is unknown.");
    if (metadata.uploadChoice === "SAMPLE_ONLY" || metadata.uploadChoice === "FULL_AND_SAMPLE") {
        const sample = metadata.sample;
        if (!sample?.selectionMethod)
            missing("sample.selectionMethod", "Describe how the sample was selected.");
        if (!sample?.coverage)
            missing("sample.coverage", "Describe the sample coverage, including what is unknown.");
        if (!sample?.omissions)
            missing("sample.omissions", "State what is omitted from the sample, or that it is unknown.");
        if (sample?.omissions === "DESCRIBED" && !sample.omissionNotes)
            missing("sample.omissionNotes", "Explain what is omitted from the sample.");
        if (!sample?.transformations)
            missing("sample.transformations", "State whether the sample was changed from its source.");
        if (sample?.transformations === "DESCRIBED" && !sample.transformationNotes)
            missing("sample.transformationNotes", "Describe the sample preparation or changes.");
    }
    if (metadata.uploadChoice === "FULL_ONLY" || metadata.uploadChoice === "FULL_AND_SAMPLE") {
        if (metadata.fullCompleteness !== true)
            missing("fullCompleteness", "Confirm that full material will cover the collection boundary you defined.");
    }
    const profiles = metadata.profiles;
    const required = (field, value, message) => { if (!value)
        missing(field, message); };
    if (metadata.modalities?.includes("TABULAR"))
        required("profiles.tabular.recordUnit", profiles?.tabular?.recordUnit, "Explain what one table record represents.");
    if (metadata.modalities?.includes("AUDIO")) {
        required("profiles.audio.content", profiles?.audio?.content, "Describe whether the audio contains speech or other sound.");
        required("profiles.audio.transcriptAvailability", profiles?.audio?.transcriptAvailability, "State transcript availability in the represented collection.");
    }
    if (metadata.modalities?.includes("IMAGE"))
        required("profiles.images.subject", profiles?.images?.subject, "Describe what the images show.");
    if (metadata.modalities?.includes("VIDEO"))
        required("profiles.video.content", profiles?.video?.content, "Describe what the videos show.");
    if (metadata.modalities?.includes("TEXT"))
        required("profiles.text.recordUnit", profiles?.text?.recordUnit, "Explain what one document or text record represents.");
    if (metadata.modalities?.includes("SENSOR"))
        required("profiles.sensors.channelNotes", profiles?.sensors?.channelNotes, "Explain the sensor channels and units, including any unknowns.");
    if (metadata.contexts?.includes("HEALTHCARE")) {
        required("profiles.healthcare.recordMeaning", profiles?.healthcare?.recordMeaning, "Describe what the healthcare records represent.");
        required("profiles.healthcare.identifierHandling", profiles?.healthcare?.identifierHandling, "Describe how personal identifiers were handled; this remains a supplier declaration.");
    }
    issues.push({ code: "FILES_NOT_ENABLED", message: "File upload and required file checks are not available in this testing release." });
    issues.push({ code: "SUBMISSION_NOT_ENABLED", message: "You can save and refine this draft. Admin submission will be enabled after file checks and review integration are ready." });
    return { canSubmit: false, issues };
}
