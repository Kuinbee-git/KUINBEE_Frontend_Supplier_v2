import { z } from "zod";
export declare const DatasetUploadAdmissionBodySchema: z.ZodObject<{
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    role: z.ZodEnum<{
        PRIMARY: "PRIMARY";
        TRANSCRIPT: "TRANSCRIPT";
        ANNOTATION: "ANNOTATION";
        SENSOR: "SENSOR";
        CALIBRATION: "CALIBRATION";
        DOCUMENTATION: "DOCUMENTATION";
    }>;
    originalName: z.ZodString;
    claimedMime: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    expectedBytes: z.ZodString;
    expectedPreparationGeneration: z.ZodNumber;
    expectedContentId: z.ZodString;
    expectedContentGeneration: z.ZodNumber;
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
}, z.core.$strict>;
export declare const DatasetUploadActionBodySchema: z.ZodObject<{
    expectedPreparationGeneration: z.ZodNumber;
    expectedContentId: z.ZodString;
    expectedContentGeneration: z.ZodNumber;
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
}, z.core.$strict>;
export declare const DatasetUploadAttemptResponseSchema: z.ZodObject<{
    requestId: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>;
    id: z.ZodString;
    rootId: z.ZodString;
    contentId: z.ZodString;
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    role: z.ZodEnum<{
        PRIMARY: "PRIMARY";
        TRANSCRIPT: "TRANSCRIPT";
        ANNOTATION: "ANNOTATION";
        SENSOR: "SENSOR";
        CALIBRATION: "CALIBRATION";
        DOCUMENTATION: "DOCUMENTATION";
    }>;
    originalName: z.ZodString;
    expectedBytes: z.ZodString;
    retainedBytes: z.ZodString;
    reservedBytes: z.ZodString;
    partBytes: z.ZodNumber;
    totalParts: z.ZodNumber;
    state: z.ZodEnum<{
        ACCEPTED: "ACCEPTED";
        ADMITTED: "ADMITTED";
        RECEIVING: "RECEIVING";
        FINALIZING: "FINALIZING";
        RECEIVED: "RECEIVED";
        CHECKING: "CHECKING";
        REJECTED: "REJECTED";
        CANCEL_REQUESTED: "CANCEL_REQUESTED";
        RECONCILIATION_REQUIRED: "RECONCILIATION_REQUIRED";
        CLOSED: "CLOSED";
    }>;
    revision: z.ZodNumber;
    expiresAt: z.ZodString;
    eligibility: z.ZodLiteral<"NOT_ACCEPTED">;
}, z.core.$strict>;
export type DatasetUploadAdmissionBody = z.infer<typeof DatasetUploadAdmissionBodySchema>;
export type DatasetUploadActionBody = z.infer<typeof DatasetUploadActionBodySchema>;
export type DatasetUploadAttemptResponse = z.infer<typeof DatasetUploadAttemptResponseSchema>;
//# sourceMappingURL=intake.schema.d.ts.map