import { z } from "zod";
export declare const DATASET_FILES_CONTRACT_VERSION: 1;
export declare const DATASET_FILES_PAGE_MAX = 50;
export declare const DatasetFilesContextBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedPreparationGeneration: z.ZodNumber;
    expectedContentId: z.ZodNullable<z.ZodString>;
    expectedContentGeneration: z.ZodNullable<z.ZodNumber>;
}, z.core.$strict>;
export declare const DatasetFilesUsageSchema: z.ZodObject<{
    state: z.ZodEnum<{
        UNAVAILABLE: "UNAVAILABLE";
        RECONCILING: "RECONCILING";
        ACCOUNTED: "ACCOUNTED";
    }>;
    dataset: z.ZodObject<{
        limitBytes: z.ZodLiteral<"5000000000" | "100000000000">;
        retainedBytes: z.ZodNullable<z.ZodString>;
        reservedBytes: z.ZodNullable<z.ZodString>;
        chargedBytes: z.ZodNullable<z.ZodString>;
        remainingBytes: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    supplier: z.ZodObject<{
        limitBytes: z.ZodLiteral<"5000000000" | "100000000000">;
        retainedBytes: z.ZodNullable<z.ZodString>;
        reservedBytes: z.ZodNullable<z.ZodString>;
        chargedBytes: z.ZodNullable<z.ZodString>;
        remainingBytes: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetFilesContextResponseSchema: z.ZodObject<{
    contractVersion: z.ZodLiteral<1>;
    requestId: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>;
    preparationId: z.ZodString;
    preparationGeneration: z.ZodNumber;
    contentId: z.ZodNullable<z.ZodString>;
    contentGeneration: z.ZodNullable<z.ZodNumber>;
    sourcePreparationGeneration: z.ZodNullable<z.ZodNumber>;
    serverUploadChoice: z.ZodNullable<z.ZodEnum<{
        SAMPLE_ONLY: "SAMPLE_ONLY";
        FULL_ONLY: "FULL_ONLY";
        FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
    }>>;
    editable: z.ZodBoolean;
    synchronizationRequired: z.ZodBoolean;
    usage: z.ZodObject<{
        state: z.ZodEnum<{
            UNAVAILABLE: "UNAVAILABLE";
            RECONCILING: "RECONCILING";
            ACCOUNTED: "ACCOUNTED";
        }>;
        dataset: z.ZodObject<{
            limitBytes: z.ZodLiteral<"5000000000" | "100000000000">;
            retainedBytes: z.ZodNullable<z.ZodString>;
            reservedBytes: z.ZodNullable<z.ZodString>;
            chargedBytes: z.ZodNullable<z.ZodString>;
            remainingBytes: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        supplier: z.ZodObject<{
            limitBytes: z.ZodLiteral<"5000000000" | "100000000000">;
            retainedBytes: z.ZodNullable<z.ZodString>;
            reservedBytes: z.ZodNullable<z.ZodString>;
            chargedBytes: z.ZodNullable<z.ZodString>;
            remainingBytes: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    admission: z.ZodObject<{
        enabled: z.ZodLiteral<false>;
        reason: z.ZodLiteral<"INTAKE_NOT_ENABLED">;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetFilesInventoryPageQuerySchema: z.ZodObject<{
    expectedPreparationGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    contentId: z.ZodString;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    component: z.ZodOptional<z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export declare const DatasetFilesInventoryMemberSchema: z.ZodObject<{
    id: z.ZodString;
    contentId: z.ZodString;
    uploadObjectId: z.ZodString;
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    role: z.ZodEnum<{
        PRIMARY: "PRIMARY";
        TRANSCRIPT: "TRANSCRIPT";
        ANNOTATION: "ANNOTATION";
        SENSOR: "SENSOR";
        CALIBRATION: "CALIBRATION";
        DOCUMENTATION: "DOCUMENTATION";
    }>;
    relativePath: z.ZodNullable<z.ZodString>;
    groupId: z.ZodNullable<z.ZodString>;
    originalFileName: z.ZodNullable<z.ZodString>;
    measuredSizeBytes: z.ZodString;
    inspection: z.ZodObject<{
        securityState: z.ZodEnum<{
            QUARANTINED: "QUARANTINED";
            PROCESSING: "PROCESSING";
            ACCEPTED: "ACCEPTED";
            BLOCKED: "BLOCKED";
            FAILED: "FAILED";
            CANCELLED: "CANCELLED";
            UNRECONCILED: "UNRECONCILED";
            UNKNOWN: "UNKNOWN";
        }>;
        currentEvidenceId: z.ZodNullable<z.ZodString>;
        recordedOutcome: z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            NONE: "NONE";
            PASS: "PASS";
            FAIL: "FAIL";
        }>;
        current: z.ZodBoolean;
        eligibility: z.ZodLiteral<"NOT_EVALUATED">;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetFilesInventoryPageResponseSchema: z.ZodObject<{
    preparationId: z.ZodString;
    preparationGeneration: z.ZodNumber;
    contentId: z.ZodString;
    contentGeneration: z.ZodNumber;
    sourcePreparationGeneration: z.ZodNumber;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        contentId: z.ZodString;
        uploadObjectId: z.ZodString;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        role: z.ZodEnum<{
            PRIMARY: "PRIMARY";
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            SENSOR: "SENSOR";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
        }>;
        relativePath: z.ZodNullable<z.ZodString>;
        groupId: z.ZodNullable<z.ZodString>;
        originalFileName: z.ZodNullable<z.ZodString>;
        measuredSizeBytes: z.ZodString;
        inspection: z.ZodObject<{
            securityState: z.ZodEnum<{
                QUARANTINED: "QUARANTINED";
                PROCESSING: "PROCESSING";
                ACCEPTED: "ACCEPTED";
                BLOCKED: "BLOCKED";
                FAILED: "FAILED";
                CANCELLED: "CANCELLED";
                UNRECONCILED: "UNRECONCILED";
                UNKNOWN: "UNKNOWN";
            }>;
            currentEvidenceId: z.ZodNullable<z.ZodString>;
            recordedOutcome: z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                NONE: "NONE";
                PASS: "PASS";
                FAIL: "FAIL";
            }>;
            current: z.ZodBoolean;
            eligibility: z.ZodLiteral<"NOT_EVALUATED">;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        afterId: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type DatasetFilesContextBody = z.infer<typeof DatasetFilesContextBodySchema>;
export type DatasetFilesContextResponse = z.infer<typeof DatasetFilesContextResponseSchema>;
export type DatasetFilesUsage = z.infer<typeof DatasetFilesUsageSchema>;
export type DatasetFilesInventoryPageQuery = z.infer<typeof DatasetFilesInventoryPageQuerySchema>;
export type DatasetFilesInventoryPageResponse = z.infer<typeof DatasetFilesInventoryPageResponseSchema>;
//# sourceMappingURL=files.schema.d.ts.map