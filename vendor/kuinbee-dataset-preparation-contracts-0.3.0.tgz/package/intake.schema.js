"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetUploadAttemptResponseSchema = exports.DatasetUploadActionBodySchema = exports.DatasetUploadAdmissionBodySchema = void 0;
const zod_1 = require("zod");
const content_schema_1 = require("./content.schema");
const id = zod_1.z.string().cuid();
const generation = zod_1.z.number().int().min(0).max(2_147_483_647);
const requestId = zod_1.z.string().uuid().transform(value => value.toLowerCase());
const bytes = zod_1.z.string().regex(/^[1-9][0-9]{0,9}$/).refine(value => {
    return /^[1-9][0-9]{0,9}$/.test(value) && BigInt(value) <= 5000000000n;
}, "A file must fit the shared Dataset allowance");
const hasControl = (value) => Array.from(value).some(character => {
    const code = character.codePointAt(0);
    return code < 32 || code === 127;
});
const name = zod_1.z.string().min(1).max(1_024).refine(value => !hasControl(value) && !value.includes("/") && !value.includes("\\") &&
    new TextEncoder().encode(value).length <= 1_024 && value !== "." && value !== "..", "Supply a plain original filename");
const context = {
    expectedPreparationGeneration: generation,
    expectedContentId: id,
    expectedContentGeneration: generation,
};
exports.DatasetUploadAdmissionBodySchema = zod_1.z.object({
    requestId, ...context,
    component: content_schema_1.DatasetMaterialComponentSchema,
    role: content_schema_1.DatasetMaterialRoleSchema,
    originalName: name,
    claimedMime: zod_1.z.string().max(256).refine(value => !hasControl(value)).nullable().optional(),
    expectedBytes: bytes,
}).strict();
exports.DatasetUploadActionBodySchema = zod_1.z.object({ requestId, ...context }).strict();
exports.DatasetUploadAttemptResponseSchema = zod_1.z.object({
    requestId: requestId.optional(), id, rootId: id, contentId: id,
    component: content_schema_1.DatasetMaterialComponentSchema, role: content_schema_1.DatasetMaterialRoleSchema,
    originalName: name,
    expectedBytes: bytes,
    retainedBytes: zod_1.z.string().regex(/^(0|[1-9][0-9]{0,9})$/),
    reservedBytes: zod_1.z.string().regex(/^(0|[1-9][0-9]{0,9})$/),
    partBytes: zod_1.z.number().int().min(1).max(8 * 1_024 * 1_024),
    totalParts: zod_1.z.number().int().min(1).max(10_000),
    state: zod_1.z.enum(["ADMITTED", "RECEIVING", "FINALIZING", "RECEIVED", "CHECKING", "ACCEPTED", "REJECTED", "CANCEL_REQUESTED", "RECONCILIATION_REQUIRED", "CLOSED"]),
    revision: generation,
    expiresAt: zod_1.z.string().datetime(),
    // Receipt and recognition are not successful format/malware inspection.
    eligibility: zod_1.z.literal("NOT_ACCEPTED"),
}).strict().refine(value => [value.retainedBytes, value.reservedBytes, value.expectedBytes].every(entry => /^(0|[1-9][0-9]{0,9})$/.test(entry)) &&
    BigInt(value.retainedBytes) + BigInt(value.reservedBytes) <= BigInt(value.expectedBytes), "Part receipts convert reservation without adding unaccounted capacity");
