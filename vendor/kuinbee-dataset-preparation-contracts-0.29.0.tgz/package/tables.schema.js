"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetTableDescriptionsMutationResponseSchema = exports.DatasetTableDescriptionsPageResponseSchema = exports.DatasetColumnDescriptionItemSchema = exports.DatasetTableDescriptionItemSchema = exports.DatasetTableDescriptionsPageQuerySchema = exports.DatasetTableDescriptionsMutationBodySchema = exports.DatasetTableDescriptionOperationSchema = exports.DatasetColumnDescriptionChangesSchema = exports.DatasetTableDescriptionChangesSchema = exports.DatasetColumnSemanticTypeSchema = exports.DatasetTableAnswerStateSchema = void 0;
const zod_1 = require("zod");
const edit_schema_1 = require("./edit.schema");
const content_schema_1 = require("./content.schema");
// Supplier interpretations are separate from immutable, backend-observed
// structure. These private editor contracts never expose cells or storage keys.
const id = zod_1.z.string().cuid();
const generation = zod_1.z.number().int().min(0).max(2_147_483_647);
const queryGeneration = zod_1.z.union([generation, zod_1.z.string().regex(/^(0|[1-9][0-9]{0,9})$/).transform(Number).pipe(generation)]);
const requestId = zod_1.z.string().uuid().transform(value => value.toLowerCase());
exports.DatasetTableAnswerStateSchema = zod_1.z.enum(["KNOWN", "UNKNOWN", "NOT_APPLICABLE"]);
exports.DatasetColumnSemanticTypeSchema = zod_1.z.enum([
    "UNKNOWN", "IDENTIFIER", "CATEGORY", "TEXT", "INTEGER", "DECIMAL", "BOOLEAN", "DATE", "DATETIME", "COORDINATE", "OTHER",
]);
exports.DatasetTableDescriptionChangesSchema = zod_1.z.object({
    displayName: zod_1.z.string().trim().max(200).nullable().optional(),
    recordUnit: zod_1.z.string().trim().max(1_000).nullable().optional(),
    missingConventionState: exports.DatasetTableAnswerStateSchema.nullable().optional(),
    missingConventionDetails: zod_1.z.string().trim().max(2_000).nullable().optional(),
}).strict();
exports.DatasetColumnDescriptionChangesSchema = zod_1.z.object({
    meaningState: zod_1.z.enum(["KNOWN", "UNKNOWN"]).nullable().optional(),
    description: zod_1.z.string().trim().max(2_000).nullable().optional(),
    semanticType: exports.DatasetColumnSemanticTypeSchema.nullable().optional(),
    unitState: exports.DatasetTableAnswerStateSchema.nullable().optional(),
    unit: zod_1.z.string().trim().max(200).nullable().optional(),
}).strict();
const nonempty = (value) => Object.keys(value).length > 0;
exports.DatasetTableDescriptionOperationSchema = zod_1.z.discriminatedUnion("operation", [
    zod_1.z.object({ operation: zod_1.z.literal("SET_TABLE"), memberId: id, tableId: id,
        changes: exports.DatasetTableDescriptionChangesSchema.refine(nonempty, "Supply an explicit field change") }).strict(),
    zod_1.z.object({ operation: zod_1.z.literal("SET_COLUMN"), memberId: id, tableId: id, columnId: id,
        changes: exports.DatasetColumnDescriptionChangesSchema.refine(nonempty, "Supply an explicit field change") }).strict(),
]);
exports.DatasetTableDescriptionsMutationBodySchema = zod_1.z.object({
    requestId, expectedContentId: id, expectedGeneration: generation, expectedPreparationGeneration: generation,
    editContext: edit_schema_1.DatasetCorrectionPreconditionSchema.optional(),
    operations: zod_1.z.array(exports.DatasetTableDescriptionOperationSchema).min(1).max(50),
}).strict();
exports.DatasetTableDescriptionsPageQuerySchema = zod_1.z.object({
    contentId: id, contentGeneration: queryGeneration, expectedPreparationGeneration: queryGeneration,
    memberId: id, tableId: id.optional(), afterId: id.optional(),
    limit: zod_1.z.coerce.number().int().min(1).max(50).default(20),
}).strict();
const tableDescription = exports.DatasetTableDescriptionChangesSchema.required();
const columnDescription = exports.DatasetColumnDescriptionChangesSchema.required();
exports.DatasetTableDescriptionItemSchema = zod_1.z.object({ kind: zod_1.z.literal("TABLE"), id, syntaxProfileId: zod_1.z.enum(["UTF8_CSV_SYNTAX_V1", "UTF8_TSV_SYNTAX_V1"]),
    headerConvention: zod_1.z.enum(["PRESENT", "ABSENT"]), logicalEntryId: id.nullable(),
    locator: content_schema_1.DatasetLogicalLocatorSchema.nullable(),
    columnCount: zod_1.z.number().int().min(1).max(1_024), recordCount: zod_1.z.string().regex(/^\d+$/), dataRecordCount: zod_1.z.string().regex(/^\d+$/),
    description: tableDescription.nullable() }).strict();
exports.DatasetColumnDescriptionItemSchema = zod_1.z.object({ kind: zod_1.z.literal("COLUMN"), id, tableId: id,
    position: zod_1.z.number().int().min(1).max(1_024), observedName: zod_1.z.string().max(65_536).nullable(),
    storageRepresentation: zod_1.z.literal("UTF8_TEXT"), description: columnDescription.nullable() }).strict();
exports.DatasetTableDescriptionsPageResponseSchema = zod_1.z.object({
    contentId: id, contentGeneration: generation, preparationGeneration: generation, frozen: zod_1.z.boolean(),
    memberId: id, component: content_schema_1.DatasetMaterialComponentSchema, tableId: id.nullable(),
    table: exports.DatasetTableDescriptionItemSchema.nullable(),
    items: zod_1.z.array(zod_1.z.discriminatedUnion("kind", [exports.DatasetTableDescriptionItemSchema, exports.DatasetColumnDescriptionItemSchema])).max(50),
    nextCursor: exports.DatasetTableDescriptionsPageQuerySchema.nullable(),
}).strict().refine(page => new Set(page.items.map(item => item.id)).size === page.items.length &&
    (page.tableId ? page.table?.id === page.tableId : page.table === null) &&
    page.items.every(item => page.tableId ? item.kind === "COLUMN" && item.tableId === page.tableId : item.kind === "TABLE") &&
    (!page.nextCursor || (page.nextCursor.contentId === page.contentId && page.nextCursor.contentGeneration === page.contentGeneration &&
        page.nextCursor.expectedPreparationGeneration === page.preparationGeneration && page.nextCursor.memberId === page.memberId &&
        (page.nextCursor.tableId ?? null) === page.tableId && page.nextCursor.afterId === page.items.at(-1)?.id)), "Each page and cursor must preserve its exact member, table and generations");
exports.DatasetTableDescriptionsMutationResponseSchema = zod_1.z.object({
    requestId, contentId: id, generation, preparationGeneration: generation,
    results: zod_1.z.array(zod_1.z.object({ index: zod_1.z.number().int().min(0).max(49), operation: zod_1.z.enum(["SET_TABLE", "SET_COLUMN"]),
        memberId: id, tableId: id, columnId: id.nullable() }).strict()).min(1).max(50),
}).strict().refine(value => value.results.every((item, index) => item.index === index), "Acknowledge every change in order");
