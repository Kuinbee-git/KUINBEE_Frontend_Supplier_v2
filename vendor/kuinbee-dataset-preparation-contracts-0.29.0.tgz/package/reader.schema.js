"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetLibraryGetResponseSchema = exports.DatasetLibraryListResponseSchema = exports.DatasetLibraryItemSchema = exports.DatasetReaderIdParamsSchema = exports.DatasetLibraryListQuerySchema = exports.DatasetPublicDescriptionSchema = exports.DatasetPublicProfilesSchema = void 0;
const zod_1 = require("zod");
const preparation_schema_1 = require("./preparation.schema");
const content_schema_1 = require("./content.schema");
const id = zod_1.z.string().min(1).max(128);
const label = zod_1.z.object({ id, name: zod_1.z.string().min(1).max(1_000) }).strict();
// This audience allowlist is deliberately separate from editable metadata.
// Adding a supplier field never automatically publishes it to catalogue/library.
const profiles = preparation_schema_1.DatasetPreparationProfilesSchema.shape;
exports.DatasetPublicProfilesSchema = zod_1.z.object({
    tabular: profiles.tabular.unwrap().unwrap().pick({ recordUnit: true, columnMeaningNotes: true,
        unitNotes: true, missingValueConventions: true, tableRelationshipNotes: true, dictionaryAvailability: true }).optional(),
    audio: profiles.audio.unwrap().unwrap().pick({ content: true, languages: true, recordingContext: true,
        transcriptAvailability: true, transcriptMeaning: true, annotationAvailability: true, annotationMeaning: true,
        speakerCoverage: true, alignmentNotes: true, transcriptTiming: true }).optional(),
    images: profiles.images.unwrap().unwrap().pick({ subject: true, captureContext: true,
        annotationAvailability: true, annotationMeaning: true, classDefinitions: true, coverage: true }).optional(),
    video: profiles.video.unwrap().unwrap().pick({ content: true, viewpoint: true, audioContext: true,
        annotationAvailability: true, annotationMeaning: true, timingConvention: true, annotationReferences: true }).optional(),
    text: profiles.text.unwrap().unwrap().pick({ recordUnit: true, languageContent: true, languages: true, annotationAvailability: true,
        annotationMeaning: true, recordConvention: true }).optional(),
    sensors: profiles.sensors.unwrap().unwrap().pick({ channels: true, channelNotes: true, sessionRelationships: true,
        timestampMeaning: true, timeOrigin: true, synchronization: true, synchronizationNotes: true,
        calibrationAvailability: true, calibrationMeaning: true, coordinateConventions: true }).optional(),
    egocentric: profiles.egocentric.unwrap().unwrap().pick({ mounting: true, activities: true, environment: true,
        additionalStreams: true }).optional(),
    healthcare: profiles.healthcare.unwrap().unwrap().pick({ recordMeaning: true, setting: true,
        identifierHandling: true, participantCoverage: true }).optional(),
}).strict();
exports.DatasetPublicDescriptionSchema = zod_1.z.object({
    title: zod_1.z.string().min(1).max(200), license: zod_1.z.string().min(1).max(1_000),
    overview: zod_1.z.string().min(1).max(4_000), description: zod_1.z.string().min(1).max(4_000),
    dataQuality: zod_1.z.string().min(1).max(4_000), collectionBoundary: zod_1.z.string().min(1).max(4_000),
    // Optional declarations from this exact frozen content. Older snapshots do
    // not acquire coverage from current metadata or uploaded file timestamps.
    geographicCoverage: preparation_schema_1.DatasetGeographicCoverageSchema.nullable().optional(),
    collectionPeriod: preparation_schema_1.DatasetCollectionPeriodSchema.nullable().optional(),
    limitations: zod_1.z.string().max(4_000).nullable(), methodology: zod_1.z.string().max(4_000).nullable(),
    useCases: zod_1.z.string().max(4_000).nullable(),
    uploadChoice: preparation_schema_1.DatasetUploadChoiceSchema, modalities: zod_1.z.array(preparation_schema_1.DatasetModalitySchema).min(1).max(6),
    contexts: zod_1.z.array(preparation_schema_1.DatasetContextSchema).max(2),
    // Null is meaningful: audio/video/images are not forced into a study design.
    studyStructure: zod_1.z.string().max(100).nullable(),
    tags: zod_1.z.array(zod_1.z.string().max(80)).max(20),
    categoriesAtFreeze: zod_1.z.object({ primary: label, additional: zod_1.z.array(label).max(10) }).strict(),
    sourceAtFreeze: zod_1.z.object({ id, name: zod_1.z.string().max(1_000), description: zod_1.z.string().max(4_000).nullable(),
        websiteUrl: zod_1.z.string().url().max(2_000).nullable(), isVerifiedAtFreeze: zod_1.z.boolean() }).strict(),
    measurements: zod_1.z.array(zod_1.z.object({
        scope: zod_1.z.enum(["REPRESENTED_COLLECTION", "FULL_MATERIAL", "SAMPLE_MATERIAL"]),
        origin: zod_1.z.literal("SUPPLIER_DECLARED"), values: zod_1.z.array(preparation_schema_1.DatasetDeclaredMeasurementSchema).max(12),
    }).strict()).min(1).max(3),
    sample: preparation_schema_1.DatasetPreparationSampleSchema.nullable(), fullCompleteness: zod_1.z.boolean().nullable(),
    profiles: exports.DatasetPublicProfilesSchema,
}).strict();
exports.DatasetLibraryListQuerySchema = zod_1.z.object({
    page: zod_1.z.coerce.number().int().min(1).max(10_000).default(1),
    pageSize: zod_1.z.coerce.number().int().min(1).max(50).default(20),
    q: zod_1.z.string().trim().min(1).max(200).optional(),
}).strict();
exports.DatasetReaderIdParamsSchema = zod_1.z.object({ datasetId: id }).strict();
const libraryBase = {
    datasetId: id, datasetUniqueId: zod_1.z.string().min(1).max(128),
    accessType: zod_1.z.enum(["PURCHASE", "FREE_CLAIM"]), grantedAt: zod_1.z.string().datetime(),
    expiresAt: zod_1.z.string().datetime().nullable(),
    // RECORDED describes an entitlement record, not current signing/security readiness.
    recordedAccess: zod_1.z.enum(["RECORDED", "EXPIRED", "REVOKED", "UNRESOLVED"]),
};
exports.DatasetLibraryItemSchema = zod_1.z.discriminatedUnion("representation", [
    zod_1.z.object({ ...libraryBase, representation: zod_1.z.literal("CONTENT"), title: zod_1.z.string().max(200).nullable(),
        metadataProvenance: zod_1.z.enum(["FROZEN_GRANT_CONTENT", "UNRESOLVED"]),
        description: exports.DatasetPublicDescriptionSchema.nullable(), grantId: zod_1.z.string().cuid().nullable(),
        material: content_schema_1.DatasetFrozenMaterialReferenceSchema.nullable(),
    }).strict(),
    zod_1.z.object({ ...libraryBase, representation: zod_1.z.literal("LEGACY"), title: zod_1.z.string().max(200),
        metadataProvenance: zod_1.z.literal("CURRENT_LEGACY_RECORD"), historicalMetadata: zod_1.z.null(),
        recordedUploadId: id.nullable(),
    }).strict(),
]);
exports.DatasetLibraryListResponseSchema = zod_1.z.object({ items: zod_1.z.array(exports.DatasetLibraryItemSchema).max(50),
    page: zod_1.z.number().int().min(1), pageSize: zod_1.z.number().int().min(1).max(50), total: zod_1.z.number().int().nonnegative(),
}).strict();
exports.DatasetLibraryGetResponseSchema = zod_1.z.object({ item: exports.DatasetLibraryItemSchema }).strict();
