"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetPublicTableMetadataResponseSchema = exports.DatasetPublicTableMetadataQuerySchema = exports.DatasetPrivateTableMetadataResponseSchema = exports.DatasetPrivateTableMetadataQuerySchema = exports.DatasetTableMetadataPageSchema = exports.DatasetTableMetadataCursorSchema = exports.DatasetTableMetadataColumnSchema = exports.DatasetTableMetadataTableSchema = void 0;
const zod_1 = require("zod");
const content_schema_1 = require("./content.schema");
const tables_schema_1 = require("./tables.schema");
const access_schema_1 = require("./access.schema");
const id = zod_1.z.string().cuid();
const generation = zod_1.z.number().int().min(0).max(2_147_483_647);
const queryGeneration = zod_1.z.union([generation, zod_1.z.string().regex(/^(0|[1-9][0-9]{0,9})$/).transform(Number).pipe(generation)]);
const limit = zod_1.z.coerce.number().int().min(1).max(50).default(20);
const answer = (states, maximum) => zod_1.z.object({ state: states.nullable(), value: zod_1.z.string().max(maximum).nullable() }).strict()
    .refine(value => value.state === "KNOWN" || value.value === null, "Inactive answers must not become displayed claims");
// Listing schema metadata is an explicit allowlist, not serialized inspection
// records. Private archive paths/assessment IDs live only in the private wrapper.
exports.DatasetTableMetadataTableSchema = zod_1.z.object({ kind: zod_1.z.literal("TABLE"), id,
    component: content_schema_1.DatasetMaterialComponentSchema, displayName: zod_1.z.string().max(200).nullable(), recordUnit: zod_1.z.string().max(1_000).nullable(),
    missingValues: answer(tables_schema_1.DatasetTableAnswerStateSchema, 2_000),
    observed: zod_1.z.object({ origin: zod_1.z.literal("BACKEND_OBSERVED"), scope: zod_1.z.literal("EXACT_TABLE"),
        dataRecordCount: zod_1.z.string().regex(/^(0|[1-9][0-9]*)$/), columnCount: zod_1.z.number().int().min(1).max(1_024),
        headerConvention: zod_1.z.enum(["PRESENT", "ABSENT"]) }).strict(),
}).strict();
exports.DatasetTableMetadataColumnSchema = zod_1.z.object({ kind: zod_1.z.literal("COLUMN"), id, tableId: id,
    position: zod_1.z.number().int().min(1).max(1_024), observedName: zod_1.z.string().max(65_536).nullable(),
    storageRepresentation: zod_1.z.literal("UTF8_TEXT"), meaning: answer(zod_1.z.enum(["KNOWN", "UNKNOWN"]), 2_000),
    declaredType: tables_schema_1.DatasetColumnSemanticTypeSchema.nullable(), unit: answer(tables_schema_1.DatasetTableAnswerStateSchema, 200),
}).strict();
exports.DatasetTableMetadataCursorSchema = zod_1.z.object({ contentId: id, contentGeneration: queryGeneration,
    component: content_schema_1.DatasetMaterialComponentSchema.optional(), tableId: id.optional(), afterId: id.optional(), limit }).strict();
exports.DatasetTableMetadataPageSchema = zod_1.z.object({ contentId: id, contentGeneration: generation, frozen: zod_1.z.boolean(), frozenAt: zod_1.z.string().datetime().nullable(),
    component: content_schema_1.DatasetMaterialComponentSchema.nullable(), tableId: id.nullable(), table: exports.DatasetTableMetadataTableSchema.nullable(),
    items: zod_1.z.array(zod_1.z.discriminatedUnion("kind", [exports.DatasetTableMetadataTableSchema, exports.DatasetTableMetadataColumnSchema])).max(50),
    nextCursor: exports.DatasetTableMetadataCursorSchema.nullable(),
}).strict().refine(page => page.frozen === (page.frozenAt !== null) && new Set(page.items.map(item => item.id)).size === page.items.length &&
    (page.tableId ? page.table?.id === page.tableId : page.table === null) &&
    (!page.table || !page.component || page.table.component === page.component) &&
    page.items.every((item, index) => page.tableId ? item.kind === "COLUMN" && item.tableId === page.tableId &&
        (!index || page.items[index - 1].kind === "COLUMN" && page.items[index - 1].position < item.position) :
        item.kind === "TABLE" && (!page.component || item.component === page.component)) &&
    (!page.nextCursor || page.nextCursor.contentId === page.contentId && page.nextCursor.contentGeneration === page.contentGeneration &&
        (page.nextCursor.component ?? null) === page.component && (page.nextCursor.tableId ?? null) === page.tableId && page.nextCursor.afterId === page.items.at(-1)?.id), "Table metadata pages preserve their exact content, component, table and ordinal cursor");
exports.DatasetPrivateTableMetadataQuerySchema = access_schema_1.DatasetFileAccessPageQuerySchema.extend({ memberId: id.optional(), tableId: id.optional() });
exports.DatasetPrivateTableMetadataResponseSchema = zod_1.z.object({ context: access_schema_1.DatasetFileAccessContextSchema,
    memberId: id.nullable(), page: exports.DatasetTableMetadataPageSchema,
    targets: zod_1.z.array(zod_1.z.object({ id, memberId: id, observedTableId: id, evidenceId: id, locator: content_schema_1.DatasetLogicalLocatorSchema.nullable() }).strict()).max(50),
}).strict().refine(value => value.context.contentId === value.page.contentId && value.context.contentGeneration === value.page.contentGeneration &&
    value.context.component === value.page.component && value.context.frozen === value.page.frozen &&
    new Set(value.targets.map(target => target.id)).size === value.targets.length &&
    value.targets.every(target => !value.memberId || target.memberId === value.memberId) &&
    (value.page.tableId ? value.targets.length === 1 && value.targets[0].id === value.page.tableId :
        value.targets.length === value.page.items.length && value.page.items.every(item => value.targets.some(target => target.id === item.id))), "Private table references belong to the exact authorized metadata page");
exports.DatasetPublicTableMetadataQuerySchema = zod_1.z.object({ publicationId: id, contentId: id,
    contentGeneration: queryGeneration.optional(), component: content_schema_1.DatasetMaterialComponentSchema.optional(), tableId: id.optional(), afterId: id.optional(), limit }).strict();
exports.DatasetPublicTableMetadataResponseSchema = zod_1.z.object({ datasetId: id, publicationId: id, page: exports.DatasetTableMetadataPageSchema }).strict()
    .refine(value => value.page.frozen, "Published table metadata must remain frozen");
