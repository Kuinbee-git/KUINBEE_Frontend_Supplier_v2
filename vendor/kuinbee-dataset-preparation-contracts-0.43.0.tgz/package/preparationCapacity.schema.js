"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetPreparationCapacityUpdateBodySchema = exports.DatasetPreparationCapacityResponseSchema = exports.DATASET_PREPARATION_MAX_ALLOWANCE = void 0;
const zod_1 = require("zod");
exports.DATASET_PREPARATION_MAX_ALLOWANCE = 100_000;
// This allowance counts retained preparations, including those that later
// enter review or publication. It does not replace metadata or upload budgets.
exports.DatasetPreparationCapacityResponseSchema = zod_1.z.object({
    limit: zod_1.z.number().int().min(1).max(exports.DATASET_PREPARATION_MAX_ALLOWANCE),
    used: zod_1.z.number().int().nonnegative(),
    remaining: zod_1.z.number().int().nonnegative(),
    generation: zod_1.z.number().int().nonnegative(),
    override: zod_1.z.number().int().min(1).max(exports.DATASET_PREPARATION_MAX_ALLOWANCE).nullable(),
}).strict().refine(value => value.remaining === Math.max(0, value.limit - value.used), "Remaining allowance must match the retained preparation count")
    .refine(value => value.override === null || value.override === value.limit, "An account override must match the effective allowance");
exports.DatasetPreparationCapacityUpdateBodySchema = zod_1.z.object({
    requestId: zod_1.z.string().uuid(),
    expectedGeneration: zod_1.z.number().int().nonnegative(),
    limitOverride: zod_1.z.number().int().min(1).max(exports.DATASET_PREPARATION_MAX_ALLOWANCE).nullable(),
    reason: zod_1.z.string().trim().min(1).max(1_000),
}).strict();
