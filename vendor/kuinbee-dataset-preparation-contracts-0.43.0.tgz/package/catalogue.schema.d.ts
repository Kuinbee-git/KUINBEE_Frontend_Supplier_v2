import { z } from "zod";
export declare const DatasetCatalogueListQuerySchema: z.ZodObject<{
    q: z.ZodOptional<z.ZodString>;
    search: z.ZodOptional<z.ZodString>;
    categoryId: z.ZodOptional<z.ZodString>;
    isPaid: z.ZodOptional<z.ZodPreprocess<z.ZodBoolean>>;
    minPrice: z.ZodOptional<z.ZodString>;
    maxPrice: z.ZodOptional<z.ZodString>;
    currency: z.ZodOptional<z.ZodEnum<{
        INR: "INR";
        USD: "USD";
        EUR: "EUR";
        GBP: "GBP";
    }>>;
    minKdtsScore: z.ZodOptional<z.ZodString>;
    sort: z.ZodOptional<z.ZodEnum<{
        "createdAt:desc": "createdAt:desc";
        "createdAt:asc": "createdAt:asc";
        "updatedAt:desc": "updatedAt:desc";
        "rating:desc": "rating:desc";
        relevance: "relevance";
        "price:asc": "price:asc";
        "price:desc": "price:desc";
        "viewCount:desc": "viewCount:desc";
        "downloadCount:desc": "downloadCount:desc";
        "kdtsScore:desc": "kdtsScore:desc";
    }>>;
    expectedCategoryRevision: z.ZodOptional<z.ZodString>;
    page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    pageSize: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    modalities: z.ZodPreprocess<z.ZodOptional<z.ZodArray<z.ZodEnum<{
        TABULAR: "TABULAR";
        TEXT: "TEXT";
        IMAGE: "IMAGE";
        VIDEO: "VIDEO";
        AUDIO: "AUDIO";
        SENSOR: "SENSOR";
        CAD: "CAD";
    }>>>>;
    contexts: z.ZodPreprocess<z.ZodOptional<z.ZodArray<z.ZodEnum<{
        HEALTHCARE: "HEALTHCARE";
        EGOCENTRIC: "EGOCENTRIC";
    }>>>>;
    uploadChoice: z.ZodOptional<z.ZodEnum<{
        SAMPLE_ONLY: "SAMPLE_ONLY";
        FULL_ONLY: "FULL_ONLY";
        FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
    }>>;
    categoryIds: z.ZodPreprocess<z.ZodOptional<z.ZodArray<z.ZodString>>>;
    tags: z.ZodPreprocess<z.ZodOptional<z.ZodArray<z.ZodString>>>;
    country: z.ZodOptional<z.ZodString>;
    state: z.ZodOptional<z.ZodString>;
    city: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetCatalogueMaterialSummarySchema: z.ZodObject<{
    component: z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>;
    origin: z.ZodLiteral<"SELECTED_PHYSICAL_FILES">;
    fileCount: z.ZodNumber;
    sizeBytes: z.ZodString;
}, z.core.$strict>;
export declare const DatasetCanonicalCatalogueCardSchema: z.ZodObject<{
    id: z.ZodString;
    datasetUniqueId: z.ZodString;
    title: z.ZodString;
    status: z.ZodLiteral<"PUBLISHED">;
    license: z.ZodString;
    owner: z.ZodObject<{
        id: z.ZodString;
        type: z.ZodEnum<{
            supplier: "supplier";
            platform: "platform";
        }>;
        name: z.ZodString;
        logoUrl: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>;
    publication: z.ZodObject<{
        id: z.ZodString;
        contentId: z.ZodString;
        publishedAt: z.ZodString;
    }, z.core.$strict>;
    overview: z.ZodString;
    uploadChoice: z.ZodEnum<{
        SAMPLE_ONLY: "SAMPLE_ONLY";
        FULL_ONLY: "FULL_ONLY";
        FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
    }>;
    modalities: z.ZodArray<z.ZodEnum<{
        TABULAR: "TABULAR";
        TEXT: "TEXT";
        IMAGE: "IMAGE";
        VIDEO: "VIDEO";
        AUDIO: "AUDIO";
        SENSOR: "SENSOR";
        CAD: "CAD";
    }>>;
    contexts: z.ZodArray<z.ZodEnum<{
        HEALTHCARE: "HEALTHCARE";
        EGOCENTRIC: "EGOCENTRIC";
    }>>;
    category: z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
    }, z.core.$strict>;
    categoryAtFreeze: z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
    }, z.core.$strict>;
    categoryNameOrigin: z.ZodEnum<{
        CURRENT_CATEGORY: "CURRENT_CATEGORY";
        CAPTURED_CATEGORY: "CAPTURED_CATEGORY";
    }>;
    secondaryCategories: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
    }, z.core.$strict>>>;
    tags: z.ZodArray<z.ZodString>;
    measurements: z.ZodArray<z.ZodObject<{
        scope: z.ZodEnum<{
            REPRESENTED_COLLECTION: "REPRESENTED_COLLECTION";
            FULL_MATERIAL: "FULL_MATERIAL";
            SAMPLE_MATERIAL: "SAMPLE_MATERIAL";
        }>;
        origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
        values: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>;
    }, z.core.$strict>>;
    materials: z.ZodArray<z.ZodObject<{
        component: z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>;
        origin: z.ZodLiteral<"SELECTED_PHYSICAL_FILES">;
        fileCount: z.ZodNumber;
        sizeBytes: z.ZodString;
    }, z.core.$strict>>;
    assessment: z.ZodObject<{
        score: z.ZodString;
        scope: z.ZodLiteral<"UPLOADED_COMPONENTS">;
        components: z.ZodArray<z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>>;
        representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
    }, z.core.$strict>;
    purchase: z.ZodObject<{
        mode: z.ZodEnum<{
            FREE_CLAIM: "FREE_CLAIM";
            PAID_CHECKOUT: "PAID_CHECKOUT";
            UNAVAILABLE: "UNAVAILABLE";
            DISPLAY_ONLY: "DISPLAY_ONLY";
        }>;
        component: z.ZodNullable<z.ZodLiteral<"FULL">>;
        pricing: z.ZodNullable<z.ZodObject<{
            surface: z.ZodNullable<z.ZodEnum<{
                DATASET_PRICING: "DATASET_PRICING";
                SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
            }>>;
            baseAmount: z.ZodNullable<z.ZodString>;
            finalAmount: z.ZodNullable<z.ZodString>;
            currency: z.ZodNullable<z.ZodString>;
            discount: z.ZodNullable<z.ZodObject<{
                proposalId: z.ZodString;
                type: z.ZodEnum<{
                    PERCENTAGE: "PERCENTAGE";
                    FIXED_AMOUNT: "FIXED_AMOUNT";
                }>;
                value: z.ZodString;
                amountOff: z.ZodString;
                startsAt: z.ZodString;
                endsAt: z.ZodString;
            }, z.core.$strip>>;
            payable: z.ZodBoolean;
            visible: z.ZodBoolean;
        }, z.core.$strip>>;
        pricingReference: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
        }, z.core.$strict>>;
        eligibilityCheckRequired: z.ZodLiteral<true>;
    }, z.core.$strict>;
    fullCollectionOffer: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        mode: z.ZodLiteral<"PAID_ON_REQUEST">;
        terms: z.ZodString;
    }, z.core.$strict>>>;
    stats: z.ZodObject<{
        viewCount: z.ZodNumber;
        downloadCount: z.ZodNumber;
        reviewCount: z.ZodNumber;
        rating: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    searchScore: z.ZodNullable<z.ZodNumber>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, z.core.$strict>;
export declare const DatasetImportedDescriptionSchema: z.ZodObject<{
    provenance: z.ZodLiteral<"LEGACY_DESCRIPTION">;
    importedAt: z.ZodString;
    modalities: z.ZodArray<z.ZodEnum<{
        TABULAR: "TABULAR";
        TEXT: "TEXT";
        IMAGE: "IMAGE";
        VIDEO: "VIDEO";
        AUDIO: "AUDIO";
        SENSOR: "SENSOR";
        CAD: "CAD";
    }>>;
    contexts: z.ZodArray<z.ZodEnum<{
        HEALTHCARE: "HEALTHCARE";
        EGOCENTRIC: "EGOCENTRIC";
    }>>;
    collectionBoundary: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"KNOWN">;
        description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"NOT_APPLICABLE">;
    }, z.core.$strict>], "state">>>;
    collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"KNOWN">;
        start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            precision: z.ZodLiteral<"YEAR">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"MONTH">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"DAY">;
            value: z.ZodISODate;
        }, z.core.$strict>], "precision">>>;
        end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            precision: z.ZodLiteral<"YEAR">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"MONTH">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"DAY">;
            value: z.ZodISODate;
        }, z.core.$strict>], "precision">>>;
        notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"NOT_APPLICABLE">;
    }, z.core.$strict>], "state">>>;
    profiles: z.ZodObject<{
        cad: z.ZodOptional<z.ZodObject<{
            modelScope: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            formatNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            assemblyStructure: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nativeSourceAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            parametricHistoryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>;
        tabular: z.ZodOptional<z.ZodObject<{
            unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
        }, z.core.$strict>>;
        audio: z.ZodOptional<z.ZodObject<{
            languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                SPEECH: "SPEECH";
                NON_SPEECH: "NON_SPEECH";
                MIXED: "MIXED";
            }>>>;
            transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                UNTIMED: "UNTIMED";
                TIMED: "TIMED";
            }>>>;
        }, z.core.$strict>>;
        images: z.ZodOptional<z.ZodObject<{
            coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>;
        video: z.ZodOptional<z.ZodObject<{
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                WHOLE_ITEM: "WHOLE_ITEM";
                TIME_OR_FRAME: "TIME_OR_FRAME";
            }>>>;
        }, z.core.$strict>>;
        text: z.ZodOptional<z.ZodObject<{
            languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                MIXED: "MIXED";
                HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                NON_LANGUAGE: "NON_LANGUAGE";
            }>>>;
        }, z.core.$strict>>;
        sensors: z.ZodOptional<z.ZodObject<{
            channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                NO_CLAIM: "NO_CLAIM";
                DESCRIBED: "DESCRIBED";
            }>>>;
        }, z.core.$strict>>;
        egocentric: z.ZodOptional<z.ZodObject<{
            mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>;
        healthcare: z.ZodOptional<z.ZodObject<{
            recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    tags: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetCatalogueCardSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    representation: z.ZodLiteral<"LEGACY">;
    legacy: z.ZodObject<{
        id: z.ZodString;
        datasetUniqueId: z.ZodString;
        title: z.ZodString;
        status: z.ZodLiteral<"PUBLISHED">;
        license: z.ZodString;
        owner: z.ZodObject<{
            id: z.ZodString;
            type: z.ZodEnum<{
                supplier: "supplier";
                platform: "platform";
            }>;
            name: z.ZodString;
            logoUrl: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>;
        category: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        secondaryCategories: z.ZodOptional<z.ZodArray<z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>>>;
        location: z.ZodNullable<z.ZodObject<{
            country: z.ZodString;
            state: z.ZodNullable<z.ZodString>;
            city: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>>;
        dataFormatInfo: z.ZodObject<{
            fileFormat: z.ZodNullable<z.ZodString>;
            rows: z.ZodNullable<z.ZodNumber>;
            cols: z.ZodNullable<z.ZodNumber>;
            fileSize: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        tags: z.ZodArray<z.ZodString>;
        isPaid: z.ZodBoolean;
        price: z.ZodNullable<z.ZodString>;
        currency: z.ZodEnum<{
            INR: "INR";
            USD: "USD";
            EUR: "EUR";
            GBP: "GBP";
        }>;
        accessFlow: z.ZodEnum<{
            FREE_CLAIM: "FREE_CLAIM";
            PAID_CHECKOUT: "PAID_CHECKOUT";
        }>;
        commercialFlow: z.ZodEnum<{
            NONE: "NONE";
            DIRECT_PLATFORM_PURCHASE: "DIRECT_PLATFORM_PURCHASE";
            INQUIRY_FOR_FULL_DATASET: "INQUIRY_FOR_FULL_DATASET";
        }>;
        accessPrice: z.ZodObject<{
            surface: z.ZodNullable<z.ZodEnum<{
                DATASET_PRICING: "DATASET_PRICING";
                SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
            }>>;
            baseAmount: z.ZodNullable<z.ZodString>;
            finalAmount: z.ZodNullable<z.ZodString>;
            currency: z.ZodNullable<z.ZodString>;
            discount: z.ZodNullable<z.ZodObject<{
                proposalId: z.ZodString;
                type: z.ZodEnum<{
                    PERCENTAGE: "PERCENTAGE";
                    FIXED_AMOUNT: "FIXED_AMOUNT";
                }>;
                value: z.ZodString;
                amountOff: z.ZodString;
                startsAt: z.ZodString;
                endsAt: z.ZodString;
            }, z.core.$strip>>;
            payable: z.ZodBoolean;
            visible: z.ZodBoolean;
        }, z.core.$strip>;
        commercialPrice: z.ZodObject<{
            surface: z.ZodNullable<z.ZodEnum<{
                DATASET_PRICING: "DATASET_PRICING";
                SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
            }>>;
            baseAmount: z.ZodNullable<z.ZodString>;
            finalAmount: z.ZodNullable<z.ZodString>;
            currency: z.ZodNullable<z.ZodString>;
            discount: z.ZodNullable<z.ZodObject<{
                proposalId: z.ZodString;
                type: z.ZodEnum<{
                    PERCENTAGE: "PERCENTAGE";
                    FIXED_AMOUNT: "FIXED_AMOUNT";
                }>;
                value: z.ZodString;
                amountOff: z.ZodString;
                startsAt: z.ZodString;
                endsAt: z.ZodString;
            }, z.core.$strip>>;
            payable: z.ZodBoolean;
            visible: z.ZodBoolean;
        }, z.core.$strip>;
        viewCount: z.ZodNumber;
        downloadCount: z.ZodNumber;
        reviewCount: z.ZodNumber;
        rating: z.ZodNullable<z.ZodString>;
        kdtsScore: z.ZodNullable<z.ZodString>;
        searchScore: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        isSample: z.ZodBoolean;
        sampleFileAvailable: z.ZodBoolean;
        sampleNotes: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            whySample: z.ZodString;
            actualDataSize: z.ZodString;
            completeness: z.ZodOptional<z.ZodString>;
            deliveryMechanism: z.ZodEnum<{
                OTHER: "OTHER";
                API: "API";
                FILE: "FILE";
            }>;
            deliveryMechanismNotes: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>>;
        actualPrice: z.ZodNullable<z.ZodString>;
        actualPriceCurrency: z.ZodNullable<z.ZodString>;
        buyInPartsAvailable: z.ZodBoolean;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
        structuredMetadata: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            provenance: z.ZodLiteral<"LEGACY_DESCRIPTION">;
            importedAt: z.ZodString;
            modalities: z.ZodArray<z.ZodEnum<{
                TABULAR: "TABULAR";
                TEXT: "TEXT";
                IMAGE: "IMAGE";
                VIDEO: "VIDEO";
                AUDIO: "AUDIO";
                SENSOR: "SENSOR";
                CAD: "CAD";
            }>>;
            contexts: z.ZodArray<z.ZodEnum<{
                HEALTHCARE: "HEALTHCARE";
                EGOCENTRIC: "EGOCENTRIC";
            }>>;
            collectionBoundary: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"KNOWN">;
                description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"NOT_APPLICABLE">;
            }, z.core.$strict>], "state">>>;
            collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"KNOWN">;
                start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    precision: z.ZodLiteral<"YEAR">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"MONTH">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"DAY">;
                    value: z.ZodISODate;
                }, z.core.$strict>], "precision">>>;
                end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    precision: z.ZodLiteral<"YEAR">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"MONTH">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"DAY">;
                    value: z.ZodISODate;
                }, z.core.$strict>], "precision">>>;
                notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"NOT_APPLICABLE">;
            }, z.core.$strict>], "state">>>;
            profiles: z.ZodObject<{
                cad: z.ZodOptional<z.ZodObject<{
                    modelScope: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    formatNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    assemblyStructure: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    nativeSourceAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    parametricHistoryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
                tabular: z.ZodOptional<z.ZodObject<{
                    unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                }, z.core.$strict>>;
                audio: z.ZodOptional<z.ZodObject<{
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        SPEECH: "SPEECH";
                        NON_SPEECH: "NON_SPEECH";
                        MIXED: "MIXED";
                    }>>>;
                    transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        UNTIMED: "UNTIMED";
                        TIMED: "TIMED";
                    }>>>;
                }, z.core.$strict>>;
                images: z.ZodOptional<z.ZodObject<{
                    coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
                video: z.ZodOptional<z.ZodObject<{
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        WHOLE_ITEM: "WHOLE_ITEM";
                        TIME_OR_FRAME: "TIME_OR_FRAME";
                    }>>>;
                }, z.core.$strict>>;
                text: z.ZodOptional<z.ZodObject<{
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        MIXED: "MIXED";
                        HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                        NON_LANGUAGE: "NON_LANGUAGE";
                    }>>>;
                }, z.core.$strict>>;
                sensors: z.ZodOptional<z.ZodObject<{
                    channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>>;
                    synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        NO_CLAIM: "NO_CLAIM";
                        DESCRIBED: "DESCRIBED";
                    }>>>;
                }, z.core.$strict>>;
                egocentric: z.ZodOptional<z.ZodObject<{
                    mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
                healthcare: z.ZodOptional<z.ZodObject<{
                    recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            tags: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>>;
    }, z.core.$strip>;
}, z.core.$strict>, z.ZodObject<{
    representation: z.ZodLiteral<"CONTENT">;
    item: z.ZodObject<{
        id: z.ZodString;
        datasetUniqueId: z.ZodString;
        title: z.ZodString;
        status: z.ZodLiteral<"PUBLISHED">;
        license: z.ZodString;
        owner: z.ZodObject<{
            id: z.ZodString;
            type: z.ZodEnum<{
                supplier: "supplier";
                platform: "platform";
            }>;
            name: z.ZodString;
            logoUrl: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>;
        publication: z.ZodObject<{
            id: z.ZodString;
            contentId: z.ZodString;
            publishedAt: z.ZodString;
        }, z.core.$strict>;
        overview: z.ZodString;
        uploadChoice: z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>;
        modalities: z.ZodArray<z.ZodEnum<{
            TABULAR: "TABULAR";
            TEXT: "TEXT";
            IMAGE: "IMAGE";
            VIDEO: "VIDEO";
            AUDIO: "AUDIO";
            SENSOR: "SENSOR";
            CAD: "CAD";
        }>>;
        contexts: z.ZodArray<z.ZodEnum<{
            HEALTHCARE: "HEALTHCARE";
            EGOCENTRIC: "EGOCENTRIC";
        }>>;
        category: z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>;
        categoryAtFreeze: z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>;
        categoryNameOrigin: z.ZodEnum<{
            CURRENT_CATEGORY: "CURRENT_CATEGORY";
            CAPTURED_CATEGORY: "CAPTURED_CATEGORY";
        }>;
        secondaryCategories: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>>;
        tags: z.ZodArray<z.ZodString>;
        measurements: z.ZodArray<z.ZodObject<{
            scope: z.ZodEnum<{
                REPRESENTED_COLLECTION: "REPRESENTED_COLLECTION";
                FULL_MATERIAL: "FULL_MATERIAL";
                SAMPLE_MATERIAL: "SAMPLE_MATERIAL";
            }>;
            origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
            values: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>;
        }, z.core.$strict>>;
        materials: z.ZodArray<z.ZodObject<{
            component: z.ZodEnum<{
                SAMPLE: "SAMPLE";
                FULL: "FULL";
            }>;
            origin: z.ZodLiteral<"SELECTED_PHYSICAL_FILES">;
            fileCount: z.ZodNumber;
            sizeBytes: z.ZodString;
        }, z.core.$strict>>;
        assessment: z.ZodObject<{
            score: z.ZodString;
            scope: z.ZodLiteral<"UPLOADED_COMPONENTS">;
            components: z.ZodArray<z.ZodEnum<{
                SAMPLE: "SAMPLE";
                FULL: "FULL";
            }>>;
            representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
        }, z.core.$strict>;
        purchase: z.ZodObject<{
            mode: z.ZodEnum<{
                FREE_CLAIM: "FREE_CLAIM";
                PAID_CHECKOUT: "PAID_CHECKOUT";
                UNAVAILABLE: "UNAVAILABLE";
                DISPLAY_ONLY: "DISPLAY_ONLY";
            }>;
            component: z.ZodNullable<z.ZodLiteral<"FULL">>;
            pricing: z.ZodNullable<z.ZodObject<{
                surface: z.ZodNullable<z.ZodEnum<{
                    DATASET_PRICING: "DATASET_PRICING";
                    SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
                }>>;
                baseAmount: z.ZodNullable<z.ZodString>;
                finalAmount: z.ZodNullable<z.ZodString>;
                currency: z.ZodNullable<z.ZodString>;
                discount: z.ZodNullable<z.ZodObject<{
                    proposalId: z.ZodString;
                    type: z.ZodEnum<{
                        PERCENTAGE: "PERCENTAGE";
                        FIXED_AMOUNT: "FIXED_AMOUNT";
                    }>;
                    value: z.ZodString;
                    amountOff: z.ZodString;
                    startsAt: z.ZodString;
                    endsAt: z.ZodString;
                }, z.core.$strip>>;
                payable: z.ZodBoolean;
                visible: z.ZodBoolean;
            }, z.core.$strip>>;
            pricingReference: z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                revision: z.ZodNumber;
            }, z.core.$strict>>;
            eligibilityCheckRequired: z.ZodLiteral<true>;
        }, z.core.$strict>;
        fullCollectionOffer: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            mode: z.ZodLiteral<"PAID_ON_REQUEST">;
            terms: z.ZodString;
        }, z.core.$strict>>>;
        stats: z.ZodObject<{
            viewCount: z.ZodNumber;
            downloadCount: z.ZodNumber;
            reviewCount: z.ZodNumber;
            rating: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        searchScore: z.ZodNullable<z.ZodNumber>;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>], "representation">;
export declare const DatasetCatalogueListResponseSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        representation: z.ZodLiteral<"LEGACY">;
        legacy: z.ZodObject<{
            id: z.ZodString;
            datasetUniqueId: z.ZodString;
            title: z.ZodString;
            status: z.ZodLiteral<"PUBLISHED">;
            license: z.ZodString;
            owner: z.ZodObject<{
                id: z.ZodString;
                type: z.ZodEnum<{
                    supplier: "supplier";
                    platform: "platform";
                }>;
                name: z.ZodString;
                logoUrl: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strip>;
            category: z.ZodObject<{
                name: z.ZodString;
            }, z.core.$strip>;
            secondaryCategories: z.ZodOptional<z.ZodArray<z.ZodObject<{
                name: z.ZodString;
            }, z.core.$strip>>>;
            location: z.ZodNullable<z.ZodObject<{
                country: z.ZodString;
                state: z.ZodNullable<z.ZodString>;
                city: z.ZodNullable<z.ZodString>;
            }, z.core.$strip>>;
            dataFormatInfo: z.ZodObject<{
                fileFormat: z.ZodNullable<z.ZodString>;
                rows: z.ZodNullable<z.ZodNumber>;
                cols: z.ZodNullable<z.ZodNumber>;
                fileSize: z.ZodNullable<z.ZodString>;
            }, z.core.$strip>;
            tags: z.ZodArray<z.ZodString>;
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
            accessFlow: z.ZodEnum<{
                FREE_CLAIM: "FREE_CLAIM";
                PAID_CHECKOUT: "PAID_CHECKOUT";
            }>;
            commercialFlow: z.ZodEnum<{
                NONE: "NONE";
                DIRECT_PLATFORM_PURCHASE: "DIRECT_PLATFORM_PURCHASE";
                INQUIRY_FOR_FULL_DATASET: "INQUIRY_FOR_FULL_DATASET";
            }>;
            accessPrice: z.ZodObject<{
                surface: z.ZodNullable<z.ZodEnum<{
                    DATASET_PRICING: "DATASET_PRICING";
                    SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
                }>>;
                baseAmount: z.ZodNullable<z.ZodString>;
                finalAmount: z.ZodNullable<z.ZodString>;
                currency: z.ZodNullable<z.ZodString>;
                discount: z.ZodNullable<z.ZodObject<{
                    proposalId: z.ZodString;
                    type: z.ZodEnum<{
                        PERCENTAGE: "PERCENTAGE";
                        FIXED_AMOUNT: "FIXED_AMOUNT";
                    }>;
                    value: z.ZodString;
                    amountOff: z.ZodString;
                    startsAt: z.ZodString;
                    endsAt: z.ZodString;
                }, z.core.$strip>>;
                payable: z.ZodBoolean;
                visible: z.ZodBoolean;
            }, z.core.$strip>;
            commercialPrice: z.ZodObject<{
                surface: z.ZodNullable<z.ZodEnum<{
                    DATASET_PRICING: "DATASET_PRICING";
                    SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
                }>>;
                baseAmount: z.ZodNullable<z.ZodString>;
                finalAmount: z.ZodNullable<z.ZodString>;
                currency: z.ZodNullable<z.ZodString>;
                discount: z.ZodNullable<z.ZodObject<{
                    proposalId: z.ZodString;
                    type: z.ZodEnum<{
                        PERCENTAGE: "PERCENTAGE";
                        FIXED_AMOUNT: "FIXED_AMOUNT";
                    }>;
                    value: z.ZodString;
                    amountOff: z.ZodString;
                    startsAt: z.ZodString;
                    endsAt: z.ZodString;
                }, z.core.$strip>>;
                payable: z.ZodBoolean;
                visible: z.ZodBoolean;
            }, z.core.$strip>;
            viewCount: z.ZodNumber;
            downloadCount: z.ZodNumber;
            reviewCount: z.ZodNumber;
            rating: z.ZodNullable<z.ZodString>;
            kdtsScore: z.ZodNullable<z.ZodString>;
            searchScore: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            isSample: z.ZodBoolean;
            sampleFileAvailable: z.ZodBoolean;
            sampleNotes: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                whySample: z.ZodString;
                actualDataSize: z.ZodString;
                completeness: z.ZodOptional<z.ZodString>;
                deliveryMechanism: z.ZodEnum<{
                    OTHER: "OTHER";
                    API: "API";
                    FILE: "FILE";
                }>;
                deliveryMechanismNotes: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>>>;
            actualPrice: z.ZodNullable<z.ZodString>;
            actualPriceCurrency: z.ZodNullable<z.ZodString>;
            buyInPartsAvailable: z.ZodBoolean;
            createdAt: z.ZodString;
            updatedAt: z.ZodString;
            structuredMetadata: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                provenance: z.ZodLiteral<"LEGACY_DESCRIPTION">;
                importedAt: z.ZodString;
                modalities: z.ZodArray<z.ZodEnum<{
                    TABULAR: "TABULAR";
                    TEXT: "TEXT";
                    IMAGE: "IMAGE";
                    VIDEO: "VIDEO";
                    AUDIO: "AUDIO";
                    SENSOR: "SENSOR";
                    CAD: "CAD";
                }>>;
                contexts: z.ZodArray<z.ZodEnum<{
                    HEALTHCARE: "HEALTHCARE";
                    EGOCENTRIC: "EGOCENTRIC";
                }>>;
                collectionBoundary: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    state: z.ZodLiteral<"KNOWN">;
                    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    state: z.ZodLiteral<"UNKNOWN">;
                }, z.core.$strict>, z.ZodObject<{
                    state: z.ZodLiteral<"NOT_APPLICABLE">;
                }, z.core.$strict>], "state">>>;
                collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    state: z.ZodLiteral<"KNOWN">;
                    start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                        precision: z.ZodLiteral<"YEAR">;
                        value: z.ZodString;
                    }, z.core.$strict>, z.ZodObject<{
                        precision: z.ZodLiteral<"MONTH">;
                        value: z.ZodString;
                    }, z.core.$strict>, z.ZodObject<{
                        precision: z.ZodLiteral<"DAY">;
                        value: z.ZodISODate;
                    }, z.core.$strict>], "precision">>>;
                    end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                        precision: z.ZodLiteral<"YEAR">;
                        value: z.ZodString;
                    }, z.core.$strict>, z.ZodObject<{
                        precision: z.ZodLiteral<"MONTH">;
                        value: z.ZodString;
                    }, z.core.$strict>, z.ZodObject<{
                        precision: z.ZodLiteral<"DAY">;
                        value: z.ZodISODate;
                    }, z.core.$strict>], "precision">>>;
                    notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    state: z.ZodLiteral<"UNKNOWN">;
                }, z.core.$strict>, z.ZodObject<{
                    state: z.ZodLiteral<"NOT_APPLICABLE">;
                }, z.core.$strict>], "state">>>;
                profiles: z.ZodObject<{
                    cad: z.ZodOptional<z.ZodObject<{
                        modelScope: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        formatNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        assemblyStructure: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        nativeSourceAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            PRESENT: "PRESENT";
                            ABSENT: "ABSENT";
                        }>>>;
                        parametricHistoryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            PRESENT: "PRESENT";
                            ABSENT: "ABSENT";
                        }>>>;
                        annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            PRESENT: "PRESENT";
                            ABSENT: "ABSENT";
                        }>>>;
                        annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>;
                    tabular: z.ZodOptional<z.ZodObject<{
                        unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            PRESENT: "PRESENT";
                            ABSENT: "ABSENT";
                        }>>>;
                    }, z.core.$strict>>;
                    audio: z.ZodOptional<z.ZodObject<{
                        languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                        annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            PRESENT: "PRESENT";
                            ABSENT: "ABSENT";
                        }>>>;
                        annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            PRESENT: "PRESENT";
                            ABSENT: "ABSENT";
                        }>>>;
                        transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            SPEECH: "SPEECH";
                            NON_SPEECH: "NON_SPEECH";
                            MIXED: "MIXED";
                        }>>>;
                        transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            UNTIMED: "UNTIMED";
                            TIMED: "TIMED";
                        }>>>;
                    }, z.core.$strict>>;
                    images: z.ZodOptional<z.ZodObject<{
                        coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            PRESENT: "PRESENT";
                            ABSENT: "ABSENT";
                        }>>>;
                        annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>;
                    video: z.ZodOptional<z.ZodObject<{
                        annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            PRESENT: "PRESENT";
                            ABSENT: "ABSENT";
                        }>>>;
                        annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            WHOLE_ITEM: "WHOLE_ITEM";
                            TIME_OR_FRAME: "TIME_OR_FRAME";
                        }>>>;
                    }, z.core.$strict>>;
                    text: z.ZodOptional<z.ZodObject<{
                        languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                        annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            PRESENT: "PRESENT";
                            ABSENT: "ABSENT";
                        }>>>;
                        annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            MIXED: "MIXED";
                            HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                            NON_LANGUAGE: "NON_LANGUAGE";
                        }>>>;
                    }, z.core.$strict>>;
                    sensors: z.ZodOptional<z.ZodObject<{
                        channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            PRESENT: "PRESENT";
                            ABSENT: "ABSENT";
                        }>>>;
                        calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            name: z.ZodString;
                            meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                            unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        }, z.core.$strict>>>;
                        synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                            UNKNOWN: "UNKNOWN";
                            NO_CLAIM: "NO_CLAIM";
                            DESCRIBED: "DESCRIBED";
                        }>>>;
                    }, z.core.$strict>>;
                    egocentric: z.ZodOptional<z.ZodObject<{
                        mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>;
                    healthcare: z.ZodOptional<z.ZodObject<{
                        recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                tags: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>>;
        }, z.core.$strip>;
    }, z.core.$strict>, z.ZodObject<{
        representation: z.ZodLiteral<"CONTENT">;
        item: z.ZodObject<{
            id: z.ZodString;
            datasetUniqueId: z.ZodString;
            title: z.ZodString;
            status: z.ZodLiteral<"PUBLISHED">;
            license: z.ZodString;
            owner: z.ZodObject<{
                id: z.ZodString;
                type: z.ZodEnum<{
                    supplier: "supplier";
                    platform: "platform";
                }>;
                name: z.ZodString;
                logoUrl: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strip>;
            publication: z.ZodObject<{
                id: z.ZodString;
                contentId: z.ZodString;
                publishedAt: z.ZodString;
            }, z.core.$strict>;
            overview: z.ZodString;
            uploadChoice: z.ZodEnum<{
                SAMPLE_ONLY: "SAMPLE_ONLY";
                FULL_ONLY: "FULL_ONLY";
                FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
            }>;
            modalities: z.ZodArray<z.ZodEnum<{
                TABULAR: "TABULAR";
                TEXT: "TEXT";
                IMAGE: "IMAGE";
                VIDEO: "VIDEO";
                AUDIO: "AUDIO";
                SENSOR: "SENSOR";
                CAD: "CAD";
            }>>;
            contexts: z.ZodArray<z.ZodEnum<{
                HEALTHCARE: "HEALTHCARE";
                EGOCENTRIC: "EGOCENTRIC";
            }>>;
            category: z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>;
            categoryAtFreeze: z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>;
            categoryNameOrigin: z.ZodEnum<{
                CURRENT_CATEGORY: "CURRENT_CATEGORY";
                CAPTURED_CATEGORY: "CAPTURED_CATEGORY";
            }>;
            secondaryCategories: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            tags: z.ZodArray<z.ZodString>;
            measurements: z.ZodArray<z.ZodObject<{
                scope: z.ZodEnum<{
                    REPRESENTED_COLLECTION: "REPRESENTED_COLLECTION";
                    FULL_MATERIAL: "FULL_MATERIAL";
                    SAMPLE_MATERIAL: "SAMPLE_MATERIAL";
                }>;
                origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
                values: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    state: z.ZodLiteral<"UNKNOWN">;
                    metric: z.ZodEnum<{
                        RECORD_COUNT: "RECORD_COUNT";
                        ROW_COUNT: "ROW_COUNT";
                        COLUMN_COUNT: "COLUMN_COUNT";
                        AUDIO_DURATION: "AUDIO_DURATION";
                        IMAGE_COUNT: "IMAGE_COUNT";
                        VIDEO_DURATION: "VIDEO_DURATION";
                        DOCUMENT_COUNT: "DOCUMENT_COUNT";
                        SESSION_COUNT: "SESSION_COUNT";
                        PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                        STREAM_COUNT: "STREAM_COUNT";
                        BYTE_SIZE: "BYTE_SIZE";
                    }>;
                    unit: z.ZodEnum<{
                        COUNT: "COUNT";
                        SECOND: "SECOND";
                        MINUTE: "MINUTE";
                        HOUR: "HOUR";
                        BYTE: "BYTE";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    state: z.ZodEnum<{
                        KNOWN: "KNOWN";
                        ESTIMATED: "ESTIMATED";
                    }>;
                    value: z.ZodString;
                    metric: z.ZodEnum<{
                        RECORD_COUNT: "RECORD_COUNT";
                        ROW_COUNT: "ROW_COUNT";
                        COLUMN_COUNT: "COLUMN_COUNT";
                        AUDIO_DURATION: "AUDIO_DURATION";
                        IMAGE_COUNT: "IMAGE_COUNT";
                        VIDEO_DURATION: "VIDEO_DURATION";
                        DOCUMENT_COUNT: "DOCUMENT_COUNT";
                        SESSION_COUNT: "SESSION_COUNT";
                        PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                        STREAM_COUNT: "STREAM_COUNT";
                        BYTE_SIZE: "BYTE_SIZE";
                    }>;
                    unit: z.ZodEnum<{
                        COUNT: "COUNT";
                        SECOND: "SECOND";
                        MINUTE: "MINUTE";
                        HOUR: "HOUR";
                        BYTE: "BYTE";
                    }>;
                }, z.core.$strict>], "state">>;
            }, z.core.$strict>>;
            materials: z.ZodArray<z.ZodObject<{
                component: z.ZodEnum<{
                    SAMPLE: "SAMPLE";
                    FULL: "FULL";
                }>;
                origin: z.ZodLiteral<"SELECTED_PHYSICAL_FILES">;
                fileCount: z.ZodNumber;
                sizeBytes: z.ZodString;
            }, z.core.$strict>>;
            assessment: z.ZodObject<{
                score: z.ZodString;
                scope: z.ZodLiteral<"UPLOADED_COMPONENTS">;
                components: z.ZodArray<z.ZodEnum<{
                    SAMPLE: "SAMPLE";
                    FULL: "FULL";
                }>>;
                representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
            }, z.core.$strict>;
            purchase: z.ZodObject<{
                mode: z.ZodEnum<{
                    FREE_CLAIM: "FREE_CLAIM";
                    PAID_CHECKOUT: "PAID_CHECKOUT";
                    UNAVAILABLE: "UNAVAILABLE";
                    DISPLAY_ONLY: "DISPLAY_ONLY";
                }>;
                component: z.ZodNullable<z.ZodLiteral<"FULL">>;
                pricing: z.ZodNullable<z.ZodObject<{
                    surface: z.ZodNullable<z.ZodEnum<{
                        DATASET_PRICING: "DATASET_PRICING";
                        SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
                    }>>;
                    baseAmount: z.ZodNullable<z.ZodString>;
                    finalAmount: z.ZodNullable<z.ZodString>;
                    currency: z.ZodNullable<z.ZodString>;
                    discount: z.ZodNullable<z.ZodObject<{
                        proposalId: z.ZodString;
                        type: z.ZodEnum<{
                            PERCENTAGE: "PERCENTAGE";
                            FIXED_AMOUNT: "FIXED_AMOUNT";
                        }>;
                        value: z.ZodString;
                        amountOff: z.ZodString;
                        startsAt: z.ZodString;
                        endsAt: z.ZodString;
                    }, z.core.$strip>>;
                    payable: z.ZodBoolean;
                    visible: z.ZodBoolean;
                }, z.core.$strip>>;
                pricingReference: z.ZodNullable<z.ZodObject<{
                    id: z.ZodString;
                    revision: z.ZodNumber;
                }, z.core.$strict>>;
                eligibilityCheckRequired: z.ZodLiteral<true>;
            }, z.core.$strict>;
            fullCollectionOffer: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                mode: z.ZodLiteral<"PAID_ON_REQUEST">;
                terms: z.ZodString;
            }, z.core.$strict>>>;
            stats: z.ZodObject<{
                viewCount: z.ZodNumber;
                downloadCount: z.ZodNumber;
                reviewCount: z.ZodNumber;
                rating: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
            searchScore: z.ZodNullable<z.ZodNumber>;
            createdAt: z.ZodString;
            updatedAt: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>], "representation">>;
    page: z.ZodNumber;
    pageSize: z.ZodNumber;
    total: z.ZodNumber;
}, z.core.$strict>;
export declare const DatasetCatalogueDetailResponseSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    representation: z.ZodLiteral<"LEGACY">;
    legacy: z.ZodObject<{
        dataset: z.ZodObject<{
            id: z.ZodString;
            datasetUniqueId: z.ZodString;
            title: z.ZodString;
            status: z.ZodLiteral<"PUBLISHED">;
            visibility: z.ZodEnum<{
                PUBLIC: "PUBLIC";
                PRIVATE: "PRIVATE";
                UNLISTED: "UNLISTED";
            }>;
            superType: z.ZodString;
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
            accessFlow: z.ZodEnum<{
                FREE_CLAIM: "FREE_CLAIM";
                PAID_CHECKOUT: "PAID_CHECKOUT";
            }>;
            commercialFlow: z.ZodEnum<{
                NONE: "NONE";
                DIRECT_PLATFORM_PURCHASE: "DIRECT_PLATFORM_PURCHASE";
                INQUIRY_FOR_FULL_DATASET: "INQUIRY_FOR_FULL_DATASET";
            }>;
            accessPrice: z.ZodObject<{
                surface: z.ZodNullable<z.ZodEnum<{
                    DATASET_PRICING: "DATASET_PRICING";
                    SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
                }>>;
                baseAmount: z.ZodNullable<z.ZodString>;
                finalAmount: z.ZodNullable<z.ZodString>;
                currency: z.ZodNullable<z.ZodString>;
                discount: z.ZodNullable<z.ZodObject<{
                    proposalId: z.ZodString;
                    type: z.ZodEnum<{
                        PERCENTAGE: "PERCENTAGE";
                        FIXED_AMOUNT: "FIXED_AMOUNT";
                    }>;
                    value: z.ZodString;
                    amountOff: z.ZodString;
                    startsAt: z.ZodString;
                    endsAt: z.ZodString;
                }, z.core.$strip>>;
                payable: z.ZodBoolean;
                visible: z.ZodBoolean;
            }, z.core.$strip>;
            commercialPrice: z.ZodObject<{
                surface: z.ZodNullable<z.ZodEnum<{
                    DATASET_PRICING: "DATASET_PRICING";
                    SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
                }>>;
                baseAmount: z.ZodNullable<z.ZodString>;
                finalAmount: z.ZodNullable<z.ZodString>;
                currency: z.ZodNullable<z.ZodString>;
                discount: z.ZodNullable<z.ZodObject<{
                    proposalId: z.ZodString;
                    type: z.ZodEnum<{
                        PERCENTAGE: "PERCENTAGE";
                        FIXED_AMOUNT: "FIXED_AMOUNT";
                    }>;
                    value: z.ZodString;
                    amountOff: z.ZodString;
                    startsAt: z.ZodString;
                    endsAt: z.ZodString;
                }, z.core.$strip>>;
                payable: z.ZodBoolean;
                visible: z.ZodBoolean;
            }, z.core.$strip>;
            license: z.ZodString;
            downloadCount: z.ZodNumber;
            viewCount: z.ZodNumber;
            rating: z.ZodNullable<z.ZodString>;
            createdAt: z.ZodString;
            updatedAt: z.ZodString;
            description: z.ZodNullable<z.ZodString>;
            isSample: z.ZodBoolean;
            sampleFileAvailable: z.ZodBoolean;
            sampleNotes: z.ZodNullable<z.ZodObject<{
                whySample: z.ZodString;
                actualDataSize: z.ZodString;
                completeness: z.ZodOptional<z.ZodString>;
                deliveryMechanism: z.ZodEnum<{
                    OTHER: "OTHER";
                    API: "API";
                    FILE: "FILE";
                }>;
                deliveryMechanismNotes: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>>;
            actualPrice: z.ZodNullable<z.ZodString>;
            actualPriceCurrency: z.ZodNullable<z.ZodString>;
            isNegotiable: z.ZodNullable<z.ZodBoolean>;
            buyInPartsAvailable: z.ZodBoolean;
        }, z.core.$strip>;
        primaryCategory: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        secondaryCategories: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>>;
        aboutDatasetInfo: z.ZodObject<{
            overview: z.ZodNullable<z.ZodString>;
            description: z.ZodNullable<z.ZodString>;
            dataQuality: z.ZodNullable<z.ZodString>;
            useCases: z.ZodNullable<z.ZodString>;
            limitations: z.ZodNullable<z.ZodString>;
            methodology: z.ZodNullable<z.ZodString>;
            updatedAt: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        dataFormatInfo: z.ZodObject<{
            fileFormat: z.ZodNullable<z.ZodString>;
            rows: z.ZodNullable<z.ZodNumber>;
            cols: z.ZodNullable<z.ZodNumber>;
            fileSize: z.ZodNullable<z.ZodString>;
            compressionType: z.ZodNullable<z.ZodString>;
            encoding: z.ZodNullable<z.ZodEnum<{
                "UTF-8": "UTF-8";
                "UTF-16": "UTF-16";
                "UTF-16LE": "UTF-16LE";
                "UTF-16BE": "UTF-16BE";
                "UTF-32": "UTF-32";
                ASCII: "ASCII";
                "ISO-8859-1": "ISO-8859-1";
                "WINDOWS-1252": "WINDOWS-1252";
                SHIFT_JIS: "SHIFT_JIS";
                GB18030: "GB18030";
            }>>;
            updatedAt: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        features: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
            dataType: z.ZodString;
            description: z.ZodNullable<z.ZodString>;
            isNullable: z.ZodBoolean;
        }, z.core.$strip>>;
        source: z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
            description: z.ZodNullable<z.ZodString>;
            websiteUrl: z.ZodNullable<z.ZodString>;
            isVerified: z.ZodBoolean;
        }, z.core.$strip>;
        locationInfo: z.ZodNullable<z.ZodObject<{
            region: z.ZodNullable<z.ZodString>;
            country: z.ZodString;
            state: z.ZodNullable<z.ZodString>;
            city: z.ZodNullable<z.ZodString>;
            coordinates: z.ZodNullable<z.ZodString>;
            coverage: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>>;
        tags: z.ZodArray<z.ZodString>;
        structuredMetadata: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            provenance: z.ZodLiteral<"LEGACY_DESCRIPTION">;
            importedAt: z.ZodString;
            modalities: z.ZodArray<z.ZodEnum<{
                TABULAR: "TABULAR";
                TEXT: "TEXT";
                IMAGE: "IMAGE";
                VIDEO: "VIDEO";
                AUDIO: "AUDIO";
                SENSOR: "SENSOR";
                CAD: "CAD";
            }>>;
            contexts: z.ZodArray<z.ZodEnum<{
                HEALTHCARE: "HEALTHCARE";
                EGOCENTRIC: "EGOCENTRIC";
            }>>;
            collectionBoundary: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"KNOWN">;
                description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"NOT_APPLICABLE">;
            }, z.core.$strict>], "state">>>;
            collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"KNOWN">;
                start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    precision: z.ZodLiteral<"YEAR">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"MONTH">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"DAY">;
                    value: z.ZodISODate;
                }, z.core.$strict>], "precision">>>;
                end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    precision: z.ZodLiteral<"YEAR">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"MONTH">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"DAY">;
                    value: z.ZodISODate;
                }, z.core.$strict>], "precision">>>;
                notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"NOT_APPLICABLE">;
            }, z.core.$strict>], "state">>>;
            profiles: z.ZodObject<{
                cad: z.ZodOptional<z.ZodObject<{
                    modelScope: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    formatNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    assemblyStructure: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    nativeSourceAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    parametricHistoryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
                tabular: z.ZodOptional<z.ZodObject<{
                    unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                }, z.core.$strict>>;
                audio: z.ZodOptional<z.ZodObject<{
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        SPEECH: "SPEECH";
                        NON_SPEECH: "NON_SPEECH";
                        MIXED: "MIXED";
                    }>>>;
                    transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        UNTIMED: "UNTIMED";
                        TIMED: "TIMED";
                    }>>>;
                }, z.core.$strict>>;
                images: z.ZodOptional<z.ZodObject<{
                    coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
                video: z.ZodOptional<z.ZodObject<{
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        WHOLE_ITEM: "WHOLE_ITEM";
                        TIME_OR_FRAME: "TIME_OR_FRAME";
                    }>>>;
                }, z.core.$strict>>;
                text: z.ZodOptional<z.ZodObject<{
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        MIXED: "MIXED";
                        HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                        NON_LANGUAGE: "NON_LANGUAGE";
                    }>>>;
                }, z.core.$strict>>;
                sensors: z.ZodOptional<z.ZodObject<{
                    channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>>;
                    synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        NO_CLAIM: "NO_CLAIM";
                        DESCRIBED: "DESCRIBED";
                    }>>>;
                }, z.core.$strict>>;
                egocentric: z.ZodOptional<z.ZodObject<{
                    mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
                healthcare: z.ZodOptional<z.ZodObject<{
                    recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            tags: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>>;
    }, z.core.$strip>;
}, z.core.$strict>, z.ZodObject<{
    representation: z.ZodLiteral<"CONTENT">;
    item: z.ZodObject<{
        id: z.ZodString;
        datasetUniqueId: z.ZodString;
        title: z.ZodString;
        status: z.ZodLiteral<"PUBLISHED">;
        license: z.ZodString;
        owner: z.ZodObject<{
            id: z.ZodString;
            type: z.ZodEnum<{
                supplier: "supplier";
                platform: "platform";
            }>;
            name: z.ZodString;
            logoUrl: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>;
        publication: z.ZodObject<{
            id: z.ZodString;
            contentId: z.ZodString;
            publishedAt: z.ZodString;
        }, z.core.$strict>;
        overview: z.ZodString;
        uploadChoice: z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>;
        modalities: z.ZodArray<z.ZodEnum<{
            TABULAR: "TABULAR";
            TEXT: "TEXT";
            IMAGE: "IMAGE";
            VIDEO: "VIDEO";
            AUDIO: "AUDIO";
            SENSOR: "SENSOR";
            CAD: "CAD";
        }>>;
        contexts: z.ZodArray<z.ZodEnum<{
            HEALTHCARE: "HEALTHCARE";
            EGOCENTRIC: "EGOCENTRIC";
        }>>;
        category: z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>;
        categoryAtFreeze: z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>;
        categoryNameOrigin: z.ZodEnum<{
            CURRENT_CATEGORY: "CURRENT_CATEGORY";
            CAPTURED_CATEGORY: "CAPTURED_CATEGORY";
        }>;
        secondaryCategories: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>>;
        tags: z.ZodArray<z.ZodString>;
        measurements: z.ZodArray<z.ZodObject<{
            scope: z.ZodEnum<{
                REPRESENTED_COLLECTION: "REPRESENTED_COLLECTION";
                FULL_MATERIAL: "FULL_MATERIAL";
                SAMPLE_MATERIAL: "SAMPLE_MATERIAL";
            }>;
            origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
            values: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>;
        }, z.core.$strict>>;
        materials: z.ZodArray<z.ZodObject<{
            component: z.ZodEnum<{
                SAMPLE: "SAMPLE";
                FULL: "FULL";
            }>;
            origin: z.ZodLiteral<"SELECTED_PHYSICAL_FILES">;
            fileCount: z.ZodNumber;
            sizeBytes: z.ZodString;
        }, z.core.$strict>>;
        assessment: z.ZodObject<{
            score: z.ZodString;
            scope: z.ZodLiteral<"UPLOADED_COMPONENTS">;
            components: z.ZodArray<z.ZodEnum<{
                SAMPLE: "SAMPLE";
                FULL: "FULL";
            }>>;
            representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
        }, z.core.$strict>;
        purchase: z.ZodObject<{
            mode: z.ZodEnum<{
                FREE_CLAIM: "FREE_CLAIM";
                PAID_CHECKOUT: "PAID_CHECKOUT";
                UNAVAILABLE: "UNAVAILABLE";
                DISPLAY_ONLY: "DISPLAY_ONLY";
            }>;
            component: z.ZodNullable<z.ZodLiteral<"FULL">>;
            pricing: z.ZodNullable<z.ZodObject<{
                surface: z.ZodNullable<z.ZodEnum<{
                    DATASET_PRICING: "DATASET_PRICING";
                    SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
                }>>;
                baseAmount: z.ZodNullable<z.ZodString>;
                finalAmount: z.ZodNullable<z.ZodString>;
                currency: z.ZodNullable<z.ZodString>;
                discount: z.ZodNullable<z.ZodObject<{
                    proposalId: z.ZodString;
                    type: z.ZodEnum<{
                        PERCENTAGE: "PERCENTAGE";
                        FIXED_AMOUNT: "FIXED_AMOUNT";
                    }>;
                    value: z.ZodString;
                    amountOff: z.ZodString;
                    startsAt: z.ZodString;
                    endsAt: z.ZodString;
                }, z.core.$strip>>;
                payable: z.ZodBoolean;
                visible: z.ZodBoolean;
            }, z.core.$strip>>;
            pricingReference: z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                revision: z.ZodNumber;
            }, z.core.$strict>>;
            eligibilityCheckRequired: z.ZodLiteral<true>;
        }, z.core.$strict>;
        fullCollectionOffer: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            mode: z.ZodLiteral<"PAID_ON_REQUEST">;
            terms: z.ZodString;
        }, z.core.$strict>>>;
        stats: z.ZodObject<{
            viewCount: z.ZodNumber;
            downloadCount: z.ZodNumber;
            reviewCount: z.ZodNumber;
            rating: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        searchScore: z.ZodNullable<z.ZodNumber>;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strict>;
    description: z.ZodObject<{
        title: z.ZodString;
        license: z.ZodString;
        overview: z.ZodString;
        description: z.ZodString;
        dataQuality: z.ZodString;
        collectionBoundary: z.ZodString;
        geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"KNOWN">;
            description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"NOT_APPLICABLE">;
        }, z.core.$strict>], "state">>>;
        collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"KNOWN">;
            start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                precision: z.ZodLiteral<"YEAR">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"MONTH">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"DAY">;
                value: z.ZodISODate;
            }, z.core.$strict>], "precision">>>;
            end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                precision: z.ZodLiteral<"YEAR">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"MONTH">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"DAY">;
                value: z.ZodISODate;
            }, z.core.$strict>], "precision">>>;
            notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"NOT_APPLICABLE">;
        }, z.core.$strict>], "state">>>;
        limitations: z.ZodNullable<z.ZodString>;
        methodology: z.ZodNullable<z.ZodString>;
        useCases: z.ZodNullable<z.ZodString>;
        uploadChoice: z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>;
        modalities: z.ZodArray<z.ZodEnum<{
            TABULAR: "TABULAR";
            TEXT: "TEXT";
            IMAGE: "IMAGE";
            VIDEO: "VIDEO";
            AUDIO: "AUDIO";
            SENSOR: "SENSOR";
            CAD: "CAD";
        }>>;
        contexts: z.ZodArray<z.ZodEnum<{
            HEALTHCARE: "HEALTHCARE";
            EGOCENTRIC: "EGOCENTRIC";
        }>>;
        studyStructure: z.ZodNullable<z.ZodString>;
        tags: z.ZodArray<z.ZodString>;
        categoriesAtFreeze: z.ZodObject<{
            primary: z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>;
            additional: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        sourceAtFreeze: z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
            description: z.ZodNullable<z.ZodString>;
            websiteUrl: z.ZodNullable<z.ZodString>;
            isVerifiedAtFreeze: z.ZodBoolean;
        }, z.core.$strict>;
        measurements: z.ZodArray<z.ZodObject<{
            scope: z.ZodEnum<{
                REPRESENTED_COLLECTION: "REPRESENTED_COLLECTION";
                FULL_MATERIAL: "FULL_MATERIAL";
                SAMPLE_MATERIAL: "SAMPLE_MATERIAL";
            }>;
            origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
            values: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>;
        }, z.core.$strict>>;
        sample: z.ZodNullable<z.ZodObject<{
            selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                DESCRIBED: "DESCRIBED";
                NONE_KNOWN: "NONE_KNOWN";
            }>>>;
            omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                DESCRIBED: "DESCRIBED";
                NONE_DECLARED: "NONE_DECLARED";
            }>>>;
            transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>;
        fullCompleteness: z.ZodNullable<z.ZodBoolean>;
        fullCollectionOffer: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            mode: z.ZodLiteral<"PAID_ON_REQUEST">;
            terms: z.ZodString;
        }, z.core.$strict>>>;
        profiles: z.ZodObject<{
            cad: z.ZodOptional<z.ZodObject<{
                modelScope: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                formatNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                assemblyStructure: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                nativeSourceAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                parametricHistoryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>;
            tabular: z.ZodOptional<z.ZodObject<{
                unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
            }, z.core.$strict>>;
            audio: z.ZodOptional<z.ZodObject<{
                languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    SPEECH: "SPEECH";
                    NON_SPEECH: "NON_SPEECH";
                    MIXED: "MIXED";
                }>>>;
                transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    UNTIMED: "UNTIMED";
                    TIMED: "TIMED";
                }>>>;
            }, z.core.$strict>>;
            images: z.ZodOptional<z.ZodObject<{
                coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>;
            video: z.ZodOptional<z.ZodObject<{
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    WHOLE_ITEM: "WHOLE_ITEM";
                    TIME_OR_FRAME: "TIME_OR_FRAME";
                }>>>;
            }, z.core.$strict>>;
            text: z.ZodOptional<z.ZodObject<{
                languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    MIXED: "MIXED";
                    HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                    NON_LANGUAGE: "NON_LANGUAGE";
                }>>>;
            }, z.core.$strict>>;
            sensors: z.ZodOptional<z.ZodObject<{
                channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    NO_CLAIM: "NO_CLAIM";
                    DESCRIBED: "DESCRIBED";
                }>>>;
            }, z.core.$strict>>;
            egocentric: z.ZodOptional<z.ZodObject<{
                mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>;
            healthcare: z.ZodOptional<z.ZodObject<{
                recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    currentCategoryFacts: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
    }, z.core.$strict>>;
    currentSourceFacts: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        isVerified: z.ZodBoolean;
    }, z.core.$strict>>;
}, z.core.$strict>], "representation">;
export type DatasetCatalogueListQuery = z.infer<typeof DatasetCatalogueListQuerySchema>;
export type DatasetCatalogueListResponse = z.infer<typeof DatasetCatalogueListResponseSchema>;
export type DatasetCanonicalCatalogueCard = z.infer<typeof DatasetCanonicalCatalogueCardSchema>;
export type DatasetCatalogueDetailResponse = z.infer<typeof DatasetCatalogueDetailResponseSchema>;
//# sourceMappingURL=catalogue.schema.d.ts.map