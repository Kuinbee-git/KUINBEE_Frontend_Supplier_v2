import { z } from "zod";
export declare const DatasetInspectionLeafProfileSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    profileId: z.ZodEnum<{
        UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
        UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
    }>;
    header: z.ZodEnum<{
        PRESENT: "PRESENT";
        ABSENT: "ABSENT";
    }>;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
    recordKind: z.ZodEnum<{
        OBJECT: "OBJECT";
        OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
    }>;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
}, z.core.$strict>], "profileId">;
export type DatasetInspectionLeafProfile = z.infer<typeof DatasetInspectionLeafProfileSchema>;
export declare const DatasetStrictInspectionProfileSchema: z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
    profileId: z.ZodEnum<{
        UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
        UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
    }>;
    header: z.ZodEnum<{
        PRESENT: "PRESENT";
        ABSENT: "ABSENT";
    }>;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
    recordKind: z.ZodEnum<{
        OBJECT: "OBJECT";
        OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
    }>;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
}, z.core.$strict>], "profileId">, z.ZodObject<{
    profileId: z.ZodLiteral<"ZIP32_CONTAINER_V1">;
    leafProfiles: z.ZodArray<z.ZodObject<{
        locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
            path: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"WORKBOOK_SHEET">;
            sheetName: z.ZodString;
        }, z.core.$strict>], "kind"> & z.ZodType<{
            kind: "ARCHIVE_ENTRY";
            path: string;
        }, {
            kind: "ARCHIVE_ENTRY";
            path: string;
        } | {
            kind: "WORKBOOK_SHEET";
            sheetName: string;
        }, z.core.$ZodTypeInternals<{
            kind: "ARCHIVE_ENTRY";
            path: string;
        }, {
            kind: "ARCHIVE_ENTRY";
            path: string;
        } | {
            kind: "WORKBOOK_SHEET";
            sheetName: string;
        }>>;
        profile: z.ZodDiscriminatedUnion<[z.ZodObject<{
            profileId: z.ZodEnum<{
                UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
                UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
            }>;
            header: z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
            recordKind: z.ZodEnum<{
                OBJECT: "OBJECT";
                OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
        }, z.core.$strict>], "profileId">;
    }, z.core.$strict>>;
    entryDefaults: z.ZodOptional<z.ZodArray<z.ZodObject<{
        extension: z.ZodString;
        profile: z.ZodDiscriminatedUnion<[z.ZodObject<{
            profileId: z.ZodEnum<{
                UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
                UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
            }>;
            header: z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
            recordKind: z.ZodEnum<{
                OBJECT: "OBJECT";
                OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
        }, z.core.$strict>], "profileId">;
    }, z.core.$strict>>>;
}, z.core.$strict>]>;
export declare const DatasetInspectionProfileSchema: z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
    profileId: z.ZodEnum<{
        UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
        UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
    }>;
    header: z.ZodEnum<{
        PRESENT: "PRESENT";
        ABSENT: "ABSENT";
    }>;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
    recordKind: z.ZodEnum<{
        OBJECT: "OBJECT";
        OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
    }>;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
}, z.core.$strict>], "profileId">, z.ZodObject<{
    profileId: z.ZodLiteral<"ZIP32_CONTAINER_V1">;
    leafProfiles: z.ZodArray<z.ZodObject<{
        locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
            path: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"WORKBOOK_SHEET">;
            sheetName: z.ZodString;
        }, z.core.$strict>], "kind"> & z.ZodType<{
            kind: "ARCHIVE_ENTRY";
            path: string;
        }, {
            kind: "ARCHIVE_ENTRY";
            path: string;
        } | {
            kind: "WORKBOOK_SHEET";
            sheetName: string;
        }, z.core.$ZodTypeInternals<{
            kind: "ARCHIVE_ENTRY";
            path: string;
        }, {
            kind: "ARCHIVE_ENTRY";
            path: string;
        } | {
            kind: "WORKBOOK_SHEET";
            sheetName: string;
        }>>;
        profile: z.ZodDiscriminatedUnion<[z.ZodObject<{
            profileId: z.ZodEnum<{
                UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
                UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
            }>;
            header: z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
            recordKind: z.ZodEnum<{
                OBJECT: "OBJECT";
                OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
        }, z.core.$strict>], "profileId">;
    }, z.core.$strict>>;
    entryDefaults: z.ZodOptional<z.ZodArray<z.ZodObject<{
        extension: z.ZodString;
        profile: z.ZodDiscriminatedUnion<[z.ZodObject<{
            profileId: z.ZodEnum<{
                UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
                UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
            }>;
            header: z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"UTF8_JSONL_SYNTAX_V1">;
            recordKind: z.ZodEnum<{
                OBJECT: "OBJECT";
                OBJECT_OR_ARRAY: "OBJECT_OR_ARRAY";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"RIFF_INTEGER_PCM_WAVE_V1">;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"PNG_STATIC_8BIT_V1">;
        }, z.core.$strict>, z.ZodObject<{
            profileId: z.ZodLiteral<"JPEG_BASELINE_STRUCTURE_V1">;
        }, z.core.$strict>], "profileId">;
    }, z.core.$strict>>>;
}, z.core.$strict>]>, z.ZodObject<{
    profileId: z.ZodLiteral<"MPEG_AUDIO_UPLOAD_V1">;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"ISO_BMFF_VIDEO_UPLOAD_V1">;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"UTF8_TEXT_UPLOAD_V1">;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"CAD_STEP_UPLOAD_V1">;
}, z.core.$strict>, z.ZodObject<{
    profileId: z.ZodLiteral<"CAD_IGES_UPLOAD_V1">;
}, z.core.$strict>]>;
export type DatasetInspectionProfile = z.infer<typeof DatasetInspectionProfileSchema>;
//# sourceMappingURL=inspectionProfile.schema.d.ts.map