import { z } from "zod";
export declare const CATALOGUE_IMPORT_VERSION: "private-catalogue-v1";
export declare const CATALOGUE_IMPORT_LIMITS: {
    readonly rows: 1000;
    readonly uploadBytes: number;
    readonly expandedBytes: number;
    readonly cells: 200000;
    readonly normalizedBytes: number;
    readonly privateBytes: 8192;
    readonly validationMs: 60000;
};
export declare const CatalogueIdentifierSchema: z.ZodString;
export declare const CatalogueDeclaredFormatsSchema: z.ZodObject<{
    state: z.ZodEnum<{
        UNCONFIRMED: "UNCONFIRMED";
        DECLARED: "DECLARED";
    }>;
    values: z.ZodOptional<z.ZodArray<z.ZodString>>;
    notes: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const CatalogueImportModeSchema: z.ZodEnum<{
    CREATE_MISSING: "CREATE_MISSING";
    UPDATE_EXISTING: "UPDATE_EXISTING";
}>;
export declare const CatalogueImportUploadBodySchema: z.ZodObject<{
    requestId: z.ZodString;
    version: z.ZodDefault<z.ZodLiteral<"private-catalogue-v1">>;
    mode: z.ZodDefault<z.ZodEnum<{
        CREATE_MISSING: "CREATE_MISSING";
        UPDATE_EXISTING: "UPDATE_EXISTING";
    }>>;
    files: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        contentBase64: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const CatalogueImportReviseBodySchema: z.ZodObject<{
    requestId: z.ZodString;
    expectedRevision: z.ZodNumber;
    rows: z.ZodArray<z.ZodObject<{
        rowId: z.ZodString;
        excluded: z.ZodOptional<z.ZodBoolean>;
        draftId: z.ZodOptional<z.ZodString>;
        replaceChannels: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const CatalogueImportCommitBodySchema: z.ZodObject<{
    requestId: z.ZodString;
    expectedRevision: z.ZodNumber;
    fingerprint: z.ZodString;
    acknowledgeUnmatchedDrafts: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export declare const CatalogueImportCancelBodySchema: z.ZodObject<{
    requestId: z.ZodString;
}, z.core.$strict>;
export declare const CatalogueEntryPatchBodySchema: z.ZodObject<{
    requestId: z.ZodString;
    expectedRevision: z.ZodNullable<z.ZodNumber>;
    expectedGeneration: z.ZodNumber;
    catalogueIdentifier: z.ZodString;
    declaredFormats: z.ZodOptional<z.ZodObject<{
        state: z.ZodEnum<{
            UNCONFIRMED: "UNCONFIRMED";
            DECLARED: "DECLARED";
        }>;
        values: z.ZodOptional<z.ZodArray<z.ZodString>>;
        notes: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const CatalogueEntryResponseSchema: z.ZodObject<{
    draftId: z.ZodString;
    catalogueIdentifier: z.ZodString;
    revision: z.ZodNumber;
    declaredFormats: z.ZodObject<{
        state: z.ZodEnum<{
            UNCONFIRMED: "UNCONFIRMED";
            DECLARED: "DECLARED";
        }>;
        values: z.ZodOptional<z.ZodArray<z.ZodString>>;
        notes: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    updatedAt: z.ZodString;
}, z.core.$strict>;
export declare const CatalogueImportRowResponseSchema: z.ZodObject<{
    id: z.ZodString;
    rowNumber: z.ZodNumber;
    catalogueIdentifier: z.ZodString;
    title: z.ZodString;
    operation: z.ZodEnum<{
        CREATE: "CREATE";
        BIND_EXISTING: "BIND_EXISTING";
        UPDATE: "UPDATE";
        UNCHANGED: "UNCHANGED";
    }>;
    status: z.ZodEnum<{
        PENDING: "PENDING";
        INVALID: "INVALID";
        CONFLICT: "CONFLICT";
        APPLIED: "APPLIED";
        SKIPPED: "SKIPPED";
        FAILED: "FAILED";
    }>;
    excluded: z.ZodBoolean;
    draftId: z.ZodNullable<z.ZodString>;
    expectedGeneration: z.ZodNullable<z.ZodNumber>;
    expectedCatalogueRevision: z.ZodNullable<z.ZodNumber>;
    changes: z.ZodArray<z.ZodObject<{
        field: z.ZodString;
        before: z.ZodUnknown;
        after: z.ZodUnknown;
    }, z.core.$strict>>;
    warnings: z.ZodArray<z.ZodString>;
    errors: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const CatalogueImportBatchResponseSchema: z.ZodObject<{
    id: z.ZodString;
    ownerId: z.ZodString;
    actorId: z.ZodString;
    administrative: z.ZodBoolean;
    version: z.ZodLiteral<"private-catalogue-v1">;
    mode: z.ZodEnum<{
        CREATE_MISSING: "CREATE_MISSING";
        UPDATE_EXISTING: "UPDATE_EXISTING";
    }>;
    status: z.ZodEnum<{
        FAILED: "FAILED";
        VALIDATING: "VALIDATING";
        NEEDS_CORRECTION: "NEEDS_CORRECTION";
        READY: "READY";
        RUNNING: "RUNNING";
        COMPLETED: "COMPLETED";
        COMPLETED_WITH_ERRORS: "COMPLETED_WITH_ERRORS";
        PAUSED: "PAUSED";
        CANCELLED: "CANCELLED";
        EXPIRED: "EXPIRED";
    }>;
    revision: z.ZodNumber;
    fingerprint: z.ZodString;
    unmatchedExistingDrafts: z.ZodNumber;
    createdAt: z.ZodString;
    expiresAt: z.ZodString;
    counts: z.ZodObject<{
        total: z.ZodNumber;
        creates: z.ZodNumber;
        bindings: z.ZodNumber;
        updates: z.ZodNumber;
        unchanged: z.ZodNumber;
        applied: z.ZodNumber;
        skipped: z.ZodNumber;
        invalid: z.ZodNumber;
        conflicts: z.ZodNumber;
        failed: z.ZodNumber;
        warnings: z.ZodNumber;
        excluded: z.ZodNumber;
    }, z.core.$strict>;
    rows: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        rowNumber: z.ZodNumber;
        catalogueIdentifier: z.ZodString;
        title: z.ZodString;
        operation: z.ZodEnum<{
            CREATE: "CREATE";
            BIND_EXISTING: "BIND_EXISTING";
            UPDATE: "UPDATE";
            UNCHANGED: "UNCHANGED";
        }>;
        status: z.ZodEnum<{
            PENDING: "PENDING";
            INVALID: "INVALID";
            CONFLICT: "CONFLICT";
            APPLIED: "APPLIED";
            SKIPPED: "SKIPPED";
            FAILED: "FAILED";
        }>;
        excluded: z.ZodBoolean;
        draftId: z.ZodNullable<z.ZodString>;
        expectedGeneration: z.ZodNullable<z.ZodNumber>;
        expectedCatalogueRevision: z.ZodNullable<z.ZodNumber>;
        changes: z.ZodArray<z.ZodObject<{
            field: z.ZodString;
            before: z.ZodUnknown;
            after: z.ZodUnknown;
        }, z.core.$strict>>;
        warnings: z.ZodArray<z.ZodString>;
        errors: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const CatalogueImportProgressResponseSchema: z.ZodObject<{
    version: z.ZodLiteral<"private-catalogue-v1">;
    mode: z.ZodEnum<{
        CREATE_MISSING: "CREATE_MISSING";
        UPDATE_EXISTING: "UPDATE_EXISTING";
    }>;
    fingerprint: z.ZodString;
    revision: z.ZodNumber;
    id: z.ZodString;
    status: z.ZodEnum<{
        FAILED: "FAILED";
        VALIDATING: "VALIDATING";
        NEEDS_CORRECTION: "NEEDS_CORRECTION";
        READY: "READY";
        RUNNING: "RUNNING";
        COMPLETED: "COMPLETED";
        COMPLETED_WITH_ERRORS: "COMPLETED_WITH_ERRORS";
        PAUSED: "PAUSED";
        CANCELLED: "CANCELLED";
        EXPIRED: "EXPIRED";
    }>;
    unmatchedExistingDrafts: z.ZodNumber;
    ownerId: z.ZodString;
    actorId: z.ZodString;
    administrative: z.ZodBoolean;
    createdAt: z.ZodString;
    expiresAt: z.ZodString;
    counts: z.ZodObject<{
        total: z.ZodNumber;
        creates: z.ZodNumber;
        bindings: z.ZodNumber;
        updates: z.ZodNumber;
        unchanged: z.ZodNumber;
        applied: z.ZodNumber;
        skipped: z.ZodNumber;
        invalid: z.ZodNumber;
        conflicts: z.ZodNumber;
        failed: z.ZodNumber;
        warnings: z.ZodNumber;
        excluded: z.ZodNumber;
    }, z.core.$strict>;
    rows: z.ZodArray<z.ZodObject<{
        draftId: z.ZodNullable<z.ZodString>;
        id: z.ZodString;
        status: z.ZodEnum<{
            PENDING: "PENDING";
            INVALID: "INVALID";
            CONFLICT: "CONFLICT";
            APPLIED: "APPLIED";
            SKIPPED: "SKIPPED";
            FAILED: "FAILED";
        }>;
        errors: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type CatalogueImportProgressResponse = z.infer<typeof CatalogueImportProgressResponseSchema>;
export declare const CatalogueImportListResponseSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        version: z.ZodLiteral<"private-catalogue-v1">;
        mode: z.ZodEnum<{
            CREATE_MISSING: "CREATE_MISSING";
            UPDATE_EXISTING: "UPDATE_EXISTING";
        }>;
        fingerprint: z.ZodString;
        revision: z.ZodNumber;
        id: z.ZodString;
        status: z.ZodEnum<{
            FAILED: "FAILED";
            VALIDATING: "VALIDATING";
            NEEDS_CORRECTION: "NEEDS_CORRECTION";
            READY: "READY";
            RUNNING: "RUNNING";
            COMPLETED: "COMPLETED";
            COMPLETED_WITH_ERRORS: "COMPLETED_WITH_ERRORS";
            PAUSED: "PAUSED";
            CANCELLED: "CANCELLED";
            EXPIRED: "EXPIRED";
        }>;
        unmatchedExistingDrafts: z.ZodNumber;
        ownerId: z.ZodString;
        actorId: z.ZodString;
        administrative: z.ZodBoolean;
        createdAt: z.ZodString;
        expiresAt: z.ZodString;
        counts: z.ZodObject<{
            total: z.ZodNumber;
            creates: z.ZodNumber;
            bindings: z.ZodNumber;
            updates: z.ZodNumber;
            unchanged: z.ZodNumber;
            applied: z.ZodNumber;
            skipped: z.ZodNumber;
            invalid: z.ZodNumber;
            conflicts: z.ZodNumber;
            failed: z.ZodNumber;
            warnings: z.ZodNumber;
            excluded: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const CatalogueImportTemplateResponseSchema: z.ZodObject<{
    version: z.ZodLiteral<"private-catalogue-v1">;
    files: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        contentBase64: z.ZodString;
        mimeType: z.ZodString;
    }, z.core.$strict>>;
    instructions: z.ZodOptional<z.ZodArray<z.ZodString>>;
    fields: z.ZodOptional<z.ZodArray<z.ZodObject<{
        field: z.ZodString;
        required: z.ZodBoolean;
        help: z.ZodString;
    }, z.core.$strict>>>;
    lookups: z.ZodOptional<z.ZodObject<{
        categories: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>;
        sources: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type CatalogueImportUploadBody = z.infer<typeof CatalogueImportUploadBodySchema>;
export type CatalogueImportReviseBody = z.infer<typeof CatalogueImportReviseBodySchema>;
export type CatalogueImportCommitBody = z.infer<typeof CatalogueImportCommitBodySchema>;
export type CatalogueImportBatchResponse = z.infer<typeof CatalogueImportBatchResponseSchema>;
export type CatalogueImportRowResponse = z.infer<typeof CatalogueImportRowResponseSchema>;
export type CatalogueEntryPatchBody = z.infer<typeof CatalogueEntryPatchBodySchema>;
export type CatalogueDeclaredFormats = z.infer<typeof CatalogueDeclaredFormatsSchema>;
//# sourceMappingURL=catalogueImport.schema.d.ts.map