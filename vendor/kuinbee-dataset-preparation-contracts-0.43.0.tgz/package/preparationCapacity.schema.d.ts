import { z } from "zod";
export declare const DATASET_PREPARATION_MAX_ALLOWANCE = 100000;
export declare const DatasetPreparationCapacityResponseSchema: z.ZodObject<{
    limit: z.ZodNumber;
    used: z.ZodNumber;
    remaining: z.ZodNumber;
    generation: z.ZodNumber;
    override: z.ZodNullable<z.ZodNumber>;
}, z.core.$strict>;
export declare const DatasetPreparationCapacityUpdateBodySchema: z.ZodObject<{
    requestId: z.ZodString;
    expectedGeneration: z.ZodNumber;
    limitOverride: z.ZodNullable<z.ZodNumber>;
    reason: z.ZodString;
}, z.core.$strict>;
export type DatasetPreparationCapacityResponse = z.infer<typeof DatasetPreparationCapacityResponseSchema>;
export type DatasetPreparationCapacityUpdateBody = z.infer<typeof DatasetPreparationCapacityUpdateBodySchema>;
//# sourceMappingURL=preparationCapacity.schema.d.ts.map