"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CatalogueImportTemplateResponseSchema = exports.CatalogueImportListResponseSchema = exports.CatalogueImportProgressResponseSchema = exports.CatalogueImportBatchResponseSchema = exports.CatalogueImportRowResponseSchema = exports.CatalogueEntryResponseSchema = exports.CatalogueEntryPatchBodySchema = exports.CatalogueImportCancelBodySchema = exports.CatalogueImportCommitBodySchema = exports.CatalogueImportReviseBodySchema = exports.CatalogueImportUploadBodySchema = exports.CatalogueImportModeSchema = exports.CatalogueDeclaredFormatsSchema = exports.CatalogueIdentifierSchema = exports.CATALOGUE_IMPORT_LIMITS = exports.CATALOGUE_IMPORT_VERSION = void 0;
const zod_1 = require("zod");
exports.CATALOGUE_IMPORT_VERSION = "private-catalogue-v1";
exports.CATALOGUE_IMPORT_LIMITS = {
    rows: 1000,
    uploadBytes: 32 * 1024 * 1024,
    expandedBytes: 128 * 1024 * 1024,
    cells: 200_000,
    normalizedBytes: 64 * 1024 * 1024,
    privateBytes: 8192,
    validationMs: 60_000,
};
const id = zod_1.z.string().cuid();
const revision = zod_1.z.number().int().nonnegative();
const requestId = zod_1.z.string().uuid();
exports.CatalogueIdentifierSchema = zod_1.z
    .string()
    .trim()
    .min(1)
    .max(200)
    .refine((value) => [...value].every((character) => character.charCodeAt(0) >= 32 && character.charCodeAt(0) !== 127), "Identifiers cannot contain control characters");
exports.CatalogueDeclaredFormatsSchema = zod_1.z
    .object({
    state: zod_1.z.enum(["UNCONFIRMED", "DECLARED"]),
    values: zod_1.z
        .array(zod_1.z.string().trim().min(1).max(100))
        .max(30)
        .refine((values) => new Set(values).size === values.length, "Formats must be unique")
        .optional(),
    notes: zod_1.z.string().trim().max(2000).optional(),
})
    .strict()
    .refine((value) => value.state !== "DECLARED" || Boolean(value.values?.length), "Declared formats require at least one format")
    .refine((value) => value.state !== "UNCONFIRMED" || !value.values?.length, "Unconfirmed formats cannot assert known formats");
exports.CatalogueImportModeSchema = zod_1.z.enum([
    "CREATE_MISSING",
    "UPDATE_EXISTING",
]);
exports.CatalogueImportUploadBodySchema = zod_1.z
    .object({
    requestId,
    version: zod_1.z
        .literal(exports.CATALOGUE_IMPORT_VERSION)
        .default(exports.CATALOGUE_IMPORT_VERSION),
    mode: exports.CatalogueImportModeSchema.default("CREATE_MISSING"),
    files: zod_1.z
        .array(zod_1.z
        .object({
        name: zod_1.z.string().min(1).max(200),
        contentBase64: zod_1.z
            .string()
            .min(1)
            .max(Math.ceil(exports.CATALOGUE_IMPORT_LIMITS.uploadBytes / 3) * 4 + 4),
    })
        .strict())
        .min(1)
        .max(3),
})
    .strict();
exports.CatalogueImportReviseBodySchema = zod_1.z
    .object({
    requestId,
    expectedRevision: revision,
    rows: zod_1.z
        .array(zod_1.z
        .object({
        rowId: id,
        excluded: zod_1.z.boolean().optional(),
        draftId: id.optional(),
        replaceChannels: zod_1.z.boolean().optional(),
    })
        .strict())
        .min(1)
        .max(1000),
})
    .strict();
exports.CatalogueImportCommitBodySchema = zod_1.z
    .object({
    requestId,
    expectedRevision: revision,
    fingerprint: zod_1.z.string().regex(/^[a-f0-9]{64}$/),
    acknowledgeUnmatchedDrafts: zod_1.z.boolean().optional(),
})
    .strict();
exports.CatalogueImportCancelBodySchema = zod_1.z.object({ requestId }).strict();
exports.CatalogueEntryPatchBodySchema = zod_1.z
    .object({
    requestId,
    expectedRevision: revision.nullable(),
    expectedGeneration: revision,
    catalogueIdentifier: exports.CatalogueIdentifierSchema,
    declaredFormats: exports.CatalogueDeclaredFormatsSchema.optional(),
})
    .strict();
exports.CatalogueEntryResponseSchema = zod_1.z
    .object({
    draftId: id,
    catalogueIdentifier: exports.CatalogueIdentifierSchema,
    revision,
    declaredFormats: exports.CatalogueDeclaredFormatsSchema,
    updatedAt: zod_1.z.string().datetime(),
})
    .strict();
exports.CatalogueImportRowResponseSchema = zod_1.z
    .object({
    id,
    rowNumber: zod_1.z.number().int().positive(),
    catalogueIdentifier: zod_1.z.string(),
    title: zod_1.z.string(),
    operation: zod_1.z.enum(["CREATE", "BIND_EXISTING", "UPDATE", "UNCHANGED"]),
    status: zod_1.z.enum([
        "PENDING",
        "INVALID",
        "CONFLICT",
        "APPLIED",
        "SKIPPED",
        "FAILED",
    ]),
    excluded: zod_1.z.boolean(),
    draftId: id.nullable(),
    expectedGeneration: revision.nullable(),
    expectedCatalogueRevision: revision.nullable(),
    changes: zod_1.z
        .array(zod_1.z
        .object({
        field: zod_1.z.string(),
        before: zod_1.z.unknown(),
        after: zod_1.z.unknown(),
    })
        .strict())
        .max(250),
    warnings: zod_1.z.array(zod_1.z.string()).max(100),
    errors: zod_1.z.array(zod_1.z.string()).max(100),
})
    .strict();
exports.CatalogueImportBatchResponseSchema = zod_1.z
    .object({
    id,
    ownerId: zod_1.z.string(),
    actorId: zod_1.z.string(),
    administrative: zod_1.z.boolean(),
    version: zod_1.z.literal(exports.CATALOGUE_IMPORT_VERSION),
    mode: exports.CatalogueImportModeSchema,
    status: zod_1.z.enum([
        "VALIDATING",
        "NEEDS_CORRECTION",
        "READY",
        "RUNNING",
        "COMPLETED",
        "COMPLETED_WITH_ERRORS",
        "PAUSED",
        "CANCELLED",
        "FAILED",
        "EXPIRED",
    ]),
    revision,
    fingerprint: zod_1.z.string(),
    unmatchedExistingDrafts: revision,
    createdAt: zod_1.z.string().datetime(),
    expiresAt: zod_1.z.string().datetime(),
    counts: zod_1.z
        .object({
        total: revision,
        creates: revision,
        bindings: revision,
        updates: revision,
        unchanged: revision,
        applied: revision,
        skipped: revision,
        invalid: revision,
        conflicts: revision,
        failed: revision,
        warnings: revision,
        excluded: revision,
    })
        .strict(),
    rows: zod_1.z.array(exports.CatalogueImportRowResponseSchema).max(1000),
})
    .strict();
exports.CatalogueImportProgressResponseSchema = exports.CatalogueImportBatchResponseSchema.omit({ rows: true }).extend({
    rows: zod_1.z.array(exports.CatalogueImportRowResponseSchema.pick({ id: true, status: true, draftId: true, errors: true })).max(1000),
}).strict();
exports.CatalogueImportListResponseSchema = zod_1.z
    .object({
    items: zod_1.z
        .array(exports.CatalogueImportBatchResponseSchema.omit({ rows: true }))
        .max(50),
})
    .strict();
exports.CatalogueImportTemplateResponseSchema = zod_1.z
    .object({
    version: zod_1.z.literal(exports.CATALOGUE_IMPORT_VERSION),
    files: zod_1.z
        .array(zod_1.z
        .object({
        name: zod_1.z.string(),
        contentBase64: zod_1.z.string(),
        mimeType: zod_1.z.string(),
    })
        .strict())
        .max(3),
    instructions: zod_1.z.array(zod_1.z.string()).optional(),
    fields: zod_1.z
        .array(zod_1.z
        .object({
        field: zod_1.z.string(),
        required: zod_1.z.boolean(),
        help: zod_1.z.string(),
    })
        .strict())
        .optional(),
    lookups: zod_1.z
        .object({
        categories: zod_1.z.array(zod_1.z.object({ id: zod_1.z.string(), name: zod_1.z.string() }).strict()),
        sources: zod_1.z.array(zod_1.z.object({ id: zod_1.z.string(), name: zod_1.z.string() }).strict()),
    })
        .strict()
        .optional(),
})
    .strict();
