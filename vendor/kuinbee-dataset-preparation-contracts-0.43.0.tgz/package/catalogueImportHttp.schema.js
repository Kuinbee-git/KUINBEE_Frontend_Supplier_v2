"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetCatalogueDraftCandidatesResponseSchema = exports.DatasetCatalogueDraftCandidatesQuerySchema = void 0;
const zod_1 = require("zod");
exports.DatasetCatalogueDraftCandidatesQuerySchema = zod_1.z.object({
    page: zod_1.z.coerce.number().int().min(1).max(10000).default(1),
    limit: zod_1.z.coerce.number().int().min(1).max(50).default(50),
    q: zod_1.z.string().trim().max(200).optional(),
}).strict();
exports.DatasetCatalogueDraftCandidatesResponseSchema = zod_1.z.object({
    items: zod_1.z.array(zod_1.z.object({ id: zod_1.z.string().cuid(), title: zod_1.z.string(), generation: zod_1.z.number().int().nonnegative(),
        catalogueIdentifier: zod_1.z.string().nullable(), catalogueRevision: zod_1.z.number().int().nonnegative().nullable(),
    }).strict()).max(50),
    page: zod_1.z.number().int().positive(), limit: zod_1.z.number().int().min(1).max(50), total: zod_1.z.number().int().nonnegative(),
}).strict();
