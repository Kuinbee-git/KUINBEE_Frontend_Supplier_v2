import { z } from "zod";
export declare const DatasetReferenceColumnPreviewSchema: z.ZodObject<{
    id: z.ZodString;
    position: z.ZodNumber;
    namePreview: z.ZodNullable<z.ZodString>;
    nameTruncated: z.ZodBoolean;
}, z.core.$strict>;
export declare const DatasetTableReferenceDefinitionSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"KEY">;
    keyKind: z.ZodNullable<z.ZodEnum<{
        PRIMARY: "PRIMARY";
        UNIQUE: "UNIQUE";
    }>>;
    columnIds: z.ZodArray<z.ZodString>;
    label: z.ZodNullable<z.ZodString>;
    notes: z.ZodNullable<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"JOIN">;
    target: z.ZodNullable<z.ZodObject<{
        memberId: z.ZodString;
        tableId: z.ZodString;
    }, z.core.$strict>>;
    pairs: z.ZodArray<z.ZodObject<{
        sourceColumnId: z.ZodString;
        targetColumnId: z.ZodString;
    }, z.core.$strict>>;
    cardinality: z.ZodNullable<z.ZodEnum<{
        UNKNOWN: "UNKNOWN";
        ONE_TO_ONE: "ONE_TO_ONE";
        ONE_TO_MANY: "ONE_TO_MANY";
        MANY_TO_ONE: "MANY_TO_ONE";
        MANY_TO_MANY: "MANY_TO_MANY";
    }>>;
    label: z.ZodNullable<z.ZodString>;
    notes: z.ZodNullable<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"DICTIONARY">;
    state: z.ZodNullable<z.ZodEnum<{
        INCLUDED: "INCLUDED";
        NOT_INCLUDED: "NOT_INCLUDED";
    }>>;
    target: z.ZodNullable<z.ZodObject<{
        memberId: z.ZodString;
        logicalEntryId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    notes: z.ZodNullable<z.ZodString>;
}, z.core.$strict>], "kind">;
export declare const DatasetTableReferenceOperationSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    definition: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"KEY">;
        keyKind: z.ZodNullable<z.ZodEnum<{
            PRIMARY: "PRIMARY";
            UNIQUE: "UNIQUE";
        }>>;
        columnIds: z.ZodArray<z.ZodString>;
        label: z.ZodNullable<z.ZodString>;
        notes: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"JOIN">;
        target: z.ZodNullable<z.ZodObject<{
            memberId: z.ZodString;
            tableId: z.ZodString;
        }, z.core.$strict>>;
        pairs: z.ZodArray<z.ZodObject<{
            sourceColumnId: z.ZodString;
            targetColumnId: z.ZodString;
        }, z.core.$strict>>;
        cardinality: z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            ONE_TO_ONE: "ONE_TO_ONE";
            ONE_TO_MANY: "ONE_TO_MANY";
            MANY_TO_ONE: "MANY_TO_ONE";
            MANY_TO_MANY: "MANY_TO_MANY";
        }>>;
        label: z.ZodNullable<z.ZodString>;
        notes: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"DICTIONARY">;
        state: z.ZodNullable<z.ZodEnum<{
            INCLUDED: "INCLUDED";
            NOT_INCLUDED: "NOT_INCLUDED";
        }>>;
        target: z.ZodNullable<z.ZodObject<{
            memberId: z.ZodString;
            logicalEntryId: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
        notes: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>], "kind">;
    memberId: z.ZodString;
    tableId: z.ZodString;
    operation: z.ZodLiteral<"PUT_REFERENCE">;
    referenceId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"REMOVE_REFERENCE">;
    referenceId: z.ZodString;
}, z.core.$strict>], "operation">;
export declare const DatasetTableReferencesMutationBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedContentId: z.ZodString;
    expectedGeneration: z.ZodNumber;
    expectedPreparationGeneration: z.ZodNumber;
    editContext: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodLiteral<"EXISTING_DRAFT">;
        expectedContentId: z.ZodString;
        expectedGeneration: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"INITIALIZE">;
        expectedWorkflowRevision: z.ZodNumber;
        context: z.ZodEnum<{
            REQUESTED_CHANGES: "REQUESTED_CHANGES";
            MANAGED_EDIT: "MANAGED_EDIT";
            APPROVED_REEDIT: "APPROVED_REEDIT";
            PLATFORM_WITHDRAWAL: "PLATFORM_WITHDRAWAL";
            PLATFORM_PUBLISHED_METADATA: "PLATFORM_PUBLISHED_METADATA";
        }>;
        expectedBaseContentId: z.ZodString;
    }, z.core.$strict>], "mode">>;
    operations: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        definition: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"KEY">;
            keyKind: z.ZodNullable<z.ZodEnum<{
                PRIMARY: "PRIMARY";
                UNIQUE: "UNIQUE";
            }>>;
            columnIds: z.ZodArray<z.ZodString>;
            label: z.ZodNullable<z.ZodString>;
            notes: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"JOIN">;
            target: z.ZodNullable<z.ZodObject<{
                memberId: z.ZodString;
                tableId: z.ZodString;
            }, z.core.$strict>>;
            pairs: z.ZodArray<z.ZodObject<{
                sourceColumnId: z.ZodString;
                targetColumnId: z.ZodString;
            }, z.core.$strict>>;
            cardinality: z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                ONE_TO_ONE: "ONE_TO_ONE";
                ONE_TO_MANY: "ONE_TO_MANY";
                MANY_TO_ONE: "MANY_TO_ONE";
                MANY_TO_MANY: "MANY_TO_MANY";
            }>>;
            label: z.ZodNullable<z.ZodString>;
            notes: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DICTIONARY">;
            state: z.ZodNullable<z.ZodEnum<{
                INCLUDED: "INCLUDED";
                NOT_INCLUDED: "NOT_INCLUDED";
            }>>;
            target: z.ZodNullable<z.ZodObject<{
                memberId: z.ZodString;
                logicalEntryId: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>>;
            notes: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>], "kind">;
        memberId: z.ZodString;
        tableId: z.ZodString;
        operation: z.ZodLiteral<"PUT_REFERENCE">;
        referenceId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"REMOVE_REFERENCE">;
        referenceId: z.ZodString;
    }, z.core.$strict>], "operation">>;
}, z.core.$strict>;
export declare const DatasetTableReferencesPageQuerySchema: z.ZodObject<{
    contentId: z.ZodString;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    expectedPreparationGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    component: z.ZodOptional<z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>>;
    memberId: z.ZodOptional<z.ZodString>;
    tableId: z.ZodOptional<z.ZodString>;
    kind: z.ZodOptional<z.ZodEnum<{
        KEY: "KEY";
        JOIN: "JOIN";
        DICTIONARY: "DICTIONARY";
    }>>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export declare const DatasetTableReferenceItemSchema: z.ZodObject<{
    component: z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>;
    definition: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"KEY">;
        keyKind: z.ZodNullable<z.ZodEnum<{
            PRIMARY: "PRIMARY";
            UNIQUE: "UNIQUE";
        }>>;
        columnIds: z.ZodArray<z.ZodString>;
        label: z.ZodNullable<z.ZodString>;
        notes: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"JOIN">;
        target: z.ZodNullable<z.ZodObject<{
            memberId: z.ZodString;
            tableId: z.ZodString;
        }, z.core.$strict>>;
        pairs: z.ZodArray<z.ZodObject<{
            sourceColumnId: z.ZodString;
            targetColumnId: z.ZodString;
        }, z.core.$strict>>;
        cardinality: z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            ONE_TO_ONE: "ONE_TO_ONE";
            ONE_TO_MANY: "ONE_TO_MANY";
            MANY_TO_ONE: "MANY_TO_ONE";
            MANY_TO_MANY: "MANY_TO_MANY";
        }>>;
        label: z.ZodNullable<z.ZodString>;
        notes: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"DICTIONARY">;
        state: z.ZodNullable<z.ZodEnum<{
            INCLUDED: "INCLUDED";
            NOT_INCLUDED: "NOT_INCLUDED";
        }>>;
        target: z.ZodNullable<z.ZodObject<{
            memberId: z.ZodString;
            logicalEntryId: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
        notes: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>], "kind">;
    origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
    columns: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        position: z.ZodNumber;
        namePreview: z.ZodNullable<z.ZodString>;
        nameTruncated: z.ZodBoolean;
    }, z.core.$strict>>;
    targetLabel: z.ZodNullable<z.ZodString>;
    memberId: z.ZodString;
    tableId: z.ZodString;
    id: z.ZodString;
}, z.core.$strict>;
export declare const DatasetTableReferencesPageResponseSchema: z.ZodObject<{
    contentId: z.ZodString;
    contentGeneration: z.ZodNumber;
    preparationGeneration: z.ZodNumber;
    frozen: z.ZodBoolean;
    items: z.ZodArray<z.ZodObject<{
        component: z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>;
        definition: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"KEY">;
            keyKind: z.ZodNullable<z.ZodEnum<{
                PRIMARY: "PRIMARY";
                UNIQUE: "UNIQUE";
            }>>;
            columnIds: z.ZodArray<z.ZodString>;
            label: z.ZodNullable<z.ZodString>;
            notes: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"JOIN">;
            target: z.ZodNullable<z.ZodObject<{
                memberId: z.ZodString;
                tableId: z.ZodString;
            }, z.core.$strict>>;
            pairs: z.ZodArray<z.ZodObject<{
                sourceColumnId: z.ZodString;
                targetColumnId: z.ZodString;
            }, z.core.$strict>>;
            cardinality: z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                ONE_TO_ONE: "ONE_TO_ONE";
                ONE_TO_MANY: "ONE_TO_MANY";
                MANY_TO_ONE: "MANY_TO_ONE";
                MANY_TO_MANY: "MANY_TO_MANY";
            }>>;
            label: z.ZodNullable<z.ZodString>;
            notes: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DICTIONARY">;
            state: z.ZodNullable<z.ZodEnum<{
                INCLUDED: "INCLUDED";
                NOT_INCLUDED: "NOT_INCLUDED";
            }>>;
            target: z.ZodNullable<z.ZodObject<{
                memberId: z.ZodString;
                logicalEntryId: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>>;
            notes: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>], "kind">;
        origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
        columns: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            position: z.ZodNumber;
            namePreview: z.ZodNullable<z.ZodString>;
            nameTruncated: z.ZodBoolean;
        }, z.core.$strict>>;
        targetLabel: z.ZodNullable<z.ZodString>;
        memberId: z.ZodString;
        tableId: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        contentId: z.ZodString;
        contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
        expectedPreparationGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
        component: z.ZodOptional<z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>>;
        memberId: z.ZodOptional<z.ZodString>;
        tableId: z.ZodOptional<z.ZodString>;
        kind: z.ZodOptional<z.ZodEnum<{
            KEY: "KEY";
            JOIN: "JOIN";
            DICTIONARY: "DICTIONARY";
        }>>;
        afterId: z.ZodOptional<z.ZodString>;
        limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetTableReferencesMutationResponseSchema: z.ZodObject<{
    requestId: z.ZodString;
    contentId: z.ZodString;
    generation: z.ZodNumber;
    preparationGeneration: z.ZodNumber;
    results: z.ZodArray<z.ZodObject<{
        index: z.ZodNumber;
        operation: z.ZodEnum<{
            PUT_REFERENCE: "PUT_REFERENCE";
            REMOVE_REFERENCE: "REMOVE_REFERENCE";
        }>;
        referenceId: z.ZodString;
        memberId: z.ZodString;
        tableId: z.ZodString;
        targetMemberId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type DatasetTableReferenceDefinition = z.infer<typeof DatasetTableReferenceDefinitionSchema>;
export type DatasetTableReferencesMutationBody = z.infer<typeof DatasetTableReferencesMutationBodySchema>;
export type DatasetTableReferencesPageQuery = z.infer<typeof DatasetTableReferencesPageQuerySchema>;
export type DatasetTableReferencesPageResponse = z.infer<typeof DatasetTableReferencesPageResponseSchema>;
export type DatasetTableReferencesMutationResponse = z.infer<typeof DatasetTableReferencesMutationResponseSchema>;
export declare const DatasetTableReferenceTargetsQuerySchema: z.ZodObject<{
    targetMemberId: z.ZodString;
    kind: z.ZodEnum<{
        JOIN: "JOIN";
        DICTIONARY: "DICTIONARY";
    }>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    memberId: z.ZodString;
    tableId: z.ZodString;
    contentId: z.ZodString;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    expectedPreparationGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
}, z.core.$strict>;
export declare const DatasetTableReferenceTargetSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"TABLE">;
    id: z.ZodString;
    logicalEntryId: z.ZodNullable<z.ZodString>;
    locator: z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
        path: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"WORKBOOK_SHEET">;
        sheetName: z.ZodString;
    }, z.core.$strict>], "kind">>;
    displayName: z.ZodNullable<z.ZodString>;
    columnCount: z.ZodNumber;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"DICTIONARY_FILE">;
    id: z.ZodString;
    logicalEntryId: z.ZodNullable<z.ZodString>;
    locator: z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
        path: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"WORKBOOK_SHEET">;
        sheetName: z.ZodString;
    }, z.core.$strict>], "kind">>;
}, z.core.$strict>], "kind">;
export declare const DatasetTableReferenceTargetsResponseSchema: z.ZodObject<{
    component: z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>;
    targetMemberId: z.ZodString;
    kind: z.ZodEnum<{
        JOIN: "JOIN";
        DICTIONARY: "DICTIONARY";
    }>;
    items: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"TABLE">;
        id: z.ZodString;
        logicalEntryId: z.ZodNullable<z.ZodString>;
        locator: z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
            path: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"WORKBOOK_SHEET">;
            sheetName: z.ZodString;
        }, z.core.$strict>], "kind">>;
        displayName: z.ZodNullable<z.ZodString>;
        columnCount: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"DICTIONARY_FILE">;
        id: z.ZodString;
        logicalEntryId: z.ZodNullable<z.ZodString>;
        locator: z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
            path: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"WORKBOOK_SHEET">;
            sheetName: z.ZodString;
        }, z.core.$strict>], "kind">>;
    }, z.core.$strict>], "kind">>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        targetMemberId: z.ZodString;
        kind: z.ZodEnum<{
            JOIN: "JOIN";
            DICTIONARY: "DICTIONARY";
        }>;
        afterId: z.ZodOptional<z.ZodString>;
        limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        memberId: z.ZodString;
        tableId: z.ZodString;
        contentId: z.ZodString;
        contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
        expectedPreparationGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    }, z.core.$strict>>;
    memberId: z.ZodString;
    tableId: z.ZodString;
    contentId: z.ZodString;
    contentGeneration: z.ZodNumber;
    preparationGeneration: z.ZodNumber;
    frozen: z.ZodBoolean;
}, z.core.$strict>;
export type DatasetTableReferenceTargetsQuery = z.infer<typeof DatasetTableReferenceTargetsQuerySchema>;
export type DatasetTableReferenceTargetsResponse = z.infer<typeof DatasetTableReferenceTargetsResponseSchema>;
export declare const DatasetTableReferenceViewSchema: z.ZodObject<{
    id: z.ZodString;
    component: z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>;
    sourceTable: z.ZodObject<{
        describedTableId: z.ZodNullable<z.ZodString>;
        displayName: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
    definition: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"KEY">;
        keyKind: z.ZodNullable<z.ZodEnum<{
            PRIMARY: "PRIMARY";
            UNIQUE: "UNIQUE";
        }>>;
        columns: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            position: z.ZodNumber;
            namePreview: z.ZodNullable<z.ZodString>;
            nameTruncated: z.ZodBoolean;
        }, z.core.$strict>>;
        label: z.ZodNullable<z.ZodString>;
        notes: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"JOIN">;
        targetTable: z.ZodNullable<z.ZodObject<{
            describedTableId: z.ZodNullable<z.ZodString>;
            displayName: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
        pairs: z.ZodArray<z.ZodObject<{
            source: z.ZodObject<{
                id: z.ZodString;
                position: z.ZodNumber;
                namePreview: z.ZodNullable<z.ZodString>;
                nameTruncated: z.ZodBoolean;
            }, z.core.$strict>;
            target: z.ZodObject<{
                id: z.ZodString;
                position: z.ZodNumber;
                namePreview: z.ZodNullable<z.ZodString>;
                nameTruncated: z.ZodBoolean;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        cardinality: z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            ONE_TO_ONE: "ONE_TO_ONE";
            ONE_TO_MANY: "ONE_TO_MANY";
            MANY_TO_ONE: "MANY_TO_ONE";
            MANY_TO_MANY: "MANY_TO_MANY";
        }>>;
        label: z.ZodNullable<z.ZodString>;
        notes: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"DICTIONARY">;
        state: z.ZodNullable<z.ZodEnum<{
            INCLUDED: "INCLUDED";
            NOT_INCLUDED: "NOT_INCLUDED";
        }>>;
        notes: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>], "kind">;
}, z.core.$strict>;
export declare const DatasetTableReferenceViewsCursorSchema: z.ZodObject<{
    contentId: z.ZodString;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    component: z.ZodOptional<z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>>;
    tableId: z.ZodOptional<z.ZodString>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export declare const DatasetTableReferenceViewsPageSchema: z.ZodObject<{
    contentId: z.ZodString;
    contentGeneration: z.ZodNumber;
    frozen: z.ZodBoolean;
    frozenAt: z.ZodNullable<z.ZodString>;
    component: z.ZodNullable<z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>>;
    tableId: z.ZodNullable<z.ZodString>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        component: z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>;
        sourceTable: z.ZodObject<{
            describedTableId: z.ZodNullable<z.ZodString>;
            displayName: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
        definition: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"KEY">;
            keyKind: z.ZodNullable<z.ZodEnum<{
                PRIMARY: "PRIMARY";
                UNIQUE: "UNIQUE";
            }>>;
            columns: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                position: z.ZodNumber;
                namePreview: z.ZodNullable<z.ZodString>;
                nameTruncated: z.ZodBoolean;
            }, z.core.$strict>>;
            label: z.ZodNullable<z.ZodString>;
            notes: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"JOIN">;
            targetTable: z.ZodNullable<z.ZodObject<{
                describedTableId: z.ZodNullable<z.ZodString>;
                displayName: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>>;
            pairs: z.ZodArray<z.ZodObject<{
                source: z.ZodObject<{
                    id: z.ZodString;
                    position: z.ZodNumber;
                    namePreview: z.ZodNullable<z.ZodString>;
                    nameTruncated: z.ZodBoolean;
                }, z.core.$strict>;
                target: z.ZodObject<{
                    id: z.ZodString;
                    position: z.ZodNumber;
                    namePreview: z.ZodNullable<z.ZodString>;
                    nameTruncated: z.ZodBoolean;
                }, z.core.$strict>;
            }, z.core.$strict>>;
            cardinality: z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                ONE_TO_ONE: "ONE_TO_ONE";
                ONE_TO_MANY: "ONE_TO_MANY";
                MANY_TO_ONE: "MANY_TO_ONE";
                MANY_TO_MANY: "MANY_TO_MANY";
            }>>;
            label: z.ZodNullable<z.ZodString>;
            notes: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DICTIONARY">;
            state: z.ZodNullable<z.ZodEnum<{
                INCLUDED: "INCLUDED";
                NOT_INCLUDED: "NOT_INCLUDED";
            }>>;
            notes: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>], "kind">;
    }, z.core.$strict>>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        contentId: z.ZodString;
        contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
        component: z.ZodOptional<z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>>;
        tableId: z.ZodOptional<z.ZodString>;
        afterId: z.ZodOptional<z.ZodString>;
        limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetPrivateTableReferenceViewsQuerySchema: z.ZodObject<{
    afterId: z.ZodOptional<z.ZodString>;
    scope: z.ZodEnum<{
        PUBLISHED: "PUBLISHED";
        WORKING: "WORKING";
        REVIEWED: "REVIEWED";
        EDIT_BASE: "EDIT_BASE";
        GRANTED: "GRANTED";
    }>;
    component: z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>;
    editOperation: z.ZodOptional<z.ZodEnum<{
        METADATA: "METADATA";
        PRICING: "PRICING";
        MATERIALS: "MATERIALS";
    }>>;
    contentId: z.ZodString;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    expectedWorkflowRevision: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
    memberId: z.ZodOptional<z.ZodString>;
    tableId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export declare const DatasetPrivateTableReferenceViewsResponseSchema: z.ZodObject<{
    context: z.ZodObject<{
        datasetId: z.ZodString;
        scope: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            WORKING: "WORKING";
            REVIEWED: "REVIEWED";
            EDIT_BASE: "EDIT_BASE";
            GRANTED: "GRANTED";
        }>;
        component: z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>;
        editOperation: z.ZodNullable<z.ZodEnum<{
            METADATA: "METADATA";
            PRICING: "PRICING";
            MATERIALS: "MATERIALS";
        }>>;
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        workflowRevision: z.ZodNullable<z.ZodNumber>;
        frozen: z.ZodBoolean;
        publicationId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    memberId: z.ZodNullable<z.ZodString>;
    page: z.ZodObject<{
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        frozen: z.ZodBoolean;
        frozenAt: z.ZodNullable<z.ZodString>;
        component: z.ZodNullable<z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>>;
        tableId: z.ZodNullable<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            component: z.ZodEnum<{
                SAMPLE: "SAMPLE";
                FULL: "FULL";
            }>;
            sourceTable: z.ZodObject<{
                describedTableId: z.ZodNullable<z.ZodString>;
                displayName: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
            origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
            definition: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"KEY">;
                keyKind: z.ZodNullable<z.ZodEnum<{
                    PRIMARY: "PRIMARY";
                    UNIQUE: "UNIQUE";
                }>>;
                columns: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    position: z.ZodNumber;
                    namePreview: z.ZodNullable<z.ZodString>;
                    nameTruncated: z.ZodBoolean;
                }, z.core.$strict>>;
                label: z.ZodNullable<z.ZodString>;
                notes: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"JOIN">;
                targetTable: z.ZodNullable<z.ZodObject<{
                    describedTableId: z.ZodNullable<z.ZodString>;
                    displayName: z.ZodNullable<z.ZodString>;
                }, z.core.$strict>>;
                pairs: z.ZodArray<z.ZodObject<{
                    source: z.ZodObject<{
                        id: z.ZodString;
                        position: z.ZodNumber;
                        namePreview: z.ZodNullable<z.ZodString>;
                        nameTruncated: z.ZodBoolean;
                    }, z.core.$strict>;
                    target: z.ZodObject<{
                        id: z.ZodString;
                        position: z.ZodNumber;
                        namePreview: z.ZodNullable<z.ZodString>;
                        nameTruncated: z.ZodBoolean;
                    }, z.core.$strict>;
                }, z.core.$strict>>;
                cardinality: z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    ONE_TO_ONE: "ONE_TO_ONE";
                    ONE_TO_MANY: "ONE_TO_MANY";
                    MANY_TO_ONE: "MANY_TO_ONE";
                    MANY_TO_MANY: "MANY_TO_MANY";
                }>>;
                label: z.ZodNullable<z.ZodString>;
                notes: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"DICTIONARY">;
                state: z.ZodNullable<z.ZodEnum<{
                    INCLUDED: "INCLUDED";
                    NOT_INCLUDED: "NOT_INCLUDED";
                }>>;
                notes: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>], "kind">;
        }, z.core.$strict>>;
        nextCursor: z.ZodNullable<z.ZodObject<{
            contentId: z.ZodString;
            contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
            component: z.ZodOptional<z.ZodEnum<{
                SAMPLE: "SAMPLE";
                FULL: "FULL";
            }>>;
            tableId: z.ZodOptional<z.ZodString>;
            afterId: z.ZodOptional<z.ZodString>;
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    targets: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        sourceMemberId: z.ZodString;
        sourceTableId: z.ZodString;
        sourceLocator: z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
            path: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"WORKBOOK_SHEET">;
            sheetName: z.ZodString;
        }, z.core.$strict>], "kind">>;
        sourceFileName: z.ZodNullable<z.ZodString>;
        targetFileName: z.ZodNullable<z.ZodString>;
        targetMemberId: z.ZodNullable<z.ZodString>;
        targetLogicalEntryId: z.ZodNullable<z.ZodString>;
        targetLocator: z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
            path: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"WORKBOOK_SHEET">;
            sheetName: z.ZodString;
        }, z.core.$strict>], "kind">>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetPublicTableReferenceViewsQuerySchema: z.ZodObject<{
    publicationId: z.ZodString;
    contentId: z.ZodString;
    contentGeneration: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
    component: z.ZodOptional<z.ZodEnum<{
        SAMPLE: "SAMPLE";
        FULL: "FULL";
    }>>;
    tableId: z.ZodOptional<z.ZodString>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export declare const DatasetPublicTableReferenceViewsResponseSchema: z.ZodObject<{
    datasetId: z.ZodString;
    publicationId: z.ZodString;
    page: z.ZodObject<{
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        frozen: z.ZodBoolean;
        frozenAt: z.ZodNullable<z.ZodString>;
        component: z.ZodNullable<z.ZodEnum<{
            SAMPLE: "SAMPLE";
            FULL: "FULL";
        }>>;
        tableId: z.ZodNullable<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            component: z.ZodEnum<{
                SAMPLE: "SAMPLE";
                FULL: "FULL";
            }>;
            sourceTable: z.ZodObject<{
                describedTableId: z.ZodNullable<z.ZodString>;
                displayName: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
            origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
            definition: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"KEY">;
                keyKind: z.ZodNullable<z.ZodEnum<{
                    PRIMARY: "PRIMARY";
                    UNIQUE: "UNIQUE";
                }>>;
                columns: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    position: z.ZodNumber;
                    namePreview: z.ZodNullable<z.ZodString>;
                    nameTruncated: z.ZodBoolean;
                }, z.core.$strict>>;
                label: z.ZodNullable<z.ZodString>;
                notes: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"JOIN">;
                targetTable: z.ZodNullable<z.ZodObject<{
                    describedTableId: z.ZodNullable<z.ZodString>;
                    displayName: z.ZodNullable<z.ZodString>;
                }, z.core.$strict>>;
                pairs: z.ZodArray<z.ZodObject<{
                    source: z.ZodObject<{
                        id: z.ZodString;
                        position: z.ZodNumber;
                        namePreview: z.ZodNullable<z.ZodString>;
                        nameTruncated: z.ZodBoolean;
                    }, z.core.$strict>;
                    target: z.ZodObject<{
                        id: z.ZodString;
                        position: z.ZodNumber;
                        namePreview: z.ZodNullable<z.ZodString>;
                        nameTruncated: z.ZodBoolean;
                    }, z.core.$strict>;
                }, z.core.$strict>>;
                cardinality: z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    ONE_TO_ONE: "ONE_TO_ONE";
                    ONE_TO_MANY: "ONE_TO_MANY";
                    MANY_TO_ONE: "MANY_TO_ONE";
                    MANY_TO_MANY: "MANY_TO_MANY";
                }>>;
                label: z.ZodNullable<z.ZodString>;
                notes: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"DICTIONARY">;
                state: z.ZodNullable<z.ZodEnum<{
                    INCLUDED: "INCLUDED";
                    NOT_INCLUDED: "NOT_INCLUDED";
                }>>;
                notes: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>], "kind">;
        }, z.core.$strict>>;
        nextCursor: z.ZodNullable<z.ZodObject<{
            contentId: z.ZodString;
            contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
            component: z.ZodOptional<z.ZodEnum<{
                SAMPLE: "SAMPLE";
                FULL: "FULL";
            }>>;
            tableId: z.ZodOptional<z.ZodString>;
            afterId: z.ZodOptional<z.ZodString>;
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type DatasetTableReferenceView = z.infer<typeof DatasetTableReferenceViewSchema>;
export type DatasetTableReferenceViewsCursor = z.infer<typeof DatasetTableReferenceViewsCursorSchema>;
export type DatasetTableReferenceViewsPage = z.infer<typeof DatasetTableReferenceViewsPageSchema>;
export type DatasetPrivateTableReferenceViewsQuery = z.infer<typeof DatasetPrivateTableReferenceViewsQuerySchema>;
export type DatasetPrivateTableReferenceViewsResponse = z.infer<typeof DatasetPrivateTableReferenceViewsResponseSchema>;
export type DatasetPublicTableReferenceViewsQuery = z.infer<typeof DatasetPublicTableReferenceViewsQuerySchema>;
export type DatasetPublicTableReferenceViewsResponse = z.infer<typeof DatasetPublicTableReferenceViewsResponseSchema>;
//# sourceMappingURL=tableReferences.schema.d.ts.map