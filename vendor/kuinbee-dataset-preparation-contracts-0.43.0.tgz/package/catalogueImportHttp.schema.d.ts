import { z } from "zod";
export declare const DatasetCatalogueDraftCandidatesQuerySchema: z.ZodObject<{
    page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    q: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetCatalogueDraftCandidatesResponseSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        generation: z.ZodNumber;
        catalogueIdentifier: z.ZodNullable<z.ZodString>;
        catalogueRevision: z.ZodNullable<z.ZodNumber>;
    }, z.core.$strict>>;
    page: z.ZodNumber;
    limit: z.ZodNumber;
    total: z.ZodNumber;
}, z.core.$strict>;
export type DatasetCatalogueDraftCandidatesQuery = z.infer<typeof DatasetCatalogueDraftCandidatesQuerySchema>;
//# sourceMappingURL=catalogueImportHttp.schema.d.ts.map