"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetDraftWorkspaceResponseSchema = exports.DatasetDraftWorkspaceItemSchema = exports.DatasetDraftWorkspaceQuerySchema = exports.DatasetPreparationsListResponseSchema = exports.DatasetPreparationResponseSchema = exports.DatasetPreparationReadinessSchema = exports.DatasetPreparationCatalogLabelsResponseSchema = exports.DatasetPreparationCatalogLabelsQuerySchema = exports.DatasetPreparationsListQuerySchema = exports.DatasetPreparationIdParamsSchema = exports.DatasetPreparationPatchBodySchema = exports.DatasetPreparationCreateBodySchema = exports.DatasetEditBaseResponseSchema = exports.DatasetPreparationMetadataSchema = exports.DatasetCollectionPeriodSchema = exports.DatasetGeographicCoverageSchema = exports.DatasetDeclaredDateSchema = exports.DatasetPreparationSampleSchema = exports.DatasetDeclaredMeasurementSchema = exports.DatasetDeclaredUnitSchema = exports.DatasetDeclaredMetricSchema = exports.DatasetPreparationProfilesSchema = exports.DATASET_MODALITIES = exports.DATASET_UPLOAD_CHOICES = exports.DatasetContextSchema = exports.DatasetModalitySchema = exports.DatasetUploadChoiceSchema = exports.DATASET_PREPARATION_LIMITS = exports.DatasetCreationContextResponseSchema = exports.DATASET_PREPARATION_CONTRACT_VERSION = void 0;
exports.formatDatasetGeographicCoverage = formatDatasetGeographicCoverage;
exports.formatDatasetCollectionPeriod = formatDatasetCollectionPeriod;
exports.isDatasetPreparationProfileFieldApplicable = isDatasetPreparationProfileFieldApplicable;
exports.getDatasetPreparationReadiness = getDatasetPreparationReadiness;
const zod_1 = require("zod");
const edit_schema_1 = require("./edit.schema");
// Supplier declarations only. Receipt, inspection, files, grants and business
// transitions deliberately have no writable representation in this first slice.
exports.DATASET_PREPARATION_CONTRACT_VERSION = 1;
// Creation routing is supplied by the authenticated backend. It identifies the
// editor only; it does not grant upload admission or claim files are ready.
exports.DatasetCreationContextResponseSchema = zod_1.z.object({
    workflow: zod_1.z.enum(["CONTENT", "LEGACY"]),
}).strict();
exports.DATASET_PREPARATION_LIMITS = {
    metadataBytes: 65_536,
    draftsPerSupplier: 50,
    requestsPerDraft: 128,
};
exports.DatasetUploadChoiceSchema = zod_1.z.enum([
    "SAMPLE_ONLY", "FULL_ONLY", "FULL_AND_SAMPLE",
]);
exports.DatasetModalitySchema = zod_1.z.enum([
    "TABULAR", "AUDIO", "IMAGE", "VIDEO", "TEXT", "SENSOR", "CAD",
]);
exports.DatasetContextSchema = zod_1.z.enum(["HEALTHCARE", "EGOCENTRIC"]);
exports.DATASET_UPLOAD_CHOICES = [
    { value: "SAMPLE_ONLY", label: "Sample only", help: "Upload a prepared sample and describe the collection it represents." },
    { value: "FULL_ONLY", label: "Full dataset only", help: "Upload the complete collection you describe. A sample is optional in a different upload choice." },
    { value: "FULL_AND_SAMPLE", label: "Full dataset + sample", help: "Provide the complete collection and a prepared sample for buyers to inspect." },
];
exports.DATASET_MODALITIES = [
    { value: "TABULAR", label: "Tables and spreadsheets", help: "Rows, records, sheets and related tables." },
    { value: "AUDIO", label: "Speech and other audio", help: "Conversations, music, environmental sound or other recordings." },
    { value: "IMAGE", label: "Images", help: "Photographs, frames, illustrations or other image collections." },
    { value: "VIDEO", label: "Video", help: "Clips or recordings, with or without audio." },
    { value: "TEXT", label: "Text and documents", help: "Text is the main data, rather than a transcript supporting a recording." },
    { value: "SENSOR", label: "Sensor readings", help: "Measurements and streams such as temperature, motion or device logs." },
    { value: "CAD", label: "CAD and 3D engineering models", help: "Engineering components, assemblies and geometric exchange files." },
];
const text = zod_1.z.string().trim().max(4_000).nullable().optional();
const shortText = zod_1.z.string().trim().max(500).nullable().optional();
// Existing catalog IDs are bounded opaque strings, including legacy imports.
// Validate existence/ownership on the server rather than inventing a new ID rule.
const catalogId = zod_1.z.string().min(1).max(128);
const reference = catalogId.nullable().optional();
const unique = (values) => new Set(values).size === values.length;
const languageList = zod_1.z.array(zod_1.z.string().trim().min(1).max(100)).max(30)
    .refine(unique, "Languages must be unique").optional();
const availability = zod_1.z.enum(["PRESENT", "ABSENT", "UNKNOWN"]).nullable().optional();
const DatasetStudyStructureSchema = zod_1.z.enum([
    "CROSS_SECTIONAL", "TIME_SERIES", "PANEL", "POOLED_CROSS_SECTIONAL",
    "REPEATED_CROSS_SECTIONS", "SPATIAL", "SPATIO_TEMPORAL", "EXPERIMENTAL",
    "OBSERVATIONAL", "BIG_DATA", "EVENT_HISTORY_SURVIVAL", "HIERARCHICAL_MULTILEVEL",
]);
exports.DatasetPreparationProfilesSchema = zod_1.z.object({
    cad: zod_1.z.object({
        modelScope: text, formatNotes: text, assemblyStructure: text, unitNotes: text,
        nativeSourceAvailability: availability, parametricHistoryAvailability: availability,
        annotationAvailability: availability, annotationMeaning: text,
    }).strict().nullable().optional(),
    tabular: zod_1.z.object({
        recordUnit: text, columnMeaningNotes: text, unitNotes: text,
        missingValueConventions: text, tableRelationshipNotes: text,
        dictionaryAvailability: availability,
    }).strict().nullable().optional(),
    audio: zod_1.z.object({
        content: zod_1.z.enum(["SPEECH", "NON_SPEECH", "MIXED", "UNKNOWN"]).nullable().optional(),
        languages: languageList, recordingContext: text,
        transcriptAvailability: availability, transcriptMeaning: text,
        transcriptTiming: zod_1.z.enum(["UNTIMED", "TIMED", "UNKNOWN"]).nullable().optional(),
        annotationAvailability: availability, annotationMeaning: text,
        speakerCoverage: text, alignmentNotes: text,
    }).strict().nullable().optional(),
    images: zod_1.z.object({
        subject: text, captureContext: text, annotationAvailability: availability,
        annotationMeaning: text, classDefinitions: text, coverage: text,
    }).strict().nullable().optional(),
    video: zod_1.z.object({
        content: text, viewpoint: shortText, audioContext: text,
        annotationAvailability: availability, annotationMeaning: text, timingConvention: text,
        annotationReferences: zod_1.z.enum(["WHOLE_ITEM", "TIME_OR_FRAME", "UNKNOWN"]).nullable().optional(),
    }).strict().nullable().optional(),
    text: zod_1.z.object({
        recordUnit: text, languageContent: zod_1.z.enum(["HUMAN_LANGUAGE", "NON_LANGUAGE", "MIXED", "UNKNOWN"]).nullable().optional(),
        languages: languageList, annotationAvailability: availability,
        annotationMeaning: text, recordConvention: text,
    }).strict().nullable().optional(),
    sensors: zod_1.z.object({
        channels: zod_1.z.array(zod_1.z.object({
            name: zod_1.z.string().trim().min(1).max(200),
            meaning: text, unit: shortText,
        }).strict()).max(100).optional(),
        channelNotes: text, sessionRelationships: text, timestampMeaning: text,
        timeOrigin: text,
        synchronization: zod_1.z.enum(["NO_CLAIM", "DESCRIBED", "UNKNOWN"]).nullable().optional(),
        synchronizationNotes: text, calibrationAvailability: availability,
        calibrationMeaning: text, coordinateConventions: text,
    }).strict().nullable().optional(),
    egocentric: zod_1.z.object({
        mounting: shortText, activities: text, environment: text, additionalStreams: text,
    }).strict().nullable().optional(),
    healthcare: zod_1.z.object({
        recordMeaning: text, setting: text, identifierHandling: text, participantCoverage: text,
    }).strict().nullable().optional(),
}).strict();
exports.DatasetDeclaredMetricSchema = zod_1.z.enum([
    "RECORD_COUNT", "ROW_COUNT", "COLUMN_COUNT", "AUDIO_DURATION", "IMAGE_COUNT",
    "VIDEO_DURATION", "DOCUMENT_COUNT", "SESSION_COUNT", "PARTICIPANT_COUNT",
    "STREAM_COUNT", "BYTE_SIZE",
]);
exports.DatasetDeclaredUnitSchema = zod_1.z.enum(["COUNT", "SECOND", "MINUTE", "HOUR", "BYTE"]);
const measurementBase = {
    metric: exports.DatasetDeclaredMetricSchema,
    unit: exports.DatasetDeclaredUnitSchema,
};
exports.DatasetDeclaredMeasurementSchema = zod_1.z.discriminatedUnion("state", [
    zod_1.z.object({ ...measurementBase, state: zod_1.z.literal("UNKNOWN") }).strict(),
    zod_1.z.object({
        ...measurementBase, state: zod_1.z.enum(["KNOWN", "ESTIMATED"]),
        value: zod_1.z.string().regex(/^(0|[1-9]\d{0,14})(\.\d{1,6})?$/, "Use a nonnegative decimal value"),
    }).strict(),
]).superRefine((measurement, ctx) => {
    const duration = measurement.metric === "AUDIO_DURATION" || measurement.metric === "VIDEO_DURATION";
    const allowedUnits = duration ? ["SECOND", "MINUTE", "HOUR"]
        : measurement.metric === "BYTE_SIZE" ? ["BYTE"] : ["COUNT"];
    if (!allowedUnits.includes(measurement.unit)) {
        ctx.addIssue({ code: "custom", path: ["unit"], message: "Unit does not match the quantity" });
    }
    if (!duration && measurement.state !== "UNKNOWN" && measurement.value.includes(".")) {
        ctx.addIssue({ code: "custom", path: ["value"], message: "Counts and byte quantities must be integers" });
    }
});
exports.DatasetPreparationSampleSchema = zod_1.z.object({
    selectionMethod: text, coverage: text,
    omissions: zod_1.z.enum(["DESCRIBED", "NONE_KNOWN", "UNKNOWN"]).nullable().optional(),
    omissionNotes: text,
    transformations: zod_1.z.enum(["NONE_DECLARED", "DESCRIBED", "UNKNOWN"]).nullable().optional(),
    transformationNotes: text, relationshipNotes: text,
}).strict();
const declaredMeasurements = zod_1.z.array(exports.DatasetDeclaredMeasurementSchema).max(12)
    .refine((values) => unique(values.map((value) => value.metric)), "Declare each quantity once within its scope");
// Optional supplier declarations about the represented collection. Missing
// historical fields stay missing; file timestamps/storage geography are never
// substituted. KNOWN may be incomplete in a saved draft, but not at submission.
const year = zod_1.z.string().regex(/^(?!0000)\d{4}$/);
exports.DatasetDeclaredDateSchema = zod_1.z.discriminatedUnion("precision", [
    zod_1.z.object({ precision: zod_1.z.literal("YEAR"), value: year }).strict(),
    zod_1.z.object({ precision: zod_1.z.literal("MONTH"), value: zod_1.z.string().regex(/^(?!0000)\d{4}-(0[1-9]|1[0-2])$/) }).strict(),
    zod_1.z.object({ precision: zod_1.z.literal("DAY"), value: zod_1.z.iso.date().refine(value => !value.startsWith("0000-")) }).strict(),
]);
function dateBounds(date) {
    if (date.precision === "YEAR")
        return [date.value + "-01-01", date.value + "-12-31"];
    if (date.precision === "DAY")
        return [date.value, date.value];
    const [y, m] = date.value.split("-").map(Number), leap = y % 4 === 0 && (y % 100 !== 0 || y % 400 === 0);
    const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1];
    return [date.value + "-01", date.value + "-" + days];
}
exports.DatasetGeographicCoverageSchema = zod_1.z.discriminatedUnion("state", [
    zod_1.z.object({ state: zod_1.z.literal("KNOWN"), description: zod_1.z.string().trim().max(2_000).nullable().optional() }).strict(),
    zod_1.z.object({ state: zod_1.z.literal("UNKNOWN") }).strict(),
    zod_1.z.object({ state: zod_1.z.literal("NOT_APPLICABLE") }).strict(),
]);
exports.DatasetCollectionPeriodSchema = zod_1.z.discriminatedUnion("state", [
    zod_1.z.object({ state: zod_1.z.literal("KNOWN"), start: exports.DatasetDeclaredDateSchema.nullable().optional(),
        end: exports.DatasetDeclaredDateSchema.nullable().optional(), notes: zod_1.z.string().trim().max(1_000).nullable().optional() }).strict(),
    zod_1.z.object({ state: zod_1.z.literal("UNKNOWN") }).strict(),
    zod_1.z.object({ state: zod_1.z.literal("NOT_APPLICABLE") }).strict(),
]).refine(period => period.state !== "KNOWN" || !period.start || !period.end ||
    dateBounds(period.start)[0] <= dateBounds(period.end)[1], "The collection period cannot end before it starts");
function formatDatasetGeographicCoverage(value) {
    return !value ? "Not declared" : value.state === "UNKNOWN" ? "Unknown" : value.state === "NOT_APPLICABLE" ? "Not applicable" :
        value.description || "Description not yet provided";
}
function formatDatasetCollectionPeriod(value) {
    if (!value)
        return "Not declared";
    if (value.state !== "KNOWN")
        return value.state === "UNKNOWN" ? "Unknown" : "Not applicable";
    const date = (item) => `${item.value} (${item.precision.toLowerCase()})`;
    const interval = value.start && value.end ? `${date(value.start)} to ${date(value.end)}` :
        value.start ? `From ${date(value.start)}; end not provided` : value.end ? `Through ${date(value.end)}; start not provided` : "Dates not yet provided";
    return value.notes ? interval + "\n" + value.notes : interval;
}
exports.DatasetPreparationMetadataSchema = zod_1.z.object({
    title: zod_1.z.string().trim().min(1).max(200),
    uploadChoice: exports.DatasetUploadChoiceSchema.nullable().optional(),
    primaryCategoryId: reference, sourceId: reference,
    license: zod_1.z.string().trim().min(1).max(1_000).nullable().optional(),
    modalities: zod_1.z.array(exports.DatasetModalitySchema).max(7).refine(unique, "Data types must be unique").optional(),
    contexts: zod_1.z.array(exports.DatasetContextSchema).max(2).refine(unique, "Contexts must be unique").optional(),
    superType: DatasetStudyStructureSchema.nullable().optional(),
    collectionBoundary: text, overview: text, description: text,
    dataQuality: text, limitations: text, collectionMethod: text, possibleUses: text,
    tags: zod_1.z.array(zod_1.z.string().trim().min(1).max(80)).max(20).refine(unique, "Tags must be unique").optional(),
    secondaryCategoryIds: zod_1.z.array(catalogId).max(10).refine(unique, "Categories must be unique").optional(),
    geographicCoverage: exports.DatasetGeographicCoverageSchema.nullable().optional(),
    collectionPeriod: exports.DatasetCollectionPeriodSchema.nullable().optional(),
    collectionMeasurements: declaredMeasurements.optional(),
    fullMeasurements: declaredMeasurements.optional(),
    sampleMeasurements: declaredMeasurements.optional(),
    sample: exports.DatasetPreparationSampleSchema.nullable().optional(),
    fullCompleteness: zod_1.z.boolean().nullable().optional(),
    fullCollectionOffer: zod_1.z.object({
        mode: zod_1.z.literal("PAID_ON_REQUEST"),
        terms: zod_1.z.string().trim().min(1).max(1_000),
    }).strict().nullable().optional(),
    profiles: exports.DatasetPreparationProfilesSchema.nullable().optional(),
}).strict();
// Visibility is shared by the editor, saved/frozen supplier summaries and the
// public frozen projection. Hidden draft answers remain stored, but cannot be
// presented as an applicable claim after a parent answer changes.
function isDatasetPreparationProfileFieldApplicable(profile, field, values) {
    if (profile === "audio") {
        if (field === "languages" || field === "speakerCoverage")
            return values.content !== "NON_SPEECH";
        if (["transcriptMeaning", "transcriptTiming", "alignmentNotes"].includes(field))
            return values.transcriptAvailability === "PRESENT" && (field !== "alignmentNotes" || values.transcriptTiming === "TIMED" || values.transcriptTiming === undefined);
        if (field === "annotationMeaning")
            return values.annotationAvailability === "PRESENT";
    }
    if (["images", "video", "text", "cad"].includes(profile) && ["annotationMeaning", "classDefinitions", "annotationReferences", "timingConvention", "recordConvention"].includes(field))
        return values.annotationAvailability === "PRESENT" && (field !== "timingConvention" || values.annotationReferences === "TIME_OR_FRAME" || values.annotationReferences === undefined);
    if (profile === "text" && field === "languages")
        return values.languageContent !== "NON_LANGUAGE";
    if (profile === "sensors" && field === "synchronizationNotes")
        return values.synchronization === "DESCRIBED";
    if (profile === "sensors" && field === "calibrationMeaning")
        return values.calibrationAvailability === "PRESENT";
    return true;
}
exports.DatasetEditBaseResponseSchema = zod_1.z.object({
    context: edit_schema_1.DatasetEditContextResponseSchema,
    metadataSource: zod_1.z.enum(["CURRENT_DRAFT", "FROZEN_BASE", "CURRENT_METADATA"]),
    metadata: exports.DatasetPreparationMetadataSchema,
    contentReference: zod_1.z.object({ contentId: zod_1.z.string().cuid(), generation: zod_1.z.number().int().nonnegative(), frozen: zod_1.z.boolean() }).strict().nullable(),
}).strict().refine(value => {
    const precondition = value.context.precondition;
    if (!value.context.editable)
        return false;
    if (value.metadataSource === "CURRENT_METADATA")
        return !precondition && !value.contentReference && value.context.operation === "PRICING";
    const ref = value.contentReference;
    if (!ref)
        return false;
    return value.metadataSource === "FROZEN_BASE" ? precondition?.mode === "INITIALIZE" &&
        ref.contentId === precondition.expectedBaseContentId && ref.frozen :
        precondition?.mode === "EXISTING_DRAFT" && ref.contentId === precondition.expectedContentId &&
            ref.generation === precondition.expectedGeneration && !ref.frozen;
}, "Edit metadata identifies its exact selected base; a read never initializes a draft");
const requestId = zod_1.z.string().uuid().transform((value) => value.toLowerCase());
exports.DatasetPreparationCreateBodySchema = zod_1.z.object({
    requestId, metadata: exports.DatasetPreparationMetadataSchema,
}).strict();
exports.DatasetPreparationPatchBodySchema = zod_1.z.object({
    requestId, expectedGeneration: zod_1.z.number().int().min(0).max(Number.MAX_SAFE_INTEGER),
    legacyBaseFingerprint: zod_1.z.string().regex(/^[a-f0-9]{64}$/).optional(),
    editContext: edit_schema_1.DatasetCorrectionPreconditionSchema.optional(),
    changes: exports.DatasetPreparationMetadataSchema.partial().refine((changes) => Object.keys(changes).length > 0, "Provide at least one change"),
}).strict().refine(value => !value.legacyBaseFingerprint || !value.editContext, "An earlier empty draft uses its exact legacy base, not an existing content edit context");
exports.DatasetPreparationIdParamsSchema = zod_1.z.object({ draftId: zod_1.z.string().cuid() }).strict();
exports.DatasetPreparationsListQuerySchema = zod_1.z.object({
    page: zod_1.z.coerce.number().int().min(1).max(10_000).default(1),
    limit: zod_1.z.coerce.number().int().min(1).max(50).default(20),
    q: zod_1.z.string().trim().min(1).max(200).optional(),
}).strict();
exports.DatasetPreparationCatalogLabelsQuerySchema = zod_1.z.object({
    primaryCategoryId: catalogId.optional(), sourceId: catalogId.optional(),
}).strict().refine((query) => Boolean(query.primaryCategoryId || query.sourceId), "Choose a category or source to look up");
const catalogLabel = zod_1.z.object({ id: catalogId, name: zod_1.z.string().min(1).max(1_000) }).strict();
exports.DatasetPreparationCatalogLabelsResponseSchema = zod_1.z.object({
    primaryCategory: catalogLabel.nullable(), source: catalogLabel.nullable(),
}).strict();
// Saved metadata checklist only. This response does not inspect files, pricing
// or workflow state and must never authorize Submit. Use the proposal readiness
// endpoint for the generation-bound, complete submission decision.
exports.DatasetPreparationReadinessSchema = zod_1.z.object({
    canSubmit: zod_1.z.literal(false),
    issues: zod_1.z.array(zod_1.z.object({ code: zod_1.z.string().min(1), field: zod_1.z.string().optional(), message: zod_1.z.string().min(1) }).strict()).max(100),
}).strict();
exports.DatasetPreparationResponseSchema = zod_1.z.object({
    contractVersion: zod_1.z.literal(exports.DATASET_PREPARATION_CONTRACT_VERSION), id: zod_1.z.string().cuid(),
    generation: zod_1.z.number().int().min(0).max(Number.MAX_SAFE_INTEGER),
    metadata: exports.DatasetPreparationMetadataSchema,
    createdAt: zod_1.z.string().datetime(), updatedAt: zod_1.z.string().datetime(),
    readiness: exports.DatasetPreparationReadinessSchema,
    // A read-only projection of an eligible old empty draft. Only an explicit,
    // fingerprinted first save initializes the canonical editor on the same id.
    legacyBaseFingerprint: zod_1.z.string().regex(/^[a-f0-9]{64}$/).optional(),
}).strict().refine(value => !value.legacyBaseFingerprint || value.generation === 0, "An earlier empty draft projection precedes its first canonical save");
exports.DatasetPreparationsListResponseSchema = zod_1.z.object({
    items: zod_1.z.array(exports.DatasetPreparationResponseSchema).max(50),
    page: zod_1.z.number().int().positive(), limit: zod_1.z.number().int().min(1).max(50),
    total: zod_1.z.number().int().nonnegative(),
}).strict();
// A single supplier draft inventory across the additive metadata foundation and
// eligible existing proposals. kind chooses the correct editor, never a new
// business status. Early unbound drafts retain a null number; canonical saves
// allocate the existing supplier Dataset number on the same stable identity.
exports.DatasetDraftWorkspaceQuerySchema = exports.DatasetPreparationsListQuerySchema;
const draftWorkspaceItem = {
    title: zod_1.z.string().min(1),
    updatedAt: zod_1.z.string().datetime(),
};
exports.DatasetDraftWorkspaceItemSchema = zod_1.z.discriminatedUnion("kind", [
    zod_1.z.object({
        ...draftWorkspaceItem, id: zod_1.z.string().cuid(), kind: zod_1.z.literal("PREPARATION"),
        datasetUniqueId: zod_1.z.string().regex(/^D[0-9]{10,16}$/).nullable(), uploadChoice: exports.DatasetUploadChoiceSchema.nullable(), currentUploadId: zod_1.z.null(),
    }).strict(),
    zod_1.z.object({
        ...draftWorkspaceItem, id: catalogId, kind: zod_1.z.literal("PROPOSAL"),
        datasetUniqueId: zod_1.z.string().min(1), uploadChoice: zod_1.z.null(), currentUploadId: catalogId.nullable(),
        guidedEditorAvailable: zod_1.z.boolean().optional(),
    }).strict(),
]);
exports.DatasetDraftWorkspaceResponseSchema = zod_1.z.object({
    items: zod_1.z.array(exports.DatasetDraftWorkspaceItemSchema).max(50),
    page: zod_1.z.number().int().positive(), limit: zod_1.z.number().int().min(1).max(50),
    total: zod_1.z.number().int().nonnegative(),
    summary: zod_1.z.object({
        total: zod_1.z.number().int().nonnegative(),
        withCurrentUpload: zod_1.z.number().int().nonnegative(),
        withoutCurrentUpload: zod_1.z.number().int().nonnegative(),
    }).strict(),
}).strict().superRefine((result, ctx) => {
    if (result.summary.total !== result.total
        || result.summary.withCurrentUpload + result.summary.withoutCurrentUpload !== result.total) {
        ctx.addIssue({ code: "custom", path: ["summary"], message: "Draft summary must match the filtered inventory" });
    }
    if (result.items.length > result.limit) {
        ctx.addIssue({ code: "custom", path: ["items"], message: "Draft page exceeds its limit" });
    }
});
function getDatasetPreparationReadiness(metadata) {
    const issues = [];
    const missing = (field, message) => issues.push({ code: "MISSING_INFORMATION", field, message });
    for (const [field, label] of [
        ["uploadChoice", "Choose what you are uploading."],
        ["primaryCategoryId", "Choose a primary category."], ["sourceId", "Choose your data source."],
        ["license", "State the dataset license."], ["collectionBoundary", "Define the collection this dataset represents."],
        ["overview", "Add a short overview."], ["description", "Explain how the collection is organized."],
        ["dataQuality", "Describe quality checks, or state that quality has not been assessed."],
    ]) {
        if (!metadata[field])
            missing(field, label);
    }
    if (!metadata.modalities?.length)
        missing("modalities", "Choose the main types of data.");
    if (metadata.fullCollectionOffer && metadata.uploadChoice !== "SAMPLE_ONLY")
        missing("fullCollectionOffer", "A full-collection enquiry offer applies to a sample-only listing.");
    if (!metadata.collectionMeasurements?.length)
        missing("collectionMeasurements", "Describe a collection quantity, or explicitly state that it is unknown.");
    if (metadata.uploadChoice === "SAMPLE_ONLY" || metadata.uploadChoice === "FULL_AND_SAMPLE") {
        const sample = metadata.sample;
        if (!sample?.selectionMethod)
            missing("sample.selectionMethod", "Describe how the sample was selected.");
        if (!sample?.coverage)
            missing("sample.coverage", "Describe the sample coverage, including what is unknown.");
        if (!sample?.omissions)
            missing("sample.omissions", "State what is omitted from the sample, or that it is unknown.");
        if (sample?.omissions === "DESCRIBED" && !sample.omissionNotes)
            missing("sample.omissionNotes", "Explain what is omitted from the sample.");
        if (!sample?.transformations)
            missing("sample.transformations", "State whether the sample was changed from its source.");
        if (sample?.transformations === "DESCRIBED" && !sample.transformationNotes)
            missing("sample.transformationNotes", "Describe the sample preparation or changes.");
    }
    if (metadata.uploadChoice === "FULL_ONLY" || metadata.uploadChoice === "FULL_AND_SAMPLE") {
        if (metadata.fullCompleteness !== true)
            missing("fullCompleteness", "Confirm that full material will cover the collection boundary you defined.");
    }
    const profiles = metadata.profiles;
    if (metadata.geographicCoverage?.state === "KNOWN" && !metadata.geographicCoverage.description)
        missing("geographicCoverage", "Describe the claimed geographic coverage, or choose Unknown / Not applicable.");
    if (metadata.collectionPeriod?.state === "KNOWN" && !metadata.collectionPeriod.start && !metadata.collectionPeriod.end)
        missing("collectionPeriod", "Provide at least one collection/capture date, or choose Unknown / Not applicable.");
    const required = (field, value, message) => { if (!value)
        missing(field, message); };
    if (metadata.modalities?.includes("CAD")) {
        required("profiles.cad.modelScope", profiles?.cad?.modelScope, "Describe the components, assemblies and projects in the collection.");
        required("profiles.cad.formatNotes", profiles?.cad?.formatNotes, "Describe the CAD formats and any unknown format coverage.");
        required("profiles.cad.assemblyStructure", profiles?.cad?.assemblyStructure, "Describe assembly relationships and known limits.");
        required("profiles.cad.unitNotes", profiles?.cad?.unitNotes, "Describe units and coordinate conventions, including unknowns.");
        if (profiles?.cad?.annotationAvailability === "PRESENT")
            required("profiles.cad.annotationMeaning", profiles.cad.annotationMeaning, "Describe the CAD annotations.");
    }
    if (metadata.modalities?.includes("TABULAR"))
        required("profiles.tabular.recordUnit", profiles?.tabular?.recordUnit, "Explain what one table record represents.");
    if (metadata.modalities?.includes("AUDIO")) {
        required("profiles.audio.content", profiles?.audio?.content, "Describe whether the audio contains speech or other sound.");
        if (profiles?.audio?.content !== "NON_SPEECH")
            required("profiles.audio.languages", profiles?.audio?.languages?.length, "State the spoken languages, or explicitly enter Unknown for unassessed language coverage.");
        required("profiles.audio.transcriptAvailability", profiles?.audio?.transcriptAvailability, "State transcript availability in the represented collection.");
        required("profiles.audio.annotationAvailability", profiles?.audio?.annotationAvailability, "State other audio annotation availability in the represented collection.");
        if (profiles?.audio?.transcriptAvailability === "PRESENT") {
            required("profiles.audio.transcriptMeaning", profiles.audio.transcriptMeaning, "Explain the available transcript conventions, or state what is undocumented.");
            required("profiles.audio.transcriptTiming", profiles.audio.transcriptTiming, "State whether the available transcripts are timed, untimed or unassessed.");
            if (profiles.audio.transcriptTiming === "TIMED")
                required("profiles.audio.alignmentNotes", profiles.audio.alignmentNotes, "Explain the claimed transcript time units and reference; untimed transcripts need no invented alignment.");
        }
        if (profiles?.audio?.annotationAvailability === "PRESENT")
            required("profiles.audio.annotationMeaning", profiles.audio.annotationMeaning, "Explain the available audio labels, or state what is undocumented.");
    }
    if (metadata.modalities?.includes("IMAGE")) {
        required("profiles.images.subject", profiles?.images?.subject, "Describe what the images show.");
        required("profiles.images.annotationAvailability", profiles?.images?.annotationAvailability, "State image annotation availability in the represented collection.");
        if (profiles?.images?.annotationAvailability === "PRESENT")
            required("profiles.images.annotationMeaning", profiles.images.annotationMeaning, "Explain the available image annotations, or state what is undocumented.");
    }
    if (metadata.modalities?.includes("VIDEO")) {
        required("profiles.video.content", profiles?.video?.content, "Describe what the videos show.");
        required("profiles.video.annotationAvailability", profiles?.video?.annotationAvailability, "State video annotation availability in the represented collection.");
        if (profiles?.video?.annotationAvailability === "PRESENT") {
            required("profiles.video.annotationMeaning", profiles.video.annotationMeaning, "Explain the available video annotations, or state what is undocumented.");
            required("profiles.video.annotationReferences", profiles.video.annotationReferences, "State whether annotations describe whole clips, time/frame references or unassessed references.");
            if (profiles.video.annotationReferences === "TIME_OR_FRAME")
                required("profiles.video.timingConvention", profiles.video.timingConvention, "Explain the claimed video time or frame units, origin and indexing convention.");
        }
    }
    if (metadata.modalities?.includes("TEXT")) {
        required("profiles.text.recordUnit", profiles?.text?.recordUnit, "Explain what one document or text record represents.");
        required("profiles.text.languageContent", profiles?.text?.languageContent, "State whether the records contain human language, other content, both or unassessed content.");
        if (profiles?.text?.languageContent !== "NON_LANGUAGE")
            required("profiles.text.languages", profiles?.text?.languages?.length, "State the text languages, or explicitly enter Unknown for unassessed language coverage.");
        required("profiles.text.annotationAvailability", profiles?.text?.annotationAvailability, "State text annotation availability in the represented collection.");
        if (profiles?.text?.annotationAvailability === "PRESENT") {
            required("profiles.text.annotationMeaning", profiles.text.annotationMeaning, "Explain the available text labels, or state what is undocumented.");
            required("profiles.text.recordConvention", profiles.text.recordConvention, "Explain the annotation record or offset convention, including any undocumented references.");
        }
    }
    if (metadata.modalities?.includes("SENSOR")) {
        required("profiles.sensors.channelNotes", profiles?.sensors?.channelNotes, "Explain the sensor channels and units, including any unknowns.");
        if (profiles?.sensors?.synchronization === "DESCRIBED")
            required("profiles.sensors.synchronizationNotes", profiles.sensors.synchronizationNotes, "Explain the claimed stream synchronization.");
        if (profiles?.sensors?.calibrationAvailability === "PRESENT")
            required("profiles.sensors.calibrationMeaning", profiles.sensors.calibrationMeaning, "Explain what the available calibration describes, or state what is undocumented.");
    }
    if (metadata.contexts?.includes("HEALTHCARE")) {
        required("profiles.healthcare.recordMeaning", profiles?.healthcare?.recordMeaning, "Describe what the healthcare records represent.");
        required("profiles.healthcare.identifierHandling", profiles?.healthcare?.identifierHandling, "Describe how personal identifiers were handled; this remains a supplier declaration.");
    }
    // An empty metadata checklist is not permission to submit: selected files,
    // pricing and current workflow dependencies are checked separately.
    return { canSubmit: false, issues };
}
