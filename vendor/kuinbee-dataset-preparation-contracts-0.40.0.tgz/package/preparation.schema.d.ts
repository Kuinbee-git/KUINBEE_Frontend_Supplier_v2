import { z } from "zod";
export declare const DATASET_PREPARATION_CONTRACT_VERSION: 1;
export declare const DatasetCreationContextResponseSchema: z.ZodObject<{
    workflow: z.ZodEnum<{
        CONTENT: "CONTENT";
        LEGACY: "LEGACY";
    }>;
}, z.core.$strict>;
export type DatasetCreationContextResponse = z.infer<typeof DatasetCreationContextResponseSchema>;
export declare const DATASET_PREPARATION_LIMITS: {
    readonly metadataBytes: 65536;
    readonly draftsPerSupplier: 50;
    readonly requestsPerDraft: 128;
};
export declare const DatasetUploadChoiceSchema: z.ZodEnum<{
    SAMPLE_ONLY: "SAMPLE_ONLY";
    FULL_ONLY: "FULL_ONLY";
    FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
}>;
export declare const DatasetModalitySchema: z.ZodEnum<{
    TABULAR: "TABULAR";
    AUDIO: "AUDIO";
    IMAGE: "IMAGE";
    VIDEO: "VIDEO";
    TEXT: "TEXT";
    SENSOR: "SENSOR";
}>;
export declare const DatasetContextSchema: z.ZodEnum<{
    HEALTHCARE: "HEALTHCARE";
    EGOCENTRIC: "EGOCENTRIC";
}>;
export declare const DATASET_UPLOAD_CHOICES: readonly [{
    readonly value: "SAMPLE_ONLY";
    readonly label: "Sample only";
    readonly help: "Upload a prepared sample and describe the collection it represents.";
}, {
    readonly value: "FULL_ONLY";
    readonly label: "Full dataset only";
    readonly help: "Upload the complete collection you describe. A sample is optional in a different upload choice.";
}, {
    readonly value: "FULL_AND_SAMPLE";
    readonly label: "Full dataset + sample";
    readonly help: "Provide the complete collection and a prepared sample for buyers to inspect.";
}];
export declare const DATASET_MODALITIES: readonly [{
    readonly value: "TABULAR";
    readonly label: "Tables and spreadsheets";
    readonly help: "Rows, records, sheets and related tables.";
}, {
    readonly value: "AUDIO";
    readonly label: "Speech and other audio";
    readonly help: "Conversations, music, environmental sound or other recordings.";
}, {
    readonly value: "IMAGE";
    readonly label: "Images";
    readonly help: "Photographs, frames, illustrations or other image collections.";
}, {
    readonly value: "VIDEO";
    readonly label: "Video";
    readonly help: "Clips or recordings, with or without audio.";
}, {
    readonly value: "TEXT";
    readonly label: "Text and documents";
    readonly help: "Text is the main data, rather than a transcript supporting a recording.";
}, {
    readonly value: "SENSOR";
    readonly label: "Sensor readings";
    readonly help: "Measurements and streams such as temperature, motion or device logs.";
}];
export declare const DatasetPreparationProfilesSchema: z.ZodObject<{
    tabular: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
            UNKNOWN: "UNKNOWN";
        }>>>;
    }, z.core.$strict>>>;
    audio: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            SPEECH: "SPEECH";
            NON_SPEECH: "NON_SPEECH";
            MIXED: "MIXED";
        }>>>;
        languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
        recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
            UNKNOWN: "UNKNOWN";
        }>>>;
        transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            UNTIMED: "UNTIMED";
            TIMED: "TIMED";
        }>>>;
        annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
            UNKNOWN: "UNKNOWN";
        }>>>;
        annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>>;
    images: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
            UNKNOWN: "UNKNOWN";
        }>>>;
        annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>>;
    video: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
            UNKNOWN: "UNKNOWN";
        }>>>;
        annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            WHOLE_ITEM: "WHOLE_ITEM";
            TIME_OR_FRAME: "TIME_OR_FRAME";
        }>>>;
    }, z.core.$strict>>>;
    text: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            MIXED: "MIXED";
            HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
            NON_LANGUAGE: "NON_LANGUAGE";
        }>>>;
        languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
        annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
            UNKNOWN: "UNKNOWN";
        }>>>;
        annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>>;
    sensors: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            NO_CLAIM: "NO_CLAIM";
            DESCRIBED: "DESCRIBED";
        }>>>;
        synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
            UNKNOWN: "UNKNOWN";
        }>>>;
        calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>>;
    egocentric: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>>;
    healthcare: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export declare const DatasetDeclaredMetricSchema: z.ZodEnum<{
    RECORD_COUNT: "RECORD_COUNT";
    ROW_COUNT: "ROW_COUNT";
    COLUMN_COUNT: "COLUMN_COUNT";
    AUDIO_DURATION: "AUDIO_DURATION";
    IMAGE_COUNT: "IMAGE_COUNT";
    VIDEO_DURATION: "VIDEO_DURATION";
    DOCUMENT_COUNT: "DOCUMENT_COUNT";
    SESSION_COUNT: "SESSION_COUNT";
    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
    STREAM_COUNT: "STREAM_COUNT";
    BYTE_SIZE: "BYTE_SIZE";
}>;
export declare const DatasetDeclaredUnitSchema: z.ZodEnum<{
    COUNT: "COUNT";
    SECOND: "SECOND";
    MINUTE: "MINUTE";
    HOUR: "HOUR";
    BYTE: "BYTE";
}>;
export declare const DatasetDeclaredMeasurementSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    state: z.ZodLiteral<"UNKNOWN">;
    metric: z.ZodEnum<{
        RECORD_COUNT: "RECORD_COUNT";
        ROW_COUNT: "ROW_COUNT";
        COLUMN_COUNT: "COLUMN_COUNT";
        AUDIO_DURATION: "AUDIO_DURATION";
        IMAGE_COUNT: "IMAGE_COUNT";
        VIDEO_DURATION: "VIDEO_DURATION";
        DOCUMENT_COUNT: "DOCUMENT_COUNT";
        SESSION_COUNT: "SESSION_COUNT";
        PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
        STREAM_COUNT: "STREAM_COUNT";
        BYTE_SIZE: "BYTE_SIZE";
    }>;
    unit: z.ZodEnum<{
        COUNT: "COUNT";
        SECOND: "SECOND";
        MINUTE: "MINUTE";
        HOUR: "HOUR";
        BYTE: "BYTE";
    }>;
}, z.core.$strict>, z.ZodObject<{
    state: z.ZodEnum<{
        KNOWN: "KNOWN";
        ESTIMATED: "ESTIMATED";
    }>;
    value: z.ZodString;
    metric: z.ZodEnum<{
        RECORD_COUNT: "RECORD_COUNT";
        ROW_COUNT: "ROW_COUNT";
        COLUMN_COUNT: "COLUMN_COUNT";
        AUDIO_DURATION: "AUDIO_DURATION";
        IMAGE_COUNT: "IMAGE_COUNT";
        VIDEO_DURATION: "VIDEO_DURATION";
        DOCUMENT_COUNT: "DOCUMENT_COUNT";
        SESSION_COUNT: "SESSION_COUNT";
        PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
        STREAM_COUNT: "STREAM_COUNT";
        BYTE_SIZE: "BYTE_SIZE";
    }>;
    unit: z.ZodEnum<{
        COUNT: "COUNT";
        SECOND: "SECOND";
        MINUTE: "MINUTE";
        HOUR: "HOUR";
        BYTE: "BYTE";
    }>;
}, z.core.$strict>], "state">;
export declare const DatasetPreparationSampleSchema: z.ZodObject<{
    selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        UNKNOWN: "UNKNOWN";
        DESCRIBED: "DESCRIBED";
        NONE_KNOWN: "NONE_KNOWN";
    }>>>;
    omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        UNKNOWN: "UNKNOWN";
        DESCRIBED: "DESCRIBED";
        NONE_DECLARED: "NONE_DECLARED";
    }>>>;
    transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strict>;
export declare const DatasetDeclaredDateSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    precision: z.ZodLiteral<"YEAR">;
    value: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    precision: z.ZodLiteral<"MONTH">;
    value: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    precision: z.ZodLiteral<"DAY">;
    value: z.ZodISODate;
}, z.core.$strict>], "precision">;
export type DatasetDeclaredDate = z.infer<typeof DatasetDeclaredDateSchema>;
export declare const DatasetGeographicCoverageSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    state: z.ZodLiteral<"KNOWN">;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strict>, z.ZodObject<{
    state: z.ZodLiteral<"UNKNOWN">;
}, z.core.$strict>, z.ZodObject<{
    state: z.ZodLiteral<"NOT_APPLICABLE">;
}, z.core.$strict>], "state">;
export declare const DatasetCollectionPeriodSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    state: z.ZodLiteral<"KNOWN">;
    start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        precision: z.ZodLiteral<"YEAR">;
        value: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        precision: z.ZodLiteral<"MONTH">;
        value: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        precision: z.ZodLiteral<"DAY">;
        value: z.ZodISODate;
    }, z.core.$strict>], "precision">>>;
    end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        precision: z.ZodLiteral<"YEAR">;
        value: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        precision: z.ZodLiteral<"MONTH">;
        value: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        precision: z.ZodLiteral<"DAY">;
        value: z.ZodISODate;
    }, z.core.$strict>], "precision">>>;
    notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strict>, z.ZodObject<{
    state: z.ZodLiteral<"UNKNOWN">;
}, z.core.$strict>, z.ZodObject<{
    state: z.ZodLiteral<"NOT_APPLICABLE">;
}, z.core.$strict>], "state">;
export declare function formatDatasetGeographicCoverage(value: z.infer<typeof DatasetGeographicCoverageSchema> | null | undefined): string;
export declare function formatDatasetCollectionPeriod(value: z.infer<typeof DatasetCollectionPeriodSchema> | null | undefined): string;
export declare const DatasetPreparationMetadataSchema: z.ZodObject<{
    title: z.ZodString;
    uploadChoice: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        SAMPLE_ONLY: "SAMPLE_ONLY";
        FULL_ONLY: "FULL_ONLY";
        FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
    }>>>;
    primaryCategoryId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    sourceId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    license: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    modalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
        TABULAR: "TABULAR";
        AUDIO: "AUDIO";
        IMAGE: "IMAGE";
        VIDEO: "VIDEO";
        TEXT: "TEXT";
        SENSOR: "SENSOR";
    }>>>;
    contexts: z.ZodOptional<z.ZodArray<z.ZodEnum<{
        HEALTHCARE: "HEALTHCARE";
        EGOCENTRIC: "EGOCENTRIC";
    }>>>;
    superType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        CROSS_SECTIONAL: "CROSS_SECTIONAL";
        TIME_SERIES: "TIME_SERIES";
        PANEL: "PANEL";
        POOLED_CROSS_SECTIONAL: "POOLED_CROSS_SECTIONAL";
        REPEATED_CROSS_SECTIONS: "REPEATED_CROSS_SECTIONS";
        SPATIAL: "SPATIAL";
        SPATIO_TEMPORAL: "SPATIO_TEMPORAL";
        EXPERIMENTAL: "EXPERIMENTAL";
        OBSERVATIONAL: "OBSERVATIONAL";
        BIG_DATA: "BIG_DATA";
        EVENT_HISTORY_SURVIVAL: "EVENT_HISTORY_SURVIVAL";
        HIERARCHICAL_MULTILEVEL: "HIERARCHICAL_MULTILEVEL";
    }>>>;
    collectionBoundary: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    overview: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    dataQuality: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    limitations: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    collectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    possibleUses: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
    secondaryCategoryIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"KNOWN">;
        description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"NOT_APPLICABLE">;
    }, z.core.$strict>], "state">>>;
    collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"KNOWN">;
        start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            precision: z.ZodLiteral<"YEAR">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"MONTH">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"DAY">;
            value: z.ZodISODate;
        }, z.core.$strict>], "precision">>>;
        end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            precision: z.ZodLiteral<"YEAR">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"MONTH">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"DAY">;
            value: z.ZodISODate;
        }, z.core.$strict>], "precision">>>;
        notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"NOT_APPLICABLE">;
    }, z.core.$strict>], "state">>>;
    collectionMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
        metric: z.ZodEnum<{
            RECORD_COUNT: "RECORD_COUNT";
            ROW_COUNT: "ROW_COUNT";
            COLUMN_COUNT: "COLUMN_COUNT";
            AUDIO_DURATION: "AUDIO_DURATION";
            IMAGE_COUNT: "IMAGE_COUNT";
            VIDEO_DURATION: "VIDEO_DURATION";
            DOCUMENT_COUNT: "DOCUMENT_COUNT";
            SESSION_COUNT: "SESSION_COUNT";
            PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
            STREAM_COUNT: "STREAM_COUNT";
            BYTE_SIZE: "BYTE_SIZE";
        }>;
        unit: z.ZodEnum<{
            COUNT: "COUNT";
            SECOND: "SECOND";
            MINUTE: "MINUTE";
            HOUR: "HOUR";
            BYTE: "BYTE";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodEnum<{
            KNOWN: "KNOWN";
            ESTIMATED: "ESTIMATED";
        }>;
        value: z.ZodString;
        metric: z.ZodEnum<{
            RECORD_COUNT: "RECORD_COUNT";
            ROW_COUNT: "ROW_COUNT";
            COLUMN_COUNT: "COLUMN_COUNT";
            AUDIO_DURATION: "AUDIO_DURATION";
            IMAGE_COUNT: "IMAGE_COUNT";
            VIDEO_DURATION: "VIDEO_DURATION";
            DOCUMENT_COUNT: "DOCUMENT_COUNT";
            SESSION_COUNT: "SESSION_COUNT";
            PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
            STREAM_COUNT: "STREAM_COUNT";
            BYTE_SIZE: "BYTE_SIZE";
        }>;
        unit: z.ZodEnum<{
            COUNT: "COUNT";
            SECOND: "SECOND";
            MINUTE: "MINUTE";
            HOUR: "HOUR";
            BYTE: "BYTE";
        }>;
    }, z.core.$strict>], "state">>>;
    fullMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
        metric: z.ZodEnum<{
            RECORD_COUNT: "RECORD_COUNT";
            ROW_COUNT: "ROW_COUNT";
            COLUMN_COUNT: "COLUMN_COUNT";
            AUDIO_DURATION: "AUDIO_DURATION";
            IMAGE_COUNT: "IMAGE_COUNT";
            VIDEO_DURATION: "VIDEO_DURATION";
            DOCUMENT_COUNT: "DOCUMENT_COUNT";
            SESSION_COUNT: "SESSION_COUNT";
            PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
            STREAM_COUNT: "STREAM_COUNT";
            BYTE_SIZE: "BYTE_SIZE";
        }>;
        unit: z.ZodEnum<{
            COUNT: "COUNT";
            SECOND: "SECOND";
            MINUTE: "MINUTE";
            HOUR: "HOUR";
            BYTE: "BYTE";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodEnum<{
            KNOWN: "KNOWN";
            ESTIMATED: "ESTIMATED";
        }>;
        value: z.ZodString;
        metric: z.ZodEnum<{
            RECORD_COUNT: "RECORD_COUNT";
            ROW_COUNT: "ROW_COUNT";
            COLUMN_COUNT: "COLUMN_COUNT";
            AUDIO_DURATION: "AUDIO_DURATION";
            IMAGE_COUNT: "IMAGE_COUNT";
            VIDEO_DURATION: "VIDEO_DURATION";
            DOCUMENT_COUNT: "DOCUMENT_COUNT";
            SESSION_COUNT: "SESSION_COUNT";
            PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
            STREAM_COUNT: "STREAM_COUNT";
            BYTE_SIZE: "BYTE_SIZE";
        }>;
        unit: z.ZodEnum<{
            COUNT: "COUNT";
            SECOND: "SECOND";
            MINUTE: "MINUTE";
            HOUR: "HOUR";
            BYTE: "BYTE";
        }>;
    }, z.core.$strict>], "state">>>;
    sampleMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
        metric: z.ZodEnum<{
            RECORD_COUNT: "RECORD_COUNT";
            ROW_COUNT: "ROW_COUNT";
            COLUMN_COUNT: "COLUMN_COUNT";
            AUDIO_DURATION: "AUDIO_DURATION";
            IMAGE_COUNT: "IMAGE_COUNT";
            VIDEO_DURATION: "VIDEO_DURATION";
            DOCUMENT_COUNT: "DOCUMENT_COUNT";
            SESSION_COUNT: "SESSION_COUNT";
            PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
            STREAM_COUNT: "STREAM_COUNT";
            BYTE_SIZE: "BYTE_SIZE";
        }>;
        unit: z.ZodEnum<{
            COUNT: "COUNT";
            SECOND: "SECOND";
            MINUTE: "MINUTE";
            HOUR: "HOUR";
            BYTE: "BYTE";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodEnum<{
            KNOWN: "KNOWN";
            ESTIMATED: "ESTIMATED";
        }>;
        value: z.ZodString;
        metric: z.ZodEnum<{
            RECORD_COUNT: "RECORD_COUNT";
            ROW_COUNT: "ROW_COUNT";
            COLUMN_COUNT: "COLUMN_COUNT";
            AUDIO_DURATION: "AUDIO_DURATION";
            IMAGE_COUNT: "IMAGE_COUNT";
            VIDEO_DURATION: "VIDEO_DURATION";
            DOCUMENT_COUNT: "DOCUMENT_COUNT";
            SESSION_COUNT: "SESSION_COUNT";
            PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
            STREAM_COUNT: "STREAM_COUNT";
            BYTE_SIZE: "BYTE_SIZE";
        }>;
        unit: z.ZodEnum<{
            COUNT: "COUNT";
            SECOND: "SECOND";
            MINUTE: "MINUTE";
            HOUR: "HOUR";
            BYTE: "BYTE";
        }>;
    }, z.core.$strict>], "state">>>;
    sample: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            DESCRIBED: "DESCRIBED";
            NONE_KNOWN: "NONE_KNOWN";
        }>>>;
        omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            DESCRIBED: "DESCRIBED";
            NONE_DECLARED: "NONE_DECLARED";
        }>>>;
        transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>>;
    fullCompleteness: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    profiles: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        tabular: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
        }, z.core.$strict>>>;
        audio: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                SPEECH: "SPEECH";
                NON_SPEECH: "NON_SPEECH";
                MIXED: "MIXED";
            }>>>;
            languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
            recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
            transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                UNTIMED: "UNTIMED";
                TIMED: "TIMED";
            }>>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        images: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        video: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                WHOLE_ITEM: "WHOLE_ITEM";
                TIME_OR_FRAME: "TIME_OR_FRAME";
            }>>>;
        }, z.core.$strict>>>;
        text: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                MIXED: "MIXED";
                HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                NON_LANGUAGE: "NON_LANGUAGE";
            }>>>;
            languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        sensors: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                NO_CLAIM: "NO_CLAIM";
                DESCRIBED: "DESCRIBED";
            }>>>;
            synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
            calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        egocentric: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        healthcare: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type DatasetPreparationMetadata = z.infer<typeof DatasetPreparationMetadataSchema>;
export type DatasetPreparationProfiles = z.infer<typeof DatasetPreparationProfilesSchema>;
export declare function isDatasetPreparationProfileFieldApplicable(profile: keyof DatasetPreparationProfiles, field: string, values: Record<string, unknown>): boolean;
export type DatasetDeclaredMeasurement = z.infer<typeof DatasetDeclaredMeasurementSchema>;
export type DatasetUploadChoice = z.infer<typeof DatasetUploadChoiceSchema>;
export type DatasetModality = z.infer<typeof DatasetModalitySchema>;
export declare const DatasetEditBaseResponseSchema: z.ZodObject<{
    context: z.ZodObject<{
        datasetId: z.ZodString;
        operation: z.ZodEnum<{
            METADATA: "METADATA";
            PRICING: "PRICING";
            MATERIALS: "MATERIALS";
        }>;
        preparationGeneration: z.ZodNumber;
        workflowRevision: z.ZodNumber;
        managementContext: z.ZodEnum<{
            INITIAL_PROPOSAL: "INITIAL_PROPOSAL";
            MANAGED: "MANAGED";
        }>;
        editable: z.ZodBoolean;
        precondition: z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            mode: z.ZodLiteral<"EXISTING_DRAFT">;
            expectedContentId: z.ZodString;
            expectedGeneration: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            mode: z.ZodLiteral<"INITIALIZE">;
            expectedWorkflowRevision: z.ZodNumber;
            context: z.ZodEnum<{
                REQUESTED_CHANGES: "REQUESTED_CHANGES";
                MANAGED_EDIT: "MANAGED_EDIT";
                APPROVED_REEDIT: "APPROVED_REEDIT";
                PLATFORM_WITHDRAWAL: "PLATFORM_WITHDRAWAL";
                PLATFORM_PUBLISHED_METADATA: "PLATFORM_PUBLISHED_METADATA";
            }>;
            expectedBaseContentId: z.ZodString;
        }, z.core.$strict>], "mode">>;
        reason: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    metadataSource: z.ZodEnum<{
        CURRENT_DRAFT: "CURRENT_DRAFT";
        FROZEN_BASE: "FROZEN_BASE";
        CURRENT_METADATA: "CURRENT_METADATA";
    }>;
    metadata: z.ZodObject<{
        title: z.ZodString;
        uploadChoice: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>>>;
        primaryCategoryId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        sourceId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        license: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        modalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            TABULAR: "TABULAR";
            AUDIO: "AUDIO";
            IMAGE: "IMAGE";
            VIDEO: "VIDEO";
            TEXT: "TEXT";
            SENSOR: "SENSOR";
        }>>>;
        contexts: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            HEALTHCARE: "HEALTHCARE";
            EGOCENTRIC: "EGOCENTRIC";
        }>>>;
        superType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            CROSS_SECTIONAL: "CROSS_SECTIONAL";
            TIME_SERIES: "TIME_SERIES";
            PANEL: "PANEL";
            POOLED_CROSS_SECTIONAL: "POOLED_CROSS_SECTIONAL";
            REPEATED_CROSS_SECTIONS: "REPEATED_CROSS_SECTIONS";
            SPATIAL: "SPATIAL";
            SPATIO_TEMPORAL: "SPATIO_TEMPORAL";
            EXPERIMENTAL: "EXPERIMENTAL";
            OBSERVATIONAL: "OBSERVATIONAL";
            BIG_DATA: "BIG_DATA";
            EVENT_HISTORY_SURVIVAL: "EVENT_HISTORY_SURVIVAL";
            HIERARCHICAL_MULTILEVEL: "HIERARCHICAL_MULTILEVEL";
        }>>>;
        collectionBoundary: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        overview: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        dataQuality: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        limitations: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        collectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        possibleUses: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
        secondaryCategoryIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"KNOWN">;
            description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"NOT_APPLICABLE">;
        }, z.core.$strict>], "state">>>;
        collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"KNOWN">;
            start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                precision: z.ZodLiteral<"YEAR">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"MONTH">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"DAY">;
                value: z.ZodISODate;
            }, z.core.$strict>], "precision">>>;
            end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                precision: z.ZodLiteral<"YEAR">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"MONTH">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"DAY">;
                value: z.ZodISODate;
            }, z.core.$strict>], "precision">>>;
            notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"NOT_APPLICABLE">;
        }, z.core.$strict>], "state">>>;
        collectionMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>>;
        fullMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>>;
        sampleMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>>;
        sample: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                DESCRIBED: "DESCRIBED";
                NONE_KNOWN: "NONE_KNOWN";
            }>>>;
            omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                DESCRIBED: "DESCRIBED";
                NONE_DECLARED: "NONE_DECLARED";
            }>>>;
            transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        fullCompleteness: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        profiles: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            tabular: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
            }, z.core.$strict>>>;
            audio: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    SPEECH: "SPEECH";
                    NON_SPEECH: "NON_SPEECH";
                    MIXED: "MIXED";
                }>>>;
                languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    UNTIMED: "UNTIMED";
                    TIMED: "TIMED";
                }>>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            images: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            video: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    WHOLE_ITEM: "WHOLE_ITEM";
                    TIME_OR_FRAME: "TIME_OR_FRAME";
                }>>>;
            }, z.core.$strict>>>;
            text: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    MIXED: "MIXED";
                    HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                    NON_LANGUAGE: "NON_LANGUAGE";
                }>>>;
                languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            sensors: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    NO_CLAIM: "NO_CLAIM";
                    DESCRIBED: "DESCRIBED";
                }>>>;
                synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            egocentric: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            healthcare: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
    contentReference: z.ZodNullable<z.ZodObject<{
        contentId: z.ZodString;
        generation: z.ZodNumber;
        frozen: z.ZodBoolean;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetPreparationCreateBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    metadata: z.ZodObject<{
        title: z.ZodString;
        uploadChoice: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>>>;
        primaryCategoryId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        sourceId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        license: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        modalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            TABULAR: "TABULAR";
            AUDIO: "AUDIO";
            IMAGE: "IMAGE";
            VIDEO: "VIDEO";
            TEXT: "TEXT";
            SENSOR: "SENSOR";
        }>>>;
        contexts: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            HEALTHCARE: "HEALTHCARE";
            EGOCENTRIC: "EGOCENTRIC";
        }>>>;
        superType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            CROSS_SECTIONAL: "CROSS_SECTIONAL";
            TIME_SERIES: "TIME_SERIES";
            PANEL: "PANEL";
            POOLED_CROSS_SECTIONAL: "POOLED_CROSS_SECTIONAL";
            REPEATED_CROSS_SECTIONS: "REPEATED_CROSS_SECTIONS";
            SPATIAL: "SPATIAL";
            SPATIO_TEMPORAL: "SPATIO_TEMPORAL";
            EXPERIMENTAL: "EXPERIMENTAL";
            OBSERVATIONAL: "OBSERVATIONAL";
            BIG_DATA: "BIG_DATA";
            EVENT_HISTORY_SURVIVAL: "EVENT_HISTORY_SURVIVAL";
            HIERARCHICAL_MULTILEVEL: "HIERARCHICAL_MULTILEVEL";
        }>>>;
        collectionBoundary: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        overview: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        dataQuality: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        limitations: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        collectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        possibleUses: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
        secondaryCategoryIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"KNOWN">;
            description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"NOT_APPLICABLE">;
        }, z.core.$strict>], "state">>>;
        collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"KNOWN">;
            start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                precision: z.ZodLiteral<"YEAR">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"MONTH">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"DAY">;
                value: z.ZodISODate;
            }, z.core.$strict>], "precision">>>;
            end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                precision: z.ZodLiteral<"YEAR">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"MONTH">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"DAY">;
                value: z.ZodISODate;
            }, z.core.$strict>], "precision">>>;
            notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"NOT_APPLICABLE">;
        }, z.core.$strict>], "state">>>;
        collectionMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>>;
        fullMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>>;
        sampleMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>>;
        sample: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                DESCRIBED: "DESCRIBED";
                NONE_KNOWN: "NONE_KNOWN";
            }>>>;
            omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                DESCRIBED: "DESCRIBED";
                NONE_DECLARED: "NONE_DECLARED";
            }>>>;
            transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        fullCompleteness: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        profiles: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            tabular: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
            }, z.core.$strict>>>;
            audio: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    SPEECH: "SPEECH";
                    NON_SPEECH: "NON_SPEECH";
                    MIXED: "MIXED";
                }>>>;
                languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    UNTIMED: "UNTIMED";
                    TIMED: "TIMED";
                }>>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            images: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            video: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    WHOLE_ITEM: "WHOLE_ITEM";
                    TIME_OR_FRAME: "TIME_OR_FRAME";
                }>>>;
            }, z.core.$strict>>>;
            text: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    MIXED: "MIXED";
                    HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                    NON_LANGUAGE: "NON_LANGUAGE";
                }>>>;
                languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            sensors: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    NO_CLAIM: "NO_CLAIM";
                    DESCRIBED: "DESCRIBED";
                }>>>;
                synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            egocentric: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            healthcare: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetPreparationPatchBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedGeneration: z.ZodNumber;
    legacyBaseFingerprint: z.ZodOptional<z.ZodString>;
    editContext: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodLiteral<"EXISTING_DRAFT">;
        expectedContentId: z.ZodString;
        expectedGeneration: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"INITIALIZE">;
        expectedWorkflowRevision: z.ZodNumber;
        context: z.ZodEnum<{
            REQUESTED_CHANGES: "REQUESTED_CHANGES";
            MANAGED_EDIT: "MANAGED_EDIT";
            APPROVED_REEDIT: "APPROVED_REEDIT";
            PLATFORM_WITHDRAWAL: "PLATFORM_WITHDRAWAL";
            PLATFORM_PUBLISHED_METADATA: "PLATFORM_PUBLISHED_METADATA";
        }>;
        expectedBaseContentId: z.ZodString;
    }, z.core.$strict>], "mode">>;
    changes: z.ZodObject<{
        title: z.ZodOptional<z.ZodString>;
        uploadChoice: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>>>>;
        primaryCategoryId: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        sourceId: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        license: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        modalities: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodEnum<{
            TABULAR: "TABULAR";
            AUDIO: "AUDIO";
            IMAGE: "IMAGE";
            VIDEO: "VIDEO";
            TEXT: "TEXT";
            SENSOR: "SENSOR";
        }>>>>;
        contexts: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodEnum<{
            HEALTHCARE: "HEALTHCARE";
            EGOCENTRIC: "EGOCENTRIC";
        }>>>>;
        superType: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            CROSS_SECTIONAL: "CROSS_SECTIONAL";
            TIME_SERIES: "TIME_SERIES";
            PANEL: "PANEL";
            POOLED_CROSS_SECTIONAL: "POOLED_CROSS_SECTIONAL";
            REPEATED_CROSS_SECTIONS: "REPEATED_CROSS_SECTIONS";
            SPATIAL: "SPATIAL";
            SPATIO_TEMPORAL: "SPATIO_TEMPORAL";
            EXPERIMENTAL: "EXPERIMENTAL";
            OBSERVATIONAL: "OBSERVATIONAL";
            BIG_DATA: "BIG_DATA";
            EVENT_HISTORY_SURVIVAL: "EVENT_HISTORY_SURVIVAL";
            HIERARCHICAL_MULTILEVEL: "HIERARCHICAL_MULTILEVEL";
        }>>>>;
        collectionBoundary: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        overview: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        description: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        dataQuality: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        limitations: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        collectionMethod: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        possibleUses: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        tags: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodString>>>;
        secondaryCategoryIds: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodString>>>;
        geographicCoverage: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"KNOWN">;
            description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"NOT_APPLICABLE">;
        }, z.core.$strict>], "state">>>>;
        collectionPeriod: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"KNOWN">;
            start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                precision: z.ZodLiteral<"YEAR">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"MONTH">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"DAY">;
                value: z.ZodISODate;
            }, z.core.$strict>], "precision">>>;
            end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                precision: z.ZodLiteral<"YEAR">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"MONTH">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"DAY">;
                value: z.ZodISODate;
            }, z.core.$strict>], "precision">>>;
            notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"NOT_APPLICABLE">;
        }, z.core.$strict>], "state">>>>;
        collectionMeasurements: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>>>;
        fullMeasurements: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>>>;
        sampleMeasurements: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>>>;
        sample: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodObject<{
            selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                DESCRIBED: "DESCRIBED";
                NONE_KNOWN: "NONE_KNOWN";
            }>>>;
            omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                DESCRIBED: "DESCRIBED";
                NONE_DECLARED: "NONE_DECLARED";
            }>>>;
            transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>>;
        fullCompleteness: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodBoolean>>>;
        profiles: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodObject<{
            tabular: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
            }, z.core.$strict>>>;
            audio: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    SPEECH: "SPEECH";
                    NON_SPEECH: "NON_SPEECH";
                    MIXED: "MIXED";
                }>>>;
                languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    UNTIMED: "UNTIMED";
                    TIMED: "TIMED";
                }>>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            images: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            video: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    WHOLE_ITEM: "WHOLE_ITEM";
                    TIME_OR_FRAME: "TIME_OR_FRAME";
                }>>>;
            }, z.core.$strict>>>;
            text: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    MIXED: "MIXED";
                    HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                    NON_LANGUAGE: "NON_LANGUAGE";
                }>>>;
                languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            sensors: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    NO_CLAIM: "NO_CLAIM";
                    DESCRIBED: "DESCRIBED";
                }>>>;
                synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            egocentric: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            healthcare: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>>>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetPreparationIdParamsSchema: z.ZodObject<{
    draftId: z.ZodString;
}, z.core.$strict>;
export declare const DatasetPreparationsListQuerySchema: z.ZodObject<{
    page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    q: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetPreparationCatalogLabelsQuerySchema: z.ZodObject<{
    primaryCategoryId: z.ZodOptional<z.ZodString>;
    sourceId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetPreparationCatalogLabelsResponseSchema: z.ZodObject<{
    primaryCategory: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
    }, z.core.$strict>>;
    source: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type DatasetPreparationCatalogLabelsQuery = z.infer<typeof DatasetPreparationCatalogLabelsQuerySchema>;
export type DatasetPreparationCatalogLabelsResponse = z.infer<typeof DatasetPreparationCatalogLabelsResponseSchema>;
export declare const DatasetPreparationReadinessSchema: z.ZodObject<{
    canSubmit: z.ZodLiteral<false>;
    issues: z.ZodArray<z.ZodObject<{
        code: z.ZodString;
        field: z.ZodOptional<z.ZodString>;
        message: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type DatasetPreparationReadiness = z.infer<typeof DatasetPreparationReadinessSchema>;
export declare const DatasetPreparationResponseSchema: z.ZodObject<{
    contractVersion: z.ZodLiteral<1>;
    id: z.ZodString;
    generation: z.ZodNumber;
    metadata: z.ZodObject<{
        title: z.ZodString;
        uploadChoice: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>>>;
        primaryCategoryId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        sourceId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        license: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        modalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            TABULAR: "TABULAR";
            AUDIO: "AUDIO";
            IMAGE: "IMAGE";
            VIDEO: "VIDEO";
            TEXT: "TEXT";
            SENSOR: "SENSOR";
        }>>>;
        contexts: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            HEALTHCARE: "HEALTHCARE";
            EGOCENTRIC: "EGOCENTRIC";
        }>>>;
        superType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            CROSS_SECTIONAL: "CROSS_SECTIONAL";
            TIME_SERIES: "TIME_SERIES";
            PANEL: "PANEL";
            POOLED_CROSS_SECTIONAL: "POOLED_CROSS_SECTIONAL";
            REPEATED_CROSS_SECTIONS: "REPEATED_CROSS_SECTIONS";
            SPATIAL: "SPATIAL";
            SPATIO_TEMPORAL: "SPATIO_TEMPORAL";
            EXPERIMENTAL: "EXPERIMENTAL";
            OBSERVATIONAL: "OBSERVATIONAL";
            BIG_DATA: "BIG_DATA";
            EVENT_HISTORY_SURVIVAL: "EVENT_HISTORY_SURVIVAL";
            HIERARCHICAL_MULTILEVEL: "HIERARCHICAL_MULTILEVEL";
        }>>>;
        collectionBoundary: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        overview: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        dataQuality: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        limitations: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        collectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        possibleUses: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
        secondaryCategoryIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"KNOWN">;
            description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"NOT_APPLICABLE">;
        }, z.core.$strict>], "state">>>;
        collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"KNOWN">;
            start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                precision: z.ZodLiteral<"YEAR">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"MONTH">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"DAY">;
                value: z.ZodISODate;
            }, z.core.$strict>], "precision">>>;
            end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                precision: z.ZodLiteral<"YEAR">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"MONTH">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"DAY">;
                value: z.ZodISODate;
            }, z.core.$strict>], "precision">>>;
            notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"NOT_APPLICABLE">;
        }, z.core.$strict>], "state">>>;
        collectionMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>>;
        fullMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>>;
        sampleMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>>;
        sample: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                DESCRIBED: "DESCRIBED";
                NONE_KNOWN: "NONE_KNOWN";
            }>>>;
            omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                DESCRIBED: "DESCRIBED";
                NONE_DECLARED: "NONE_DECLARED";
            }>>>;
            transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        fullCompleteness: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        profiles: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            tabular: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
            }, z.core.$strict>>>;
            audio: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    SPEECH: "SPEECH";
                    NON_SPEECH: "NON_SPEECH";
                    MIXED: "MIXED";
                }>>>;
                languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    UNTIMED: "UNTIMED";
                    TIMED: "TIMED";
                }>>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            images: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            video: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    WHOLE_ITEM: "WHOLE_ITEM";
                    TIME_OR_FRAME: "TIME_OR_FRAME";
                }>>>;
            }, z.core.$strict>>>;
            text: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    MIXED: "MIXED";
                    HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                    NON_LANGUAGE: "NON_LANGUAGE";
                }>>>;
                languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            sensors: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    NO_CLAIM: "NO_CLAIM";
                    DESCRIBED: "DESCRIBED";
                }>>>;
                synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                    UNKNOWN: "UNKNOWN";
                }>>>;
                calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            egocentric: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            healthcare: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
    readiness: z.ZodObject<{
        canSubmit: z.ZodLiteral<false>;
        issues: z.ZodArray<z.ZodObject<{
            code: z.ZodString;
            field: z.ZodOptional<z.ZodString>;
            message: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    legacyBaseFingerprint: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetPreparationsListResponseSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        contractVersion: z.ZodLiteral<1>;
        id: z.ZodString;
        generation: z.ZodNumber;
        metadata: z.ZodObject<{
            title: z.ZodString;
            uploadChoice: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                SAMPLE_ONLY: "SAMPLE_ONLY";
                FULL_ONLY: "FULL_ONLY";
                FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
            }>>>;
            primaryCategoryId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            sourceId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            license: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            modalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                TABULAR: "TABULAR";
                AUDIO: "AUDIO";
                IMAGE: "IMAGE";
                VIDEO: "VIDEO";
                TEXT: "TEXT";
                SENSOR: "SENSOR";
            }>>>;
            contexts: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                HEALTHCARE: "HEALTHCARE";
                EGOCENTRIC: "EGOCENTRIC";
            }>>>;
            superType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                CROSS_SECTIONAL: "CROSS_SECTIONAL";
                TIME_SERIES: "TIME_SERIES";
                PANEL: "PANEL";
                POOLED_CROSS_SECTIONAL: "POOLED_CROSS_SECTIONAL";
                REPEATED_CROSS_SECTIONS: "REPEATED_CROSS_SECTIONS";
                SPATIAL: "SPATIAL";
                SPATIO_TEMPORAL: "SPATIO_TEMPORAL";
                EXPERIMENTAL: "EXPERIMENTAL";
                OBSERVATIONAL: "OBSERVATIONAL";
                BIG_DATA: "BIG_DATA";
                EVENT_HISTORY_SURVIVAL: "EVENT_HISTORY_SURVIVAL";
                HIERARCHICAL_MULTILEVEL: "HIERARCHICAL_MULTILEVEL";
            }>>>;
            collectionBoundary: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            overview: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            dataQuality: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            limitations: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            collectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            possibleUses: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
            secondaryCategoryIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
            geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"KNOWN">;
                description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"NOT_APPLICABLE">;
            }, z.core.$strict>], "state">>>;
            collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"KNOWN">;
                start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    precision: z.ZodLiteral<"YEAR">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"MONTH">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"DAY">;
                    value: z.ZodISODate;
                }, z.core.$strict>], "precision">>>;
                end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    precision: z.ZodLiteral<"YEAR">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"MONTH">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"DAY">;
                    value: z.ZodISODate;
                }, z.core.$strict>], "precision">>>;
                notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"NOT_APPLICABLE">;
            }, z.core.$strict>], "state">>>;
            collectionMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>>;
            fullMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>>;
            sampleMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>>;
            sample: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    DESCRIBED: "DESCRIBED";
                    NONE_KNOWN: "NONE_KNOWN";
                }>>>;
                omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    DESCRIBED: "DESCRIBED";
                    NONE_DECLARED: "NONE_DECLARED";
                }>>>;
                transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            fullCompleteness: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            profiles: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                tabular: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                }, z.core.$strict>>>;
                audio: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        SPEECH: "SPEECH";
                        NON_SPEECH: "NON_SPEECH";
                        MIXED: "MIXED";
                    }>>>;
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        UNTIMED: "UNTIMED";
                        TIMED: "TIMED";
                    }>>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                images: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                video: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        WHOLE_ITEM: "WHOLE_ITEM";
                        TIME_OR_FRAME: "TIME_OR_FRAME";
                    }>>>;
                }, z.core.$strict>>>;
                text: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        MIXED: "MIXED";
                        HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                        NON_LANGUAGE: "NON_LANGUAGE";
                    }>>>;
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                sensors: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>>;
                    channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        NO_CLAIM: "NO_CLAIM";
                        DESCRIBED: "DESCRIBED";
                    }>>>;
                    synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                egocentric: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                healthcare: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
        readiness: z.ZodObject<{
            canSubmit: z.ZodLiteral<false>;
            issues: z.ZodArray<z.ZodObject<{
                code: z.ZodString;
                field: z.ZodOptional<z.ZodString>;
                message: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        legacyBaseFingerprint: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    page: z.ZodNumber;
    limit: z.ZodNumber;
    total: z.ZodNumber;
}, z.core.$strict>;
export type DatasetPreparationResponse = z.infer<typeof DatasetPreparationResponseSchema>;
export type DatasetPreparationsListResponse = z.infer<typeof DatasetPreparationsListResponseSchema>;
export type DatasetPreparationCreateBody = z.infer<typeof DatasetPreparationCreateBodySchema>;
export type DatasetPreparationPatchBody = z.infer<typeof DatasetPreparationPatchBodySchema>;
export type DatasetPreparationsListQuery = z.infer<typeof DatasetPreparationsListQuerySchema>;
export declare const DatasetDraftWorkspaceQuerySchema: z.ZodObject<{
    page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    q: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetDraftWorkspaceItemSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodLiteral<"PREPARATION">;
    datasetUniqueId: z.ZodNullable<z.ZodString>;
    uploadChoice: z.ZodNullable<z.ZodEnum<{
        SAMPLE_ONLY: "SAMPLE_ONLY";
        FULL_ONLY: "FULL_ONLY";
        FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
    }>>;
    currentUploadId: z.ZodNull;
    title: z.ZodString;
    updatedAt: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodLiteral<"PROPOSAL">;
    datasetUniqueId: z.ZodString;
    uploadChoice: z.ZodNull;
    currentUploadId: z.ZodNullable<z.ZodString>;
    guidedEditorAvailable: z.ZodOptional<z.ZodBoolean>;
    title: z.ZodString;
    updatedAt: z.ZodString;
}, z.core.$strict>], "kind">;
export declare const DatasetDraftWorkspaceResponseSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodLiteral<"PREPARATION">;
        datasetUniqueId: z.ZodNullable<z.ZodString>;
        uploadChoice: z.ZodNullable<z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>>;
        currentUploadId: z.ZodNull;
        title: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodLiteral<"PROPOSAL">;
        datasetUniqueId: z.ZodString;
        uploadChoice: z.ZodNull;
        currentUploadId: z.ZodNullable<z.ZodString>;
        guidedEditorAvailable: z.ZodOptional<z.ZodBoolean>;
        title: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strict>], "kind">>;
    page: z.ZodNumber;
    limit: z.ZodNumber;
    total: z.ZodNumber;
    summary: z.ZodObject<{
        total: z.ZodNumber;
        withCurrentUpload: z.ZodNumber;
        withoutCurrentUpload: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>;
export type DatasetDraftWorkspaceQuery = z.infer<typeof DatasetDraftWorkspaceQuerySchema>;
export type DatasetDraftWorkspaceItem = z.infer<typeof DatasetDraftWorkspaceItemSchema>;
export type DatasetDraftWorkspaceResponse = z.infer<typeof DatasetDraftWorkspaceResponseSchema>;
export declare function getDatasetPreparationReadiness(metadata: DatasetPreparationMetadata): DatasetPreparationReadiness;
//# sourceMappingURL=preparation.schema.d.ts.map