"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetCatalogueDetailResponseSchema = exports.DatasetCatalogueListResponseSchema = exports.DatasetCatalogueCardSchema = exports.DatasetCanonicalCatalogueCardSchema = exports.DatasetCatalogueMaterialSummarySchema = exports.DatasetCatalogueListQuerySchema = void 0;
const zod_1 = require("zod");
const preparation_schema_1 = require("./preparation.schema");
const reader_schema_1 = require("./reader.schema");
const legacyCatalogue_schema_1 = require("./legacyCatalogue.schema");
const legacyCatalogueEndpoints_schema_1 = require("./legacyCatalogueEndpoints.schema");
const category_schema_1 = require("./category.schema");
const id = zod_1.z.string().min(1).max(128);
const label = zod_1.z.object({ id, name: zod_1.z.string().min(1).max(1_000) }).strict();
const listInput = (schema, maximum) => zod_1.z.preprocess(value => value === undefined ? undefined : Array.isArray(value) ? value : [value], zod_1.z.array(schema).min(1).max(maximum)
    .refine(values => new Set(values).size === values.length, "Choose each filter once").optional());
exports.DatasetCatalogueListQuerySchema = legacyCatalogueEndpoints_schema_1.MarketplaceDatasetsListQuerySchema.extend({
    expectedCategoryRevision: category_schema_1.DatasetCategoryDirectoryQuerySchema.shape.expectedRevision,
    page: zod_1.z.coerce.number().int().min(1).max(10_000).default(1),
    pageSize: zod_1.z.coerce.number().int().min(1).max(50).default(20),
    modalities: listInput(preparation_schema_1.DatasetModalitySchema, 6), contexts: listInput(preparation_schema_1.DatasetContextSchema, 2),
    uploadChoice: preparation_schema_1.DatasetUploadChoiceSchema.optional(),
    categoryIds: listInput(id, 20), tags: listInput(zod_1.z.string().min(1).max(80), 20),
    country: zod_1.z.string().min(1).max(200).optional(), state: zod_1.z.string().min(1).max(200).optional(),
    city: zod_1.z.string().min(1).max(200).optional(),
}).strict();
exports.DatasetCatalogueMaterialSummarySchema = zod_1.z.object({ component: zod_1.z.enum(["FULL", "SAMPLE"]),
    origin: zod_1.z.literal("SELECTED_PHYSICAL_FILES"), fileCount: zod_1.z.number().int().min(1).max(1_000),
    sizeBytes: zod_1.z.string().regex(/^[0-9]{1,16}$/),
}).strict();
const purchase = zod_1.z.object({ mode: zod_1.z.enum(["DISPLAY_ONLY", "FREE_CLAIM", "PAID_CHECKOUT", "UNAVAILABLE"]),
    component: zod_1.z.literal("FULL").nullable(), pricing: legacyCatalogue_schema_1.MarketplaceDatasetPriceSurfaceDtoSchema.nullable(),
    pricingReference: zod_1.z.object({ id, revision: zod_1.z.number().int().nonnegative() }).strict().nullable(),
    // This is published offer metadata. Acquisition/delivery recheck current
    // security, capacity, exact target, ownership and price on their own APIs.
    eligibilityCheckRequired: zod_1.z.literal(true),
}).strict().refine(value => value.mode === "DISPLAY_ONLY" ? value.component === null && value.pricing === null && value.pricingReference === null :
    value.component === "FULL" && (value.mode === "UNAVAILABLE" ? value.pricing === null && value.pricingReference === null :
        value.pricing !== null && value.pricingReference !== null), "Purchase metadata must match the uploaded material");
exports.DatasetCanonicalCatalogueCardSchema = zod_1.z.object({
    id, datasetUniqueId: zod_1.z.string().min(1).max(128), title: zod_1.z.string().min(1).max(200), status: zod_1.z.literal("PUBLISHED"),
    license: zod_1.z.string().min(1).max(1_000), owner: legacyCatalogue_schema_1.MarketplaceOwnerDtoSchema,
    publication: zod_1.z.object({ id, contentId: zod_1.z.string().cuid(), publishedAt: zod_1.z.string().datetime() }).strict(),
    overview: zod_1.z.string().min(1).max(4_000), uploadChoice: preparation_schema_1.DatasetUploadChoiceSchema,
    modalities: zod_1.z.array(preparation_schema_1.DatasetModalitySchema).min(1).max(6), contexts: zod_1.z.array(preparation_schema_1.DatasetContextSchema).max(2),
    category: label, categoryAtFreeze: label, categoryNameOrigin: zod_1.z.enum(["CURRENT_CATEGORY", "CAPTURED_CATEGORY"]),
    tags: zod_1.z.array(zod_1.z.string().max(80)).max(20),
    measurements: reader_schema_1.DatasetPublicDescriptionSchema.shape.measurements,
    materials: zod_1.z.array(exports.DatasetCatalogueMaterialSummarySchema).min(1).max(2),
    assessment: zod_1.z.object({ score: zod_1.z.string().regex(/^[0-9]+(?:\.[0-9]+)?$/),
        scope: zod_1.z.literal("UPLOADED_COMPONENTS"), components: zod_1.z.array(zod_1.z.enum(["FULL", "SAMPLE"])).min(1).max(2),
        representedCollection: zod_1.z.literal("SUPPLIER_DECLARATION"),
    }).strict(),
    purchase,
    stats: zod_1.z.object({ viewCount: zod_1.z.number().int().nonnegative(), downloadCount: zod_1.z.number().int().nonnegative(),
        reviewCount: zod_1.z.number().int().nonnegative(), rating: zod_1.z.string().nullable() }).strict(),
    searchScore: zod_1.z.number().nullable(), createdAt: zod_1.z.string().datetime(), updatedAt: zod_1.z.string().datetime(),
}).strict().refine(value => {
    const expected = value.uploadChoice === "FULL_AND_SAMPLE" ? ["FULL", "SAMPLE"] :
        [value.uploadChoice === "SAMPLE_ONLY" ? "SAMPLE" : "FULL"];
    return value.materials.length === expected.length && expected.every(component => value.materials.some(item => item.component === component)) &&
        value.assessment.components.length === expected.length && expected.every(component => value.assessment.components.includes(component)) &&
        (value.uploadChoice === "SAMPLE_ONLY" ? value.purchase.mode === "DISPLAY_ONLY" : value.purchase.mode !== "DISPLAY_ONLY");
}, "Material summaries and offer metadata must describe the exact published upload choice");
exports.DatasetCatalogueCardSchema = zod_1.z.discriminatedUnion("representation", [
    zod_1.z.object({ representation: zod_1.z.literal("LEGACY"), legacy: legacyCatalogue_schema_1.MarketplaceDatasetListItemDtoSchema }).strict(),
    zod_1.z.object({ representation: zod_1.z.literal("CONTENT"), item: exports.DatasetCanonicalCatalogueCardSchema }).strict(),
]);
exports.DatasetCatalogueListResponseSchema = zod_1.z.object({ items: zod_1.z.array(exports.DatasetCatalogueCardSchema).max(50),
    page: zod_1.z.number().int().positive(), pageSize: zod_1.z.number().int().min(1).max(50), total: zod_1.z.number().int().nonnegative(),
}).strict();
exports.DatasetCatalogueDetailResponseSchema = zod_1.z.discriminatedUnion("representation", [
    zod_1.z.object({ representation: zod_1.z.literal("LEGACY"), legacy: legacyCatalogue_schema_1.MarketplaceDatasetDetailsDtoSchema }).strict(),
    zod_1.z.object({ representation: zod_1.z.literal("CONTENT"), item: exports.DatasetCanonicalCatalogueCardSchema,
        description: reader_schema_1.DatasetPublicDescriptionSchema,
        currentCategoryFacts: zod_1.z.array(label).max(11),
        currentSourceFacts: zod_1.z.object({ id, name: zod_1.z.string().min(1).max(1_000), isVerified: zod_1.z.boolean() }).strict().nullable(),
    }).strict(),
]);
