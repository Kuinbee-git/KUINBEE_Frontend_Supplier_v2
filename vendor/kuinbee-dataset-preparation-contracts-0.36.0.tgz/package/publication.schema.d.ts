import { z } from "zod";
export declare const DatasetContentAssessmentTargetSchema: z.ZodEnum<{
    REVIEWED: "REVIEWED";
    PUBLISHED: "PUBLISHED";
}>;
export declare const DatasetContentAssessmentQuerySchema: z.ZodObject<{
    target: z.ZodDefault<z.ZodEnum<{
        REVIEWED: "REVIEWED";
        PUBLISHED: "PUBLISHED";
    }>>;
}, z.core.$strict>;
export declare const DatasetContentAssessmentBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedWorkflowRevision: z.ZodNumber;
    expectedContentId: z.ZodString;
    target: z.ZodDefault<z.ZodEnum<{
        REVIEWED: "REVIEWED";
        PUBLISHED: "PUBLISHED";
    }>>;
    Q: z.ZodNumber;
    L: z.ZodNumber;
    P: z.ZodNumber;
    U: z.ZodNumber;
    F: z.ZodNumber;
    note: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetContentAssessmentSchema: z.ZodObject<{
    id: z.ZodString;
    datasetId: z.ZodString;
    contentId: z.ZodString;
    Q: z.ZodNumber;
    L: z.ZodNumber;
    P: z.ZodNumber;
    U: z.ZodNumber;
    F: z.ZodNumber;
    finalScore: z.ZodString;
    adminId: z.ZodString;
    createdAt: z.ZodString;
    note: z.ZodNullable<z.ZodString>;
    scope: z.ZodObject<{
        uploadedComponents: z.ZodArray<z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>>;
        representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetPublicationSchema: z.ZodObject<{
    id: z.ZodString;
    contentId: z.ZodString;
    publishedAt: z.ZodString;
    pricingReference: z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strict>;
    pricingAtPublication: z.ZodObject<{
        isPaid: z.ZodBoolean;
        price: z.ZodNullable<z.ZodString>;
        currency: z.ZodEnum<{
            INR: "INR";
            USD: "USD";
            EUR: "EUR";
            GBP: "GBP";
        }>;
    }, z.core.$strict>;
    assessmentAtPublicationId: z.ZodString;
    currentAssessmentId: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetContentAssessmentResponseSchema: z.ZodObject<{
    state: z.ZodObject<{
        datasetId: z.ZodString;
        preparationGeneration: z.ZodNumber;
        workflowRevision: z.ZodNumber;
        datasetUniqueId: z.ZodString;
        datasetStatus: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            REJECTED: "REJECTED";
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            DELISTED: "DELISTED";
            ARCHIVED: "ARCHIVED";
        }>;
        verificationStatus: z.ZodEnum<{
            REJECTED: "REJECTED";
            PENDING: "PENDING";
            SUBMITTED: "SUBMITTED";
            CHANGES_REQUESTED: "CHANGES_REQUESTED";
            RESUBMITTED: "RESUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
        }>;
        activeContentId: z.ZodNullable<z.ZodString>;
        reviewedContentId: z.ZodNullable<z.ZodString>;
        publishedContentId: z.ZodNullable<z.ZodString>;
        pricing: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            status: z.ZodEnum<{
                REJECTED: "REJECTED";
                DRAFT: "DRAFT";
                SUBMITTED: "SUBMITTED";
                CHANGES_REQUESTED: "CHANGES_REQUESTED";
                RESUBMITTED: "RESUBMITTED";
                UNDER_REVIEW: "UNDER_REVIEW";
                ACTIVE: "ACTIVE";
                INACTIVE: "INACTIVE";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    target: z.ZodEnum<{
        REVIEWED: "REVIEWED";
        PUBLISHED: "PUBLISHED";
    }>;
    assessment: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        datasetId: z.ZodString;
        contentId: z.ZodString;
        Q: z.ZodNumber;
        L: z.ZodNumber;
        P: z.ZodNumber;
        U: z.ZodNumber;
        F: z.ZodNumber;
        finalScore: z.ZodString;
        adminId: z.ZodString;
        createdAt: z.ZodString;
        note: z.ZodNullable<z.ZodString>;
        scope: z.ZodObject<{
            uploadedComponents: z.ZodArray<z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>>;
            representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
        }, z.core.$strict>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetPublicationResponseSchema: z.ZodObject<{
    requestId: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>;
    state: z.ZodObject<{
        datasetId: z.ZodString;
        preparationGeneration: z.ZodNumber;
        workflowRevision: z.ZodNumber;
        datasetUniqueId: z.ZodString;
        datasetStatus: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            REJECTED: "REJECTED";
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            DELISTED: "DELISTED";
            ARCHIVED: "ARCHIVED";
        }>;
        verificationStatus: z.ZodEnum<{
            REJECTED: "REJECTED";
            PENDING: "PENDING";
            SUBMITTED: "SUBMITTED";
            CHANGES_REQUESTED: "CHANGES_REQUESTED";
            RESUBMITTED: "RESUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
        }>;
        activeContentId: z.ZodNullable<z.ZodString>;
        reviewedContentId: z.ZodNullable<z.ZodString>;
        publishedContentId: z.ZodNullable<z.ZodString>;
        pricing: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            status: z.ZodEnum<{
                REJECTED: "REJECTED";
                DRAFT: "DRAFT";
                SUBMITTED: "SUBMITTED";
                CHANGES_REQUESTED: "CHANGES_REQUESTED";
                RESUBMITTED: "RESUBMITTED";
                UNDER_REVIEW: "UNDER_REVIEW";
                ACTIVE: "ACTIVE";
                INACTIVE: "INACTIVE";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    visibility: z.ZodEnum<{
        PUBLIC: "PUBLIC";
        PRIVATE: "PRIVATE";
        UNLISTED: "UNLISTED";
    }>;
    publication: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        contentId: z.ZodString;
        publishedAt: z.ZodString;
        pricingReference: z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
        }, z.core.$strict>;
        pricingAtPublication: z.ZodObject<{
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
        }, z.core.$strict>;
        assessmentAtPublicationId: z.ZodString;
        currentAssessmentId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    reviewedAssessment: z.ZodNullable<z.ZodObject<{
        datasetId: z.ZodString;
        contentId: z.ZodString;
        id: z.ZodString;
        createdAt: z.ZodString;
        scope: z.ZodObject<{
            uploadedComponents: z.ZodArray<z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>>;
            representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
        }, z.core.$strict>;
        adminId: z.ZodString;
        Q: z.ZodNumber;
        L: z.ZodNumber;
        P: z.ZodNumber;
        U: z.ZodNumber;
        F: z.ZodNumber;
        finalScore: z.ZodString;
    }, z.core.$strict>>;
    publishedAssessment: z.ZodNullable<z.ZodObject<{
        datasetId: z.ZodString;
        contentId: z.ZodString;
        id: z.ZodString;
        createdAt: z.ZodString;
        scope: z.ZodObject<{
            uploadedComponents: z.ZodArray<z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>>;
            representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
        }, z.core.$strict>;
        adminId: z.ZodString;
        Q: z.ZodNumber;
        L: z.ZodNumber;
        P: z.ZodNumber;
        U: z.ZodNumber;
        F: z.ZodNumber;
        finalScore: z.ZodString;
    }, z.core.$strict>>;
    assessmentChange: z.ZodOptional<z.ZodObject<{
        target: z.ZodEnum<{
            REVIEWED: "REVIEWED";
            PUBLISHED: "PUBLISHED";
        }>;
        assessment: z.ZodObject<{
            id: z.ZodString;
            datasetId: z.ZodString;
            contentId: z.ZodString;
            Q: z.ZodNumber;
            L: z.ZodNumber;
            P: z.ZodNumber;
            U: z.ZodNumber;
            F: z.ZodNumber;
            finalScore: z.ZodString;
            adminId: z.ZodString;
            createdAt: z.ZodString;
            note: z.ZodNullable<z.ZodString>;
            scope: z.ZodObject<{
                uploadedComponents: z.ZodArray<z.ZodEnum<{
                    FULL: "FULL";
                    SAMPLE: "SAMPLE";
                }>>;
                representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
            }, z.core.$strict>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetPublishedReviewResponseSchema: z.ZodObject<{
    state: z.ZodObject<{
        datasetId: z.ZodString;
        preparationGeneration: z.ZodNumber;
        workflowRevision: z.ZodNumber;
        datasetUniqueId: z.ZodString;
        datasetStatus: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            REJECTED: "REJECTED";
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            DELISTED: "DELISTED";
            ARCHIVED: "ARCHIVED";
        }>;
        verificationStatus: z.ZodEnum<{
            REJECTED: "REJECTED";
            PENDING: "PENDING";
            SUBMITTED: "SUBMITTED";
            CHANGES_REQUESTED: "CHANGES_REQUESTED";
            RESUBMITTED: "RESUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
        }>;
        activeContentId: z.ZodNullable<z.ZodString>;
        reviewedContentId: z.ZodNullable<z.ZodString>;
        publishedContentId: z.ZodNullable<z.ZodString>;
        pricing: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            status: z.ZodEnum<{
                REJECTED: "REJECTED";
                DRAFT: "DRAFT";
                SUBMITTED: "SUBMITTED";
                CHANGES_REQUESTED: "CHANGES_REQUESTED";
                RESUBMITTED: "RESUBMITTED";
                UNDER_REVIEW: "UNDER_REVIEW";
                ACTIVE: "ACTIVE";
                INACTIVE: "INACTIVE";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    visibility: z.ZodEnum<{
        PUBLIC: "PUBLIC";
        PRIVATE: "PRIVATE";
        UNLISTED: "UNLISTED";
    }>;
    publication: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        contentId: z.ZodString;
        publishedAt: z.ZodString;
        pricingReference: z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
        }, z.core.$strict>;
        pricingAtPublication: z.ZodObject<{
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
        }, z.core.$strict>;
        assessmentAtPublicationId: z.ZodString;
        currentAssessmentId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    publishedContent: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        generation: z.ZodNumber;
        uploadChoice: z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>;
        frozenAt: z.ZodString;
        common: z.ZodObject<{
            title: z.ZodString;
            overview: z.ZodString;
            description: z.ZodString;
            dataQuality: z.ZodString;
            license: z.ZodString;
            primaryCategoryId: z.ZodString;
            sourceId: z.ZodString;
            superType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                CROSS_SECTIONAL: "CROSS_SECTIONAL";
                TIME_SERIES: "TIME_SERIES";
                PANEL: "PANEL";
                POOLED_CROSS_SECTIONAL: "POOLED_CROSS_SECTIONAL";
                REPEATED_CROSS_SECTIONS: "REPEATED_CROSS_SECTIONS";
                SPATIAL: "SPATIAL";
                SPATIO_TEMPORAL: "SPATIO_TEMPORAL";
                EXPERIMENTAL: "EXPERIMENTAL";
                OBSERVATIONAL: "OBSERVATIONAL";
                BIG_DATA: "BIG_DATA";
                EVENT_HISTORY_SURVIVAL: "EVENT_HISTORY_SURVIVAL";
                HIERARCHICAL_MULTILEVEL: "HIERARCHICAL_MULTILEVEL";
            }>>>;
            useCases: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            limitations: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            methodology: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            secondaryCategoryIds: z.ZodArray<z.ZodString>;
            tags: z.ZodArray<z.ZodString>;
            categories: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>;
            source: z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
                description: z.ZodNullable<z.ZodString>;
                websiteUrl: z.ZodNullable<z.ZodString>;
                isVerifiedAtFreeze: z.ZodBoolean;
            }, z.core.$strict>;
        }, z.core.$strict>;
        metadata: z.ZodObject<{
            collectionBoundary: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            limitations: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            collectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            possibleUses: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            modalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                TABULAR: "TABULAR";
                AUDIO: "AUDIO";
                IMAGE: "IMAGE";
                VIDEO: "VIDEO";
                TEXT: "TEXT";
                SENSOR: "SENSOR";
            }>>>;
            contexts: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                HEALTHCARE: "HEALTHCARE";
                EGOCENTRIC: "EGOCENTRIC";
            }>>>;
            geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"KNOWN">;
                description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"NOT_APPLICABLE">;
            }, z.core.$strict>], "state">>>;
            collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"KNOWN">;
                start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    precision: z.ZodLiteral<"YEAR">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"MONTH">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"DAY">;
                    value: z.ZodISODate;
                }, z.core.$strict>], "precision">>>;
                end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    precision: z.ZodLiteral<"YEAR">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"MONTH">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"DAY">;
                    value: z.ZodISODate;
                }, z.core.$strict>], "precision">>>;
                notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"NOT_APPLICABLE">;
            }, z.core.$strict>], "state">>>;
            collectionMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>>;
            fullMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>>;
            sampleMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>>;
            sample: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    DESCRIBED: "DESCRIBED";
                    NONE_KNOWN: "NONE_KNOWN";
                }>>>;
                omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    DESCRIBED: "DESCRIBED";
                    NONE_DECLARED: "NONE_DECLARED";
                }>>>;
                transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            fullCompleteness: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            profiles: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                tabular: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                }, z.core.$strict>>>;
                audio: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        SPEECH: "SPEECH";
                        NON_SPEECH: "NON_SPEECH";
                        MIXED: "MIXED";
                    }>>>;
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        UNTIMED: "UNTIMED";
                        TIMED: "TIMED";
                    }>>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                images: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                video: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        WHOLE_ITEM: "WHOLE_ITEM";
                        TIME_OR_FRAME: "TIME_OR_FRAME";
                    }>>>;
                }, z.core.$strict>>>;
                text: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        MIXED: "MIXED";
                        HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                        NON_LANGUAGE: "NON_LANGUAGE";
                    }>>>;
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                sensors: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>>;
                    channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        NO_CLAIM: "NO_CLAIM";
                        DESCRIBED: "DESCRIBED";
                    }>>>;
                    synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                egocentric: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                healthcare: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        pricingReference: z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
        }, z.core.$strict>;
        pricingAtSubmission: z.ZodObject<{
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
        }, z.core.$strict>;
        dependencyFingerprint: z.ZodString;
        dependenciesChanged: z.ZodBoolean;
        selectedFiles: z.ZodNumber;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetPublicationReadinessResponseSchema: z.ZodObject<{
    requestId: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>;
    state: z.ZodObject<{
        datasetId: z.ZodString;
        preparationGeneration: z.ZodNumber;
        workflowRevision: z.ZodNumber;
        datasetUniqueId: z.ZodString;
        datasetStatus: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            REJECTED: "REJECTED";
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            DELISTED: "DELISTED";
            ARCHIVED: "ARCHIVED";
        }>;
        verificationStatus: z.ZodEnum<{
            REJECTED: "REJECTED";
            PENDING: "PENDING";
            SUBMITTED: "SUBMITTED";
            CHANGES_REQUESTED: "CHANGES_REQUESTED";
            RESUBMITTED: "RESUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
        }>;
        activeContentId: z.ZodNullable<z.ZodString>;
        reviewedContentId: z.ZodNullable<z.ZodString>;
        publishedContentId: z.ZodNullable<z.ZodString>;
        pricing: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            status: z.ZodEnum<{
                REJECTED: "REJECTED";
                DRAFT: "DRAFT";
                SUBMITTED: "SUBMITTED";
                CHANGES_REQUESTED: "CHANGES_REQUESTED";
                RESUBMITTED: "RESUBMITTED";
                UNDER_REVIEW: "UNDER_REVIEW";
                ACTIVE: "ACTIVE";
                INACTIVE: "INACTIVE";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    visibility: z.ZodEnum<{
        PUBLIC: "PUBLIC";
        PRIVATE: "PRIVATE";
        UNLISTED: "UNLISTED";
    }>;
    publication: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        contentId: z.ZodString;
        publishedAt: z.ZodString;
        pricingReference: z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
        }, z.core.$strict>;
        pricingAtPublication: z.ZodObject<{
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
        }, z.core.$strict>;
        assessmentAtPublicationId: z.ZodString;
        currentAssessmentId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    reviewedAssessment: z.ZodNullable<z.ZodObject<{
        datasetId: z.ZodString;
        contentId: z.ZodString;
        id: z.ZodString;
        createdAt: z.ZodString;
        scope: z.ZodObject<{
            uploadedComponents: z.ZodArray<z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>>;
            representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
        }, z.core.$strict>;
        adminId: z.ZodString;
        Q: z.ZodNumber;
        L: z.ZodNumber;
        P: z.ZodNumber;
        U: z.ZodNumber;
        F: z.ZodNumber;
        finalScore: z.ZodString;
    }, z.core.$strict>>;
    publishedAssessment: z.ZodNullable<z.ZodObject<{
        datasetId: z.ZodString;
        contentId: z.ZodString;
        id: z.ZodString;
        createdAt: z.ZodString;
        scope: z.ZodObject<{
            uploadedComponents: z.ZodArray<z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>>;
            representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
        }, z.core.$strict>;
        adminId: z.ZodString;
        Q: z.ZodNumber;
        L: z.ZodNumber;
        P: z.ZodNumber;
        U: z.ZodNumber;
        F: z.ZodNumber;
        finalScore: z.ZodString;
    }, z.core.$strict>>;
    assessmentChange: z.ZodOptional<z.ZodObject<{
        target: z.ZodEnum<{
            REVIEWED: "REVIEWED";
            PUBLISHED: "PUBLISHED";
        }>;
        assessment: z.ZodObject<{
            id: z.ZodString;
            datasetId: z.ZodString;
            contentId: z.ZodString;
            Q: z.ZodNumber;
            L: z.ZodNumber;
            P: z.ZodNumber;
            U: z.ZodNumber;
            F: z.ZodNumber;
            finalScore: z.ZodString;
            adminId: z.ZodString;
            createdAt: z.ZodString;
            note: z.ZodNullable<z.ZodString>;
            scope: z.ZodObject<{
                uploadedComponents: z.ZodArray<z.ZodEnum<{
                    FULL: "FULL";
                    SAMPLE: "SAMPLE";
                }>>;
                representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
            }, z.core.$strict>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    contentId: z.ZodNullable<z.ZodString>;
    contentGeneration: z.ZodNullable<z.ZodNumber>;
    dependencyFingerprint: z.ZodNullable<z.ZodString>;
    canPublish: z.ZodBoolean;
    issues: z.ZodArray<z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetContentPublishBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedWorkflowRevision: z.ZodNumber;
    expectedContentId: z.ZodString;
    expectedContentGeneration: z.ZodNumber;
    expectedPricingReference: z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strict>;
    expectedAssessmentId: z.ZodString;
    expectedDependencyFingerprint: z.ZodString;
}, z.core.$strict>;
export declare const DatasetContentLifecycleBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedWorkflowRevision: z.ZodNumber;
    expectedPublishedContentId: z.ZodNullable<z.ZodString>;
    expectedPublicationId: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetContentVisibilityBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedWorkflowRevision: z.ZodNumber;
    expectedPublishedContentId: z.ZodNullable<z.ZodString>;
    expectedPublicationId: z.ZodNullable<z.ZodString>;
    visibility: z.ZodEnum<{
        PUBLIC: "PUBLIC";
        PRIVATE: "PRIVATE";
        UNLISTED: "UNLISTED";
    }>;
}, z.core.$strict>;
export type DatasetContentAssessmentBody = z.infer<typeof DatasetContentAssessmentBodySchema>;
export type DatasetContentAssessmentResponse = z.infer<typeof DatasetContentAssessmentResponseSchema>;
export type DatasetContentPublishBody = z.infer<typeof DatasetContentPublishBodySchema>;
export type DatasetContentLifecycleBody = z.infer<typeof DatasetContentLifecycleBodySchema>;
export type DatasetContentVisibilityBody = z.infer<typeof DatasetContentVisibilityBodySchema>;
//# sourceMappingURL=publication.schema.d.ts.map