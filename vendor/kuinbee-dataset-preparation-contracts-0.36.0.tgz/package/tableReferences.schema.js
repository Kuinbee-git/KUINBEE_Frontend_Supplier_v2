"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetPublicTableReferenceViewsResponseSchema = exports.DatasetPublicTableReferenceViewsQuerySchema = exports.DatasetPrivateTableReferenceViewsResponseSchema = exports.DatasetPrivateTableReferenceViewsQuerySchema = exports.DatasetTableReferenceViewsPageSchema = exports.DatasetTableReferenceViewsCursorSchema = exports.DatasetTableReferenceViewSchema = exports.DatasetTableReferenceTargetsResponseSchema = exports.DatasetTableReferenceTargetSchema = exports.DatasetTableReferenceTargetsQuerySchema = exports.DatasetTableReferencesMutationResponseSchema = exports.DatasetTableReferencesPageResponseSchema = exports.DatasetTableReferenceItemSchema = exports.DatasetTableReferencesPageQuerySchema = exports.DatasetTableReferencesMutationBodySchema = exports.DatasetTableReferenceOperationSchema = exports.DatasetTableReferenceDefinitionSchema = exports.DatasetReferenceColumnPreviewSchema = void 0;
const zod_1 = require("zod");
const edit_schema_1 = require("./edit.schema");
const content_schema_1 = require("./content.schema");
const access_schema_1 = require("./access.schema");
const id = zod_1.z.string().cuid();
const generation = zod_1.z.number().int().min(0).max(2_147_483_647);
const queryGeneration = zod_1.z.union([generation, zod_1.z.string().regex(/^(0|[1-9][0-9]{0,9})$/).transform(Number).pipe(generation)]);
const unique = (values) => new Set(values).size === values.length;
const label = zod_1.z.string().trim().max(200).nullable();
const notes = zod_1.z.string().trim().max(2_000).nullable();
const subject = { memberId: id, tableId: id };
exports.DatasetReferenceColumnPreviewSchema = zod_1.z.object({ id, position: zod_1.z.number().int().min(1).max(1_024),
    namePreview: zod_1.z.string().max(192).nullable(), nameTruncated: zod_1.z.boolean(),
}).strict().refine(value => value.namePreview === null ? !value.nameTruncated : Array.from(value.namePreview).length <= 96, "Column labels are bounded previews; exact identity and position remain available");
// These are bounded supplier declarations about exact inspected identifiers.
// Empty tuples/targets may be saved progressively, never frozen as a promise.
exports.DatasetTableReferenceDefinitionSchema = zod_1.z.discriminatedUnion("kind", [
    zod_1.z.object({ kind: zod_1.z.literal("KEY"), keyKind: zod_1.z.enum(["PRIMARY", "UNIQUE"]).nullable(),
        columnIds: zod_1.z.array(id).max(16).refine(unique, "Select each key column once"), label, notes }).strict(),
    zod_1.z.object({ kind: zod_1.z.literal("JOIN"), target: zod_1.z.object(subject).strict().nullable(),
        pairs: zod_1.z.array(zod_1.z.object({ sourceColumnId: id, targetColumnId: id }).strict()).max(16)
            .refine(pairs => unique(pairs.map(pair => pair.sourceColumnId)) && unique(pairs.map(pair => pair.targetColumnId)), "Each composite pair preserves one distinct source and target column"),
        cardinality: zod_1.z.enum(["ONE_TO_ONE", "ONE_TO_MANY", "MANY_TO_ONE", "MANY_TO_MANY", "UNKNOWN"]).nullable(), label, notes,
    }).strict().refine(value => value.target !== null || value.pairs.length === 0, "Choose the target table before its columns"),
    zod_1.z.object({ kind: zod_1.z.literal("DICTIONARY"), state: zod_1.z.enum(["INCLUDED", "NOT_INCLUDED"]).nullable(),
        target: zod_1.z.object({ memberId: id, logicalEntryId: id.nullable() }).strict().nullable(), notes,
    }).strict().refine(value => value.target === null || value.state === "INCLUDED", "An exact companion is an explicit inclusion declaration"),
]);
exports.DatasetTableReferenceOperationSchema = zod_1.z.discriminatedUnion("operation", [
    zod_1.z.object({ operation: zod_1.z.literal("PUT_REFERENCE"), referenceId: id.optional(), ...subject,
        definition: exports.DatasetTableReferenceDefinitionSchema }).strict(),
    zod_1.z.object({ operation: zod_1.z.literal("REMOVE_REFERENCE"), referenceId: id }).strict(),
]);
exports.DatasetTableReferencesMutationBodySchema = zod_1.z.object({ requestId: zod_1.z.string().uuid().transform(value => value.toLowerCase()),
    expectedContentId: id, expectedGeneration: generation, expectedPreparationGeneration: generation,
    editContext: edit_schema_1.DatasetCorrectionPreconditionSchema.optional(),
    operations: zod_1.z.array(exports.DatasetTableReferenceOperationSchema).min(1).max(50),
}).strict();
exports.DatasetTableReferencesPageQuerySchema = zod_1.z.object({ contentId: id, contentGeneration: queryGeneration,
    expectedPreparationGeneration: queryGeneration, component: content_schema_1.DatasetMaterialComponentSchema.optional(),
    memberId: id.optional(), tableId: id.optional(), kind: zod_1.z.enum(["KEY", "JOIN", "DICTIONARY"]).optional(),
    afterId: id.optional(), limit: zod_1.z.coerce.number().int().min(1).max(50).default(20),
}).strict().refine(value => !value.tableId || Boolean(value.memberId), "A table filter retains its exact selected membership");
exports.DatasetTableReferenceItemSchema = zod_1.z.object({ id, ...subject, component: content_schema_1.DatasetMaterialComponentSchema,
    definition: exports.DatasetTableReferenceDefinitionSchema, origin: zod_1.z.literal("SUPPLIER_DECLARED"),
    columns: zod_1.z.array(exports.DatasetReferenceColumnPreviewSchema).max(32), targetLabel: zod_1.z.string().max(1_024).nullable(),
}).strict().refine(value => {
    const selected = new Set(value.definition.kind === "KEY" ? value.definition.columnIds : value.definition.kind === "JOIN" ?
        value.definition.pairs.flatMap(pair => [pair.sourceColumnId, pair.targetColumnId]) : []);
    return unique(value.columns.map(column => column.id)) && value.columns.length === selected.size && value.columns.every(column => selected.has(column.id));
}, "Keep labels for every exact selected column, including selections on unseen picker pages");
exports.DatasetTableReferencesPageResponseSchema = zod_1.z.object({ contentId: id, contentGeneration: generation,
    preparationGeneration: generation, frozen: zod_1.z.boolean(),
    items: zod_1.z.array(exports.DatasetTableReferenceItemSchema).max(50), nextCursor: exports.DatasetTableReferencesPageQuerySchema.nullable(),
}).strict().refine(value => {
    if (!unique(value.items.map(item => item.id)))
        return false;
    const cursor = value.nextCursor;
    return !cursor || cursor.contentId === value.contentId && cursor.contentGeneration === value.contentGeneration &&
        cursor.expectedPreparationGeneration === value.preparationGeneration && cursor.afterId === value.items.at(-1)?.id &&
        value.items.length <= cursor.limit && value.items.every(item => (!cursor.component || item.component === cursor.component) &&
        (!cursor.memberId || item.memberId === cursor.memberId) && (!cursor.tableId || item.tableId === cursor.tableId) &&
        (!cursor.kind || item.definition.kind === cursor.kind));
}, "Keep exact generations, filters and the final row in every continuation");
exports.DatasetTableReferencesMutationResponseSchema = zod_1.z.object({ requestId: zod_1.z.string().uuid(), contentId: id,
    generation, preparationGeneration: generation,
    results: zod_1.z.array(zod_1.z.object({ index: zod_1.z.number().int().min(0).max(49), operation: zod_1.z.enum(["PUT_REFERENCE", "REMOVE_REFERENCE"]),
        referenceId: id, memberId: id, tableId: id, targetMemberId: id.nullable(),
    }).strict()).min(1).max(50),
}).strict().refine(value => value.results.every((item, index) => item.index === index), "Acknowledge every exact row in order");
// A candidate is inspected structure with declared purpose, not security
// acceptance, a checked semantic dictionary, uniqueness or a new entitlement.
exports.DatasetTableReferenceTargetsQuerySchema = zod_1.z.object({ contentId: id, contentGeneration: queryGeneration,
    expectedPreparationGeneration: queryGeneration, ...subject, targetMemberId: id, kind: zod_1.z.enum(["JOIN", "DICTIONARY"]),
    afterId: id.optional(), limit: zod_1.z.coerce.number().int().min(1).max(50).default(20),
}).strict();
exports.DatasetTableReferenceTargetSchema = zod_1.z.discriminatedUnion("kind", [
    zod_1.z.object({ kind: zod_1.z.literal("TABLE"), id, logicalEntryId: id.nullable(), locator: content_schema_1.DatasetLogicalLocatorSchema.nullable(),
        displayName: label, columnCount: zod_1.z.number().int().min(1).max(1_024) }).strict(),
    zod_1.z.object({ kind: zod_1.z.literal("DICTIONARY_FILE"), id, logicalEntryId: id.nullable(), locator: content_schema_1.DatasetLogicalLocatorSchema.nullable() }).strict(),
]);
exports.DatasetTableReferenceTargetsResponseSchema = zod_1.z.object({ contentId: id, contentGeneration: generation,
    preparationGeneration: generation, frozen: zod_1.z.boolean(), ...subject, component: content_schema_1.DatasetMaterialComponentSchema,
    targetMemberId: id, kind: zod_1.z.enum(["JOIN", "DICTIONARY"]), items: zod_1.z.array(exports.DatasetTableReferenceTargetSchema).max(50),
    nextCursor: exports.DatasetTableReferenceTargetsQuerySchema.nullable(),
}).strict().refine(value => unique(value.items.map(item => item.id)) && value.items.every(item => value.kind === "JOIN" ? item.kind === "TABLE" : item.kind === "DICTIONARY_FILE" &&
    item.id === (item.logicalEntryId ?? value.targetMemberId)) && (!value.nextCursor ||
    value.nextCursor.contentId === value.contentId && value.nextCursor.contentGeneration === value.contentGeneration &&
        value.nextCursor.expectedPreparationGeneration === value.preparationGeneration && value.nextCursor.memberId === value.memberId &&
        value.nextCursor.tableId === value.tableId && value.nextCursor.targetMemberId === value.targetMemberId &&
        value.nextCursor.kind === value.kind && value.nextCursor.afterId === value.items.at(-1)?.id && value.items.length <= value.nextCursor.limit), "Candidate pages retain the exact source, target, purpose and acknowledged generations");
const viewedColumn = exports.DatasetReferenceColumnPreviewSchema;
const viewedTable = zod_1.z.object({ describedTableId: id.nullable(), displayName: label }).strict();
const viewedDefinition = zod_1.z.discriminatedUnion("kind", [
    zod_1.z.object({ kind: zod_1.z.literal("KEY"), keyKind: zod_1.z.enum(["PRIMARY", "UNIQUE"]).nullable(), columns: zod_1.z.array(viewedColumn).max(16), label, notes }).strict(),
    zod_1.z.object({ kind: zod_1.z.literal("JOIN"), targetTable: viewedTable.nullable(),
        pairs: zod_1.z.array(zod_1.z.object({ source: viewedColumn, target: viewedColumn }).strict()).max(16),
        cardinality: zod_1.z.enum(["ONE_TO_ONE", "ONE_TO_MANY", "MANY_TO_ONE", "MANY_TO_MANY", "UNKNOWN"]).nullable(), label, notes }).strict(),
    zod_1.z.object({ kind: zod_1.z.literal("DICTIONARY"), state: zod_1.z.enum(["INCLUDED", "NOT_INCLUDED"]).nullable(), notes }).strict(),
]);
exports.DatasetTableReferenceViewSchema = zod_1.z.object({ id, component: content_schema_1.DatasetMaterialComponentSchema,
    sourceTable: viewedTable, origin: zod_1.z.literal("SUPPLIER_DECLARED"), definition: viewedDefinition }).strict();
exports.DatasetTableReferenceViewsCursorSchema = zod_1.z.object({ contentId: id, contentGeneration: queryGeneration,
    component: content_schema_1.DatasetMaterialComponentSchema.optional(), tableId: id.optional(), afterId: id.optional(),
    limit: zod_1.z.coerce.number().int().min(1).max(20).default(5) }).strict();
exports.DatasetTableReferenceViewsPageSchema = zod_1.z.object({ contentId: id, contentGeneration: generation,
    frozen: zod_1.z.boolean(), frozenAt: zod_1.z.string().datetime().nullable(), component: content_schema_1.DatasetMaterialComponentSchema.nullable(),
    tableId: id.nullable(), items: zod_1.z.array(exports.DatasetTableReferenceViewSchema).max(20),
    nextCursor: exports.DatasetTableReferenceViewsCursorSchema.nullable(),
}).strict().refine(value => value.frozen === (value.frozenAt !== null) && unique(value.items.map(item => item.id)) &&
    value.items.every(item => (!value.component || item.component === value.component) &&
        (!value.tableId || item.sourceTable.describedTableId === value.tableId)) && (!value.nextCursor ||
    value.nextCursor.contentId === value.contentId && value.nextCursor.contentGeneration === value.contentGeneration &&
        (value.nextCursor.component ?? null) === value.component && (value.nextCursor.tableId ?? null) === value.tableId &&
        value.nextCursor.afterId === value.items.at(-1)?.id && value.items.length <= value.nextCursor.limit), "Reference views preserve the exact content, component, table and bounded cursor");
exports.DatasetPrivateTableReferenceViewsQuerySchema = access_schema_1.DatasetFileAccessPageQuerySchema.extend({ memberId: id.optional(), tableId: id.optional(),
    limit: zod_1.z.coerce.number().int().min(1).max(20).default(5) });
exports.DatasetPrivateTableReferenceViewsResponseSchema = zod_1.z.object({ context: access_schema_1.DatasetFileAccessContextSchema,
    memberId: id.nullable(), page: exports.DatasetTableReferenceViewsPageSchema, targets: zod_1.z.array(zod_1.z.object({ id,
        sourceMemberId: id, sourceTableId: id, sourceLocator: content_schema_1.DatasetLogicalLocatorSchema.nullable(),
        sourceFileName: zod_1.z.string().max(1_024).nullable(), targetFileName: zod_1.z.string().max(1_024).nullable(),
        targetMemberId: id.nullable(), targetLogicalEntryId: id.nullable(), targetLocator: content_schema_1.DatasetLogicalLocatorSchema.nullable(),
    }).strict()).max(20) }).strict().refine(value => value.context.contentId === value.page.contentId &&
    value.context.contentGeneration === value.page.contentGeneration && value.context.component === value.page.component &&
    value.context.frozen === value.page.frozen && value.targets.length === value.page.items.length &&
    unique(value.targets.map(target => target.id)) && value.targets.every(target => value.page.items.some(item => item.id === target.id) && (!value.memberId || value.memberId === target.sourceMemberId)), "Private reference targets belong only to the authorized exact page");
exports.DatasetPublicTableReferenceViewsQuerySchema = zod_1.z.object({ publicationId: id, contentId: id,
    contentGeneration: queryGeneration.optional(), component: content_schema_1.DatasetMaterialComponentSchema.optional(), tableId: id.optional(), afterId: id.optional(),
    limit: zod_1.z.coerce.number().int().min(1).max(20).default(5) }).strict();
exports.DatasetPublicTableReferenceViewsResponseSchema = zod_1.z.object({ datasetId: id, publicationId: id,
    page: exports.DatasetTableReferenceViewsPageSchema }).strict().refine(value => value.page.frozen && value.page.items.every(row => row.definition.kind !== "DICTIONARY"), "Public keys and relationships come from the exact frozen publication; dictionary declarations stay in private review");
