"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetCategoryResolveResponseSchema = exports.DatasetCategoryResolveParamsSchema = exports.DatasetCategoryDirectoryResponseSchema = exports.DatasetCategoryDirectoryQuerySchema = exports.DatasetPublicCategorySchema = exports.datasetCategoryRouteKey = exports.datasetCategoryLegacySlug = void 0;
const zod_1 = require("zod");
const id = zod_1.z.string().cuid();
const revision = zod_1.z.string().regex(/^[1-9][0-9]{0,18}$/).refine(value => BigInt(value) <= 9223372036854775807n);
const slug = zod_1.z.string().min(1).max(1_000).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/);
// Retain the existing name-only URL convention for compatibility. New links
// carry immutable identity as well as the current human-readable name.
const datasetCategoryLegacySlug = (name) => name.toLowerCase().replace(/&/g, " ").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
exports.datasetCategoryLegacySlug = datasetCategoryLegacySlug;
const datasetCategoryRouteKey = (categoryId, name) => id.parse(categoryId) + "--" + slug.parse((0, exports.datasetCategoryLegacySlug)(name) || "category");
exports.datasetCategoryRouteKey = datasetCategoryRouteKey;
exports.DatasetPublicCategorySchema = zod_1.z.object({ id, name: zod_1.z.string().min(1).max(1_000),
    routeKey: zod_1.z.string().min(1).max(1_066), datasetCount: zod_1.z.number().int().min(0).max(Number.MAX_SAFE_INTEGER),
}).strict().refine(value => value.routeKey === (0, exports.datasetCategoryRouteKey)(value.id, value.name), "Category links retain exact identity and the current name");
exports.DatasetCategoryDirectoryQuerySchema = zod_1.z.object({ q: zod_1.z.string().trim().min(1).max(200).optional(),
    expectedRevision: revision.optional(), afterId: id.optional(), limit: zod_1.z.coerce.number().int().min(1).max(100).default(50),
}).strict().refine(value => !value.afterId || Boolean(value.expectedRevision), "Continue only the exact category snapshot");
exports.DatasetCategoryDirectoryResponseSchema = zod_1.z.object({ revision, total: zod_1.z.number().int().min(0).max(Number.MAX_SAFE_INTEGER),
    items: zod_1.z.array(exports.DatasetPublicCategorySchema).max(100), nextCursor: exports.DatasetCategoryDirectoryQuerySchema.nullable(),
}).strict().refine(value => new Set(value.items.map(item => item.id)).size === value.items.length && value.total >= value.items.length &&
    (!value.nextCursor || value.items.length > 0 && value.nextCursor.expectedRevision === value.revision &&
        value.nextCursor.afterId === value.items.at(-1)?.id && value.items.length <= value.nextCursor.limit), "Keep one category snapshot across every bounded page");
exports.DatasetCategoryResolveParamsSchema = zod_1.z.object({ key: zod_1.z.string().min(1).max(1_066).refine(value => {
        const separator = value.indexOf("--");
        return separator < 0 ? slug.safeParse(value).success : id.safeParse(value.slice(0, separator)).success && slug.safeParse(value.slice(separator + 2)).success;
    }, "Choose a category identity or an exact legacy category slug") }).strict();
exports.DatasetCategoryResolveResponseSchema = zod_1.z.object({ revision, requestedKey: exports.DatasetCategoryResolveParamsSchema.shape.key,
    category: exports.DatasetPublicCategorySchema, redirect: zod_1.z.boolean(),
}).strict().refine(value => value.category.datasetCount > 0 && value.redirect === (value.requestedKey !== value.category.routeKey), "Resolve the current public category without retargeting an ambiguous legacy URL");
