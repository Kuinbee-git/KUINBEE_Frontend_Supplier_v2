import { z } from "zod";
export declare const DatasetPublicProfilesSchema: z.ZodObject<{
    tabular: z.ZodOptional<z.ZodObject<{
        recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
        }>>>;
    }, z.core.$strict>>;
    audio: z.ZodOptional<z.ZodObject<{
        languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
        recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
        }>>>;
        transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
        }>>>;
        annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            SPEECH: "SPEECH";
            NON_SPEECH: "NON_SPEECH";
            MIXED: "MIXED";
        }>>>;
        transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            UNTIMED: "UNTIMED";
            TIMED: "TIMED";
        }>>>;
    }, z.core.$strict>>;
    images: z.ZodOptional<z.ZodObject<{
        coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
        }>>>;
        annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>;
    video: z.ZodOptional<z.ZodObject<{
        annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
        }>>>;
        annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            WHOLE_ITEM: "WHOLE_ITEM";
            TIME_OR_FRAME: "TIME_OR_FRAME";
        }>>>;
    }, z.core.$strict>>;
    text: z.ZodOptional<z.ZodObject<{
        recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
        annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
        }>>>;
        annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            MIXED: "MIXED";
            HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
            NON_LANGUAGE: "NON_LANGUAGE";
        }>>>;
    }, z.core.$strict>>;
    sensors: z.ZodOptional<z.ZodObject<{
        channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
        }>>>;
        calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            DESCRIBED: "DESCRIBED";
            NO_CLAIM: "NO_CLAIM";
        }>>>;
    }, z.core.$strict>>;
    egocentric: z.ZodOptional<z.ZodObject<{
        mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>;
    healthcare: z.ZodOptional<z.ZodObject<{
        recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetPublicDescriptionSchema: z.ZodObject<{
    title: z.ZodString;
    license: z.ZodString;
    overview: z.ZodString;
    description: z.ZodString;
    dataQuality: z.ZodString;
    collectionBoundary: z.ZodString;
    geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"KNOWN">;
        description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"NOT_APPLICABLE">;
    }, z.core.$strict>], "state">>>;
    collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"KNOWN">;
        start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            precision: z.ZodLiteral<"YEAR">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"MONTH">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"DAY">;
            value: z.ZodISODate;
        }, z.core.$strict>], "precision">>>;
        end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            precision: z.ZodLiteral<"YEAR">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"MONTH">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"DAY">;
            value: z.ZodISODate;
        }, z.core.$strict>], "precision">>>;
        notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"NOT_APPLICABLE">;
    }, z.core.$strict>], "state">>>;
    limitations: z.ZodNullable<z.ZodString>;
    methodology: z.ZodNullable<z.ZodString>;
    useCases: z.ZodNullable<z.ZodString>;
    uploadChoice: z.ZodEnum<{
        SAMPLE_ONLY: "SAMPLE_ONLY";
        FULL_ONLY: "FULL_ONLY";
        FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
    }>;
    modalities: z.ZodArray<z.ZodEnum<{
        SENSOR: "SENSOR";
        TABULAR: "TABULAR";
        AUDIO: "AUDIO";
        IMAGE: "IMAGE";
        VIDEO: "VIDEO";
        TEXT: "TEXT";
    }>>;
    contexts: z.ZodArray<z.ZodEnum<{
        HEALTHCARE: "HEALTHCARE";
        EGOCENTRIC: "EGOCENTRIC";
    }>>;
    studyStructure: z.ZodNullable<z.ZodString>;
    tags: z.ZodArray<z.ZodString>;
    categoriesAtFreeze: z.ZodObject<{
        primary: z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>;
        additional: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    sourceAtFreeze: z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        description: z.ZodNullable<z.ZodString>;
        websiteUrl: z.ZodNullable<z.ZodString>;
        isVerifiedAtFreeze: z.ZodBoolean;
    }, z.core.$strict>;
    measurements: z.ZodArray<z.ZodObject<{
        scope: z.ZodEnum<{
            REPRESENTED_COLLECTION: "REPRESENTED_COLLECTION";
            FULL_MATERIAL: "FULL_MATERIAL";
            SAMPLE_MATERIAL: "SAMPLE_MATERIAL";
        }>;
        origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
        values: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodEnum<{
                KNOWN: "KNOWN";
                ESTIMATED: "ESTIMATED";
            }>;
            value: z.ZodString;
            metric: z.ZodEnum<{
                RECORD_COUNT: "RECORD_COUNT";
                ROW_COUNT: "ROW_COUNT";
                COLUMN_COUNT: "COLUMN_COUNT";
                AUDIO_DURATION: "AUDIO_DURATION";
                IMAGE_COUNT: "IMAGE_COUNT";
                VIDEO_DURATION: "VIDEO_DURATION";
                DOCUMENT_COUNT: "DOCUMENT_COUNT";
                SESSION_COUNT: "SESSION_COUNT";
                PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                STREAM_COUNT: "STREAM_COUNT";
                BYTE_SIZE: "BYTE_SIZE";
            }>;
            unit: z.ZodEnum<{
                COUNT: "COUNT";
                SECOND: "SECOND";
                MINUTE: "MINUTE";
                HOUR: "HOUR";
                BYTE: "BYTE";
            }>;
        }, z.core.$strict>], "state">>;
    }, z.core.$strict>>;
    sample: z.ZodNullable<z.ZodObject<{
        selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            DESCRIBED: "DESCRIBED";
            NONE_KNOWN: "NONE_KNOWN";
        }>>>;
        omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            DESCRIBED: "DESCRIBED";
            NONE_DECLARED: "NONE_DECLARED";
        }>>>;
        transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>;
    fullCompleteness: z.ZodNullable<z.ZodBoolean>;
    profiles: z.ZodObject<{
        tabular: z.ZodOptional<z.ZodObject<{
            recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
        }, z.core.$strict>>;
        audio: z.ZodOptional<z.ZodObject<{
            languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
            recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                SPEECH: "SPEECH";
                NON_SPEECH: "NON_SPEECH";
                MIXED: "MIXED";
            }>>>;
            transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                UNTIMED: "UNTIMED";
                TIMED: "TIMED";
            }>>>;
        }, z.core.$strict>>;
        images: z.ZodOptional<z.ZodObject<{
            coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>;
        video: z.ZodOptional<z.ZodObject<{
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                WHOLE_ITEM: "WHOLE_ITEM";
                TIME_OR_FRAME: "TIME_OR_FRAME";
            }>>>;
        }, z.core.$strict>>;
        text: z.ZodOptional<z.ZodObject<{
            recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                MIXED: "MIXED";
                HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                NON_LANGUAGE: "NON_LANGUAGE";
            }>>>;
        }, z.core.$strict>>;
        sensors: z.ZodOptional<z.ZodObject<{
            channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>>>;
            calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                DESCRIBED: "DESCRIBED";
                NO_CLAIM: "NO_CLAIM";
            }>>>;
        }, z.core.$strict>>;
        egocentric: z.ZodOptional<z.ZodObject<{
            mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>;
        healthcare: z.ZodOptional<z.ZodObject<{
            recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type DatasetPublicDescription = z.infer<typeof DatasetPublicDescriptionSchema>;
export declare const DatasetLibraryListQuerySchema: z.ZodObject<{
    page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    pageSize: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    q: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetReaderIdParamsSchema: z.ZodObject<{
    datasetId: z.ZodString;
}, z.core.$strict>;
export declare const DatasetLibraryItemSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    representation: z.ZodLiteral<"CONTENT">;
    title: z.ZodNullable<z.ZodString>;
    metadataProvenance: z.ZodEnum<{
        UNRESOLVED: "UNRESOLVED";
        FROZEN_GRANT_CONTENT: "FROZEN_GRANT_CONTENT";
    }>;
    description: z.ZodNullable<z.ZodObject<{
        title: z.ZodString;
        license: z.ZodString;
        overview: z.ZodString;
        description: z.ZodString;
        dataQuality: z.ZodString;
        collectionBoundary: z.ZodString;
        geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"KNOWN">;
            description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"NOT_APPLICABLE">;
        }, z.core.$strict>], "state">>>;
        collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"KNOWN">;
            start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                precision: z.ZodLiteral<"YEAR">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"MONTH">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"DAY">;
                value: z.ZodISODate;
            }, z.core.$strict>], "precision">>>;
            end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                precision: z.ZodLiteral<"YEAR">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"MONTH">;
                value: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                precision: z.ZodLiteral<"DAY">;
                value: z.ZodISODate;
            }, z.core.$strict>], "precision">>>;
            notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"UNKNOWN">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"NOT_APPLICABLE">;
        }, z.core.$strict>], "state">>>;
        limitations: z.ZodNullable<z.ZodString>;
        methodology: z.ZodNullable<z.ZodString>;
        useCases: z.ZodNullable<z.ZodString>;
        uploadChoice: z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>;
        modalities: z.ZodArray<z.ZodEnum<{
            SENSOR: "SENSOR";
            TABULAR: "TABULAR";
            AUDIO: "AUDIO";
            IMAGE: "IMAGE";
            VIDEO: "VIDEO";
            TEXT: "TEXT";
        }>>;
        contexts: z.ZodArray<z.ZodEnum<{
            HEALTHCARE: "HEALTHCARE";
            EGOCENTRIC: "EGOCENTRIC";
        }>>;
        studyStructure: z.ZodNullable<z.ZodString>;
        tags: z.ZodArray<z.ZodString>;
        categoriesAtFreeze: z.ZodObject<{
            primary: z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>;
            additional: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        sourceAtFreeze: z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
            description: z.ZodNullable<z.ZodString>;
            websiteUrl: z.ZodNullable<z.ZodString>;
            isVerifiedAtFreeze: z.ZodBoolean;
        }, z.core.$strict>;
        measurements: z.ZodArray<z.ZodObject<{
            scope: z.ZodEnum<{
                REPRESENTED_COLLECTION: "REPRESENTED_COLLECTION";
                FULL_MATERIAL: "FULL_MATERIAL";
                SAMPLE_MATERIAL: "SAMPLE_MATERIAL";
            }>;
            origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
            values: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>;
        }, z.core.$strict>>;
        sample: z.ZodNullable<z.ZodObject<{
            selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                DESCRIBED: "DESCRIBED";
                NONE_KNOWN: "NONE_KNOWN";
            }>>>;
            omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                DESCRIBED: "DESCRIBED";
                NONE_DECLARED: "NONE_DECLARED";
            }>>>;
            transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>;
        fullCompleteness: z.ZodNullable<z.ZodBoolean>;
        profiles: z.ZodObject<{
            tabular: z.ZodOptional<z.ZodObject<{
                recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
            }, z.core.$strict>>;
            audio: z.ZodOptional<z.ZodObject<{
                languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    SPEECH: "SPEECH";
                    NON_SPEECH: "NON_SPEECH";
                    MIXED: "MIXED";
                }>>>;
                transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    UNTIMED: "UNTIMED";
                    TIMED: "TIMED";
                }>>>;
            }, z.core.$strict>>;
            images: z.ZodOptional<z.ZodObject<{
                coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>;
            video: z.ZodOptional<z.ZodObject<{
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    WHOLE_ITEM: "WHOLE_ITEM";
                    TIME_OR_FRAME: "TIME_OR_FRAME";
                }>>>;
            }, z.core.$strict>>;
            text: z.ZodOptional<z.ZodObject<{
                recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    MIXED: "MIXED";
                    HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                    NON_LANGUAGE: "NON_LANGUAGE";
                }>>>;
            }, z.core.$strict>>;
            sensors: z.ZodOptional<z.ZodObject<{
                channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>>>;
                calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    DESCRIBED: "DESCRIBED";
                    NO_CLAIM: "NO_CLAIM";
                }>>>;
            }, z.core.$strict>>;
            egocentric: z.ZodOptional<z.ZodObject<{
                mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>;
            healthcare: z.ZodOptional<z.ZodObject<{
                recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    grantId: z.ZodNullable<z.ZodString>;
    material: z.ZodNullable<z.ZodObject<{
        datasetId: z.ZodString;
        contentId: z.ZodString;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
    }, z.core.$strict>>;
    datasetId: z.ZodString;
    datasetUniqueId: z.ZodString;
    accessType: z.ZodEnum<{
        PURCHASE: "PURCHASE";
        FREE_CLAIM: "FREE_CLAIM";
    }>;
    grantedAt: z.ZodString;
    expiresAt: z.ZodNullable<z.ZodString>;
    recordedAccess: z.ZodEnum<{
        REVOKED: "REVOKED";
        RECORDED: "RECORDED";
        EXPIRED: "EXPIRED";
        UNRESOLVED: "UNRESOLVED";
    }>;
}, z.core.$strict>, z.ZodObject<{
    representation: z.ZodLiteral<"LEGACY">;
    title: z.ZodString;
    metadataProvenance: z.ZodLiteral<"CURRENT_LEGACY_RECORD">;
    historicalMetadata: z.ZodNull;
    recordedUploadId: z.ZodNullable<z.ZodString>;
    datasetId: z.ZodString;
    datasetUniqueId: z.ZodString;
    accessType: z.ZodEnum<{
        PURCHASE: "PURCHASE";
        FREE_CLAIM: "FREE_CLAIM";
    }>;
    grantedAt: z.ZodString;
    expiresAt: z.ZodNullable<z.ZodString>;
    recordedAccess: z.ZodEnum<{
        REVOKED: "REVOKED";
        RECORDED: "RECORDED";
        EXPIRED: "EXPIRED";
        UNRESOLVED: "UNRESOLVED";
    }>;
}, z.core.$strict>], "representation">;
export declare const DatasetLibraryListResponseSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        representation: z.ZodLiteral<"CONTENT">;
        title: z.ZodNullable<z.ZodString>;
        metadataProvenance: z.ZodEnum<{
            UNRESOLVED: "UNRESOLVED";
            FROZEN_GRANT_CONTENT: "FROZEN_GRANT_CONTENT";
        }>;
        description: z.ZodNullable<z.ZodObject<{
            title: z.ZodString;
            license: z.ZodString;
            overview: z.ZodString;
            description: z.ZodString;
            dataQuality: z.ZodString;
            collectionBoundary: z.ZodString;
            geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"KNOWN">;
                description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"NOT_APPLICABLE">;
            }, z.core.$strict>], "state">>>;
            collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"KNOWN">;
                start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    precision: z.ZodLiteral<"YEAR">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"MONTH">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"DAY">;
                    value: z.ZodISODate;
                }, z.core.$strict>], "precision">>>;
                end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    precision: z.ZodLiteral<"YEAR">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"MONTH">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"DAY">;
                    value: z.ZodISODate;
                }, z.core.$strict>], "precision">>>;
                notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"NOT_APPLICABLE">;
            }, z.core.$strict>], "state">>>;
            limitations: z.ZodNullable<z.ZodString>;
            methodology: z.ZodNullable<z.ZodString>;
            useCases: z.ZodNullable<z.ZodString>;
            uploadChoice: z.ZodEnum<{
                SAMPLE_ONLY: "SAMPLE_ONLY";
                FULL_ONLY: "FULL_ONLY";
                FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
            }>;
            modalities: z.ZodArray<z.ZodEnum<{
                SENSOR: "SENSOR";
                TABULAR: "TABULAR";
                AUDIO: "AUDIO";
                IMAGE: "IMAGE";
                VIDEO: "VIDEO";
                TEXT: "TEXT";
            }>>;
            contexts: z.ZodArray<z.ZodEnum<{
                HEALTHCARE: "HEALTHCARE";
                EGOCENTRIC: "EGOCENTRIC";
            }>>;
            studyStructure: z.ZodNullable<z.ZodString>;
            tags: z.ZodArray<z.ZodString>;
            categoriesAtFreeze: z.ZodObject<{
                primary: z.ZodObject<{
                    id: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>;
                additional: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            sourceAtFreeze: z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
                description: z.ZodNullable<z.ZodString>;
                websiteUrl: z.ZodNullable<z.ZodString>;
                isVerifiedAtFreeze: z.ZodBoolean;
            }, z.core.$strict>;
            measurements: z.ZodArray<z.ZodObject<{
                scope: z.ZodEnum<{
                    REPRESENTED_COLLECTION: "REPRESENTED_COLLECTION";
                    FULL_MATERIAL: "FULL_MATERIAL";
                    SAMPLE_MATERIAL: "SAMPLE_MATERIAL";
                }>;
                origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
                values: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    state: z.ZodLiteral<"UNKNOWN">;
                    metric: z.ZodEnum<{
                        RECORD_COUNT: "RECORD_COUNT";
                        ROW_COUNT: "ROW_COUNT";
                        COLUMN_COUNT: "COLUMN_COUNT";
                        AUDIO_DURATION: "AUDIO_DURATION";
                        IMAGE_COUNT: "IMAGE_COUNT";
                        VIDEO_DURATION: "VIDEO_DURATION";
                        DOCUMENT_COUNT: "DOCUMENT_COUNT";
                        SESSION_COUNT: "SESSION_COUNT";
                        PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                        STREAM_COUNT: "STREAM_COUNT";
                        BYTE_SIZE: "BYTE_SIZE";
                    }>;
                    unit: z.ZodEnum<{
                        COUNT: "COUNT";
                        SECOND: "SECOND";
                        MINUTE: "MINUTE";
                        HOUR: "HOUR";
                        BYTE: "BYTE";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    state: z.ZodEnum<{
                        KNOWN: "KNOWN";
                        ESTIMATED: "ESTIMATED";
                    }>;
                    value: z.ZodString;
                    metric: z.ZodEnum<{
                        RECORD_COUNT: "RECORD_COUNT";
                        ROW_COUNT: "ROW_COUNT";
                        COLUMN_COUNT: "COLUMN_COUNT";
                        AUDIO_DURATION: "AUDIO_DURATION";
                        IMAGE_COUNT: "IMAGE_COUNT";
                        VIDEO_DURATION: "VIDEO_DURATION";
                        DOCUMENT_COUNT: "DOCUMENT_COUNT";
                        SESSION_COUNT: "SESSION_COUNT";
                        PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                        STREAM_COUNT: "STREAM_COUNT";
                        BYTE_SIZE: "BYTE_SIZE";
                    }>;
                    unit: z.ZodEnum<{
                        COUNT: "COUNT";
                        SECOND: "SECOND";
                        MINUTE: "MINUTE";
                        HOUR: "HOUR";
                        BYTE: "BYTE";
                    }>;
                }, z.core.$strict>], "state">>;
            }, z.core.$strict>>;
            sample: z.ZodNullable<z.ZodObject<{
                selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    DESCRIBED: "DESCRIBED";
                    NONE_KNOWN: "NONE_KNOWN";
                }>>>;
                omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    DESCRIBED: "DESCRIBED";
                    NONE_DECLARED: "NONE_DECLARED";
                }>>>;
                transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>;
            fullCompleteness: z.ZodNullable<z.ZodBoolean>;
            profiles: z.ZodObject<{
                tabular: z.ZodOptional<z.ZodObject<{
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                }, z.core.$strict>>;
                audio: z.ZodOptional<z.ZodObject<{
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        SPEECH: "SPEECH";
                        NON_SPEECH: "NON_SPEECH";
                        MIXED: "MIXED";
                    }>>>;
                    transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        UNTIMED: "UNTIMED";
                        TIMED: "TIMED";
                    }>>>;
                }, z.core.$strict>>;
                images: z.ZodOptional<z.ZodObject<{
                    coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
                video: z.ZodOptional<z.ZodObject<{
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        WHOLE_ITEM: "WHOLE_ITEM";
                        TIME_OR_FRAME: "TIME_OR_FRAME";
                    }>>>;
                }, z.core.$strict>>;
                text: z.ZodOptional<z.ZodObject<{
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        MIXED: "MIXED";
                        HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                        NON_LANGUAGE: "NON_LANGUAGE";
                    }>>>;
                }, z.core.$strict>>;
                sensors: z.ZodOptional<z.ZodObject<{
                    channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>>;
                    synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        DESCRIBED: "DESCRIBED";
                        NO_CLAIM: "NO_CLAIM";
                    }>>>;
                }, z.core.$strict>>;
                egocentric: z.ZodOptional<z.ZodObject<{
                    mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
                healthcare: z.ZodOptional<z.ZodObject<{
                    recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        grantId: z.ZodNullable<z.ZodString>;
        material: z.ZodNullable<z.ZodObject<{
            datasetId: z.ZodString;
            contentId: z.ZodString;
            component: z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>;
        }, z.core.$strict>>;
        datasetId: z.ZodString;
        datasetUniqueId: z.ZodString;
        accessType: z.ZodEnum<{
            PURCHASE: "PURCHASE";
            FREE_CLAIM: "FREE_CLAIM";
        }>;
        grantedAt: z.ZodString;
        expiresAt: z.ZodNullable<z.ZodString>;
        recordedAccess: z.ZodEnum<{
            REVOKED: "REVOKED";
            RECORDED: "RECORDED";
            EXPIRED: "EXPIRED";
            UNRESOLVED: "UNRESOLVED";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        representation: z.ZodLiteral<"LEGACY">;
        title: z.ZodString;
        metadataProvenance: z.ZodLiteral<"CURRENT_LEGACY_RECORD">;
        historicalMetadata: z.ZodNull;
        recordedUploadId: z.ZodNullable<z.ZodString>;
        datasetId: z.ZodString;
        datasetUniqueId: z.ZodString;
        accessType: z.ZodEnum<{
            PURCHASE: "PURCHASE";
            FREE_CLAIM: "FREE_CLAIM";
        }>;
        grantedAt: z.ZodString;
        expiresAt: z.ZodNullable<z.ZodString>;
        recordedAccess: z.ZodEnum<{
            REVOKED: "REVOKED";
            RECORDED: "RECORDED";
            EXPIRED: "EXPIRED";
            UNRESOLVED: "UNRESOLVED";
        }>;
    }, z.core.$strict>], "representation">>;
    page: z.ZodNumber;
    pageSize: z.ZodNumber;
    total: z.ZodNumber;
}, z.core.$strict>;
export declare const DatasetLibraryGetResponseSchema: z.ZodObject<{
    item: z.ZodDiscriminatedUnion<[z.ZodObject<{
        representation: z.ZodLiteral<"CONTENT">;
        title: z.ZodNullable<z.ZodString>;
        metadataProvenance: z.ZodEnum<{
            UNRESOLVED: "UNRESOLVED";
            FROZEN_GRANT_CONTENT: "FROZEN_GRANT_CONTENT";
        }>;
        description: z.ZodNullable<z.ZodObject<{
            title: z.ZodString;
            license: z.ZodString;
            overview: z.ZodString;
            description: z.ZodString;
            dataQuality: z.ZodString;
            collectionBoundary: z.ZodString;
            geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"KNOWN">;
                description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"NOT_APPLICABLE">;
            }, z.core.$strict>], "state">>>;
            collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"KNOWN">;
                start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    precision: z.ZodLiteral<"YEAR">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"MONTH">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"DAY">;
                    value: z.ZodISODate;
                }, z.core.$strict>], "precision">>>;
                end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    precision: z.ZodLiteral<"YEAR">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"MONTH">;
                    value: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    precision: z.ZodLiteral<"DAY">;
                    value: z.ZodISODate;
                }, z.core.$strict>], "precision">>>;
                notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodLiteral<"NOT_APPLICABLE">;
            }, z.core.$strict>], "state">>>;
            limitations: z.ZodNullable<z.ZodString>;
            methodology: z.ZodNullable<z.ZodString>;
            useCases: z.ZodNullable<z.ZodString>;
            uploadChoice: z.ZodEnum<{
                SAMPLE_ONLY: "SAMPLE_ONLY";
                FULL_ONLY: "FULL_ONLY";
                FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
            }>;
            modalities: z.ZodArray<z.ZodEnum<{
                SENSOR: "SENSOR";
                TABULAR: "TABULAR";
                AUDIO: "AUDIO";
                IMAGE: "IMAGE";
                VIDEO: "VIDEO";
                TEXT: "TEXT";
            }>>;
            contexts: z.ZodArray<z.ZodEnum<{
                HEALTHCARE: "HEALTHCARE";
                EGOCENTRIC: "EGOCENTRIC";
            }>>;
            studyStructure: z.ZodNullable<z.ZodString>;
            tags: z.ZodArray<z.ZodString>;
            categoriesAtFreeze: z.ZodObject<{
                primary: z.ZodObject<{
                    id: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>;
                additional: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            sourceAtFreeze: z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
                description: z.ZodNullable<z.ZodString>;
                websiteUrl: z.ZodNullable<z.ZodString>;
                isVerifiedAtFreeze: z.ZodBoolean;
            }, z.core.$strict>;
            measurements: z.ZodArray<z.ZodObject<{
                scope: z.ZodEnum<{
                    REPRESENTED_COLLECTION: "REPRESENTED_COLLECTION";
                    FULL_MATERIAL: "FULL_MATERIAL";
                    SAMPLE_MATERIAL: "SAMPLE_MATERIAL";
                }>;
                origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
                values: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    state: z.ZodLiteral<"UNKNOWN">;
                    metric: z.ZodEnum<{
                        RECORD_COUNT: "RECORD_COUNT";
                        ROW_COUNT: "ROW_COUNT";
                        COLUMN_COUNT: "COLUMN_COUNT";
                        AUDIO_DURATION: "AUDIO_DURATION";
                        IMAGE_COUNT: "IMAGE_COUNT";
                        VIDEO_DURATION: "VIDEO_DURATION";
                        DOCUMENT_COUNT: "DOCUMENT_COUNT";
                        SESSION_COUNT: "SESSION_COUNT";
                        PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                        STREAM_COUNT: "STREAM_COUNT";
                        BYTE_SIZE: "BYTE_SIZE";
                    }>;
                    unit: z.ZodEnum<{
                        COUNT: "COUNT";
                        SECOND: "SECOND";
                        MINUTE: "MINUTE";
                        HOUR: "HOUR";
                        BYTE: "BYTE";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    state: z.ZodEnum<{
                        KNOWN: "KNOWN";
                        ESTIMATED: "ESTIMATED";
                    }>;
                    value: z.ZodString;
                    metric: z.ZodEnum<{
                        RECORD_COUNT: "RECORD_COUNT";
                        ROW_COUNT: "ROW_COUNT";
                        COLUMN_COUNT: "COLUMN_COUNT";
                        AUDIO_DURATION: "AUDIO_DURATION";
                        IMAGE_COUNT: "IMAGE_COUNT";
                        VIDEO_DURATION: "VIDEO_DURATION";
                        DOCUMENT_COUNT: "DOCUMENT_COUNT";
                        SESSION_COUNT: "SESSION_COUNT";
                        PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                        STREAM_COUNT: "STREAM_COUNT";
                        BYTE_SIZE: "BYTE_SIZE";
                    }>;
                    unit: z.ZodEnum<{
                        COUNT: "COUNT";
                        SECOND: "SECOND";
                        MINUTE: "MINUTE";
                        HOUR: "HOUR";
                        BYTE: "BYTE";
                    }>;
                }, z.core.$strict>], "state">>;
            }, z.core.$strict>>;
            sample: z.ZodNullable<z.ZodObject<{
                selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    DESCRIBED: "DESCRIBED";
                    NONE_KNOWN: "NONE_KNOWN";
                }>>>;
                omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    DESCRIBED: "DESCRIBED";
                    NONE_DECLARED: "NONE_DECLARED";
                }>>>;
                transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>;
            fullCompleteness: z.ZodNullable<z.ZodBoolean>;
            profiles: z.ZodObject<{
                tabular: z.ZodOptional<z.ZodObject<{
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                }, z.core.$strict>>;
                audio: z.ZodOptional<z.ZodObject<{
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        SPEECH: "SPEECH";
                        NON_SPEECH: "NON_SPEECH";
                        MIXED: "MIXED";
                    }>>>;
                    transcriptTiming: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        UNTIMED: "UNTIMED";
                        TIMED: "TIMED";
                    }>>>;
                }, z.core.$strict>>;
                images: z.ZodOptional<z.ZodObject<{
                    coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
                video: z.ZodOptional<z.ZodObject<{
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationReferences: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        WHOLE_ITEM: "WHOLE_ITEM";
                        TIME_OR_FRAME: "TIME_OR_FRAME";
                    }>>>;
                }, z.core.$strict>>;
                text: z.ZodOptional<z.ZodObject<{
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    languageContent: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        MIXED: "MIXED";
                        HUMAN_LANGUAGE: "HUMAN_LANGUAGE";
                        NON_LANGUAGE: "NON_LANGUAGE";
                    }>>>;
                }, z.core.$strict>>;
                sensors: z.ZodOptional<z.ZodObject<{
                    channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                    }>>>;
                    calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>>;
                    synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        DESCRIBED: "DESCRIBED";
                        NO_CLAIM: "NO_CLAIM";
                    }>>>;
                }, z.core.$strict>>;
                egocentric: z.ZodOptional<z.ZodObject<{
                    mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
                healthcare: z.ZodOptional<z.ZodObject<{
                    recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        grantId: z.ZodNullable<z.ZodString>;
        material: z.ZodNullable<z.ZodObject<{
            datasetId: z.ZodString;
            contentId: z.ZodString;
            component: z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>;
        }, z.core.$strict>>;
        datasetId: z.ZodString;
        datasetUniqueId: z.ZodString;
        accessType: z.ZodEnum<{
            PURCHASE: "PURCHASE";
            FREE_CLAIM: "FREE_CLAIM";
        }>;
        grantedAt: z.ZodString;
        expiresAt: z.ZodNullable<z.ZodString>;
        recordedAccess: z.ZodEnum<{
            REVOKED: "REVOKED";
            RECORDED: "RECORDED";
            EXPIRED: "EXPIRED";
            UNRESOLVED: "UNRESOLVED";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        representation: z.ZodLiteral<"LEGACY">;
        title: z.ZodString;
        metadataProvenance: z.ZodLiteral<"CURRENT_LEGACY_RECORD">;
        historicalMetadata: z.ZodNull;
        recordedUploadId: z.ZodNullable<z.ZodString>;
        datasetId: z.ZodString;
        datasetUniqueId: z.ZodString;
        accessType: z.ZodEnum<{
            PURCHASE: "PURCHASE";
            FREE_CLAIM: "FREE_CLAIM";
        }>;
        grantedAt: z.ZodString;
        expiresAt: z.ZodNullable<z.ZodString>;
        recordedAccess: z.ZodEnum<{
            REVOKED: "REVOKED";
            RECORDED: "RECORDED";
            EXPIRED: "EXPIRED";
            UNRESOLVED: "UNRESOLVED";
        }>;
    }, z.core.$strict>], "representation">;
}, z.core.$strict>;
export type DatasetLibraryItem = z.infer<typeof DatasetLibraryItemSchema>;
export type DatasetLibraryListQuery = z.infer<typeof DatasetLibraryListQuerySchema>;
export type DatasetLibraryListResponse = z.infer<typeof DatasetLibraryListResponseSchema>;
//# sourceMappingURL=reader.schema.d.ts.map