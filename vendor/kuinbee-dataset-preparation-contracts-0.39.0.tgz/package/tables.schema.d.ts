import { z } from "zod";
export declare const DatasetTableAnswerStateSchema: z.ZodEnum<{
    KNOWN: "KNOWN";
    UNKNOWN: "UNKNOWN";
    NOT_APPLICABLE: "NOT_APPLICABLE";
}>;
export declare const DatasetTableApplicabilitySchema: z.ZodObject<{
    purpose: z.ZodEnum<{
        PRIMARY: "PRIMARY";
        TRANSCRIPT: "TRANSCRIPT";
        ANNOTATION: "ANNOTATION";
        SENSOR: "SENSOR";
        CALIBRATION: "CALIBRATION";
        DOCUMENTATION: "DOCUMENTATION";
        COMPANION: "COMPANION";
    }>;
    companionPurposes: z.ZodOptional<z.ZodArray<z.ZodEnum<{
        TRANSCRIPT: "TRANSCRIPT";
        ANNOTATION: "ANNOTATION";
        CALIBRATION: "CALIBRATION";
        DOCUMENTATION: "DOCUMENTATION";
    }>>>;
    origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
    basis: z.ZodEnum<{
        SELECTED_FILE_PURPOSE: "SELECTED_FILE_PURPOSE";
        EXACT_ENTRY_RELATIONSHIP: "EXACT_ENTRY_RELATIONSHIP";
    }>;
    definitionsRequired: z.ZodBoolean;
}, z.core.$strict>;
export type DatasetTableApplicability = z.infer<typeof DatasetTableApplicabilitySchema>;
export declare const DatasetColumnSemanticTypeSchema: z.ZodEnum<{
    TEXT: "TEXT";
    UNKNOWN: "UNKNOWN";
    IDENTIFIER: "IDENTIFIER";
    CATEGORY: "CATEGORY";
    INTEGER: "INTEGER";
    DECIMAL: "DECIMAL";
    BOOLEAN: "BOOLEAN";
    DATE: "DATE";
    DATETIME: "DATETIME";
    COORDINATE: "COORDINATE";
    OTHER: "OTHER";
}>;
export declare const DatasetTableDescriptionChangesSchema: z.ZodObject<{
    displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    missingConventionState: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        KNOWN: "KNOWN";
        UNKNOWN: "UNKNOWN";
        NOT_APPLICABLE: "NOT_APPLICABLE";
    }>>>;
    missingConventionDetails: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strict>;
export declare const DatasetColumnDescriptionChangesSchema: z.ZodObject<{
    meaningState: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        KNOWN: "KNOWN";
        UNKNOWN: "UNKNOWN";
    }>>>;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    semanticType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        TEXT: "TEXT";
        UNKNOWN: "UNKNOWN";
        IDENTIFIER: "IDENTIFIER";
        CATEGORY: "CATEGORY";
        INTEGER: "INTEGER";
        DECIMAL: "DECIMAL";
        BOOLEAN: "BOOLEAN";
        DATE: "DATE";
        DATETIME: "DATETIME";
        COORDINATE: "COORDINATE";
        OTHER: "OTHER";
    }>>>;
    unitState: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        KNOWN: "KNOWN";
        UNKNOWN: "UNKNOWN";
        NOT_APPLICABLE: "NOT_APPLICABLE";
    }>>>;
    unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strict>;
export declare const DatasetTableDescriptionOperationSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    operation: z.ZodLiteral<"SET_TABLE">;
    memberId: z.ZodString;
    tableId: z.ZodString;
    changes: z.ZodObject<{
        displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        missingConventionState: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            KNOWN: "KNOWN";
            UNKNOWN: "UNKNOWN";
            NOT_APPLICABLE: "NOT_APPLICABLE";
        }>>>;
        missingConventionDetails: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"SET_COLUMN">;
    memberId: z.ZodString;
    tableId: z.ZodString;
    columnId: z.ZodString;
    changes: z.ZodObject<{
        meaningState: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            KNOWN: "KNOWN";
            UNKNOWN: "UNKNOWN";
        }>>>;
        description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        semanticType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            TEXT: "TEXT";
            UNKNOWN: "UNKNOWN";
            IDENTIFIER: "IDENTIFIER";
            CATEGORY: "CATEGORY";
            INTEGER: "INTEGER";
            DECIMAL: "DECIMAL";
            BOOLEAN: "BOOLEAN";
            DATE: "DATE";
            DATETIME: "DATETIME";
            COORDINATE: "COORDINATE";
            OTHER: "OTHER";
        }>>>;
        unitState: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            KNOWN: "KNOWN";
            UNKNOWN: "UNKNOWN";
            NOT_APPLICABLE: "NOT_APPLICABLE";
        }>>>;
        unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
}, z.core.$strict>], "operation">;
export declare const DatasetTableDescriptionsMutationBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedContentId: z.ZodString;
    expectedGeneration: z.ZodNumber;
    expectedPreparationGeneration: z.ZodNumber;
    editContext: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodLiteral<"EXISTING_DRAFT">;
        expectedContentId: z.ZodString;
        expectedGeneration: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"INITIALIZE">;
        expectedWorkflowRevision: z.ZodNumber;
        context: z.ZodEnum<{
            REQUESTED_CHANGES: "REQUESTED_CHANGES";
            MANAGED_EDIT: "MANAGED_EDIT";
            APPROVED_REEDIT: "APPROVED_REEDIT";
            PLATFORM_WITHDRAWAL: "PLATFORM_WITHDRAWAL";
            PLATFORM_PUBLISHED_METADATA: "PLATFORM_PUBLISHED_METADATA";
        }>;
        expectedBaseContentId: z.ZodString;
    }, z.core.$strict>], "mode">>;
    operations: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        operation: z.ZodLiteral<"SET_TABLE">;
        memberId: z.ZodString;
        tableId: z.ZodString;
        changes: z.ZodObject<{
            displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            missingConventionState: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                KNOWN: "KNOWN";
                UNKNOWN: "UNKNOWN";
                NOT_APPLICABLE: "NOT_APPLICABLE";
            }>>>;
            missingConventionDetails: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"SET_COLUMN">;
        memberId: z.ZodString;
        tableId: z.ZodString;
        columnId: z.ZodString;
        changes: z.ZodObject<{
            meaningState: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                KNOWN: "KNOWN";
                UNKNOWN: "UNKNOWN";
            }>>>;
            description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            semanticType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                TEXT: "TEXT";
                UNKNOWN: "UNKNOWN";
                IDENTIFIER: "IDENTIFIER";
                CATEGORY: "CATEGORY";
                INTEGER: "INTEGER";
                DECIMAL: "DECIMAL";
                BOOLEAN: "BOOLEAN";
                DATE: "DATE";
                DATETIME: "DATETIME";
                COORDINATE: "COORDINATE";
                OTHER: "OTHER";
            }>>>;
            unitState: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                KNOWN: "KNOWN";
                UNKNOWN: "UNKNOWN";
                NOT_APPLICABLE: "NOT_APPLICABLE";
            }>>>;
            unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>;
    }, z.core.$strict>], "operation">>;
}, z.core.$strict>;
export declare const DatasetTableDescriptionsPageQuerySchema: z.ZodObject<{
    contentId: z.ZodString;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    expectedPreparationGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    memberId: z.ZodString;
    tableId: z.ZodOptional<z.ZodString>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export declare const DatasetTableDescriptionItemSchema: z.ZodObject<{
    kind: z.ZodLiteral<"TABLE">;
    id: z.ZodString;
    syntaxProfileId: z.ZodEnum<{
        UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
        UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
    }>;
    applicability: z.ZodObject<{
        purpose: z.ZodEnum<{
            PRIMARY: "PRIMARY";
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            SENSOR: "SENSOR";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
            COMPANION: "COMPANION";
        }>;
        companionPurposes: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
        }>>>;
        origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
        basis: z.ZodEnum<{
            SELECTED_FILE_PURPOSE: "SELECTED_FILE_PURPOSE";
            EXACT_ENTRY_RELATIONSHIP: "EXACT_ENTRY_RELATIONSHIP";
        }>;
        definitionsRequired: z.ZodBoolean;
    }, z.core.$strict>;
    headerConvention: z.ZodEnum<{
        PRESENT: "PRESENT";
        ABSENT: "ABSENT";
    }>;
    logicalEntryId: z.ZodNullable<z.ZodString>;
    locator: z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
        path: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"WORKBOOK_SHEET">;
        sheetName: z.ZodString;
    }, z.core.$strict>], "kind">>;
    columnCount: z.ZodNumber;
    recordCount: z.ZodString;
    dataRecordCount: z.ZodString;
    description: z.ZodNullable<z.ZodObject<{
        displayName: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        recordUnit: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        missingConventionState: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            KNOWN: "KNOWN";
            UNKNOWN: "UNKNOWN";
            NOT_APPLICABLE: "NOT_APPLICABLE";
        }>>>>;
        missingConventionDetails: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetColumnDescriptionItemSchema: z.ZodObject<{
    kind: z.ZodLiteral<"COLUMN">;
    id: z.ZodString;
    tableId: z.ZodString;
    position: z.ZodNumber;
    observedName: z.ZodNullable<z.ZodString>;
    storageRepresentation: z.ZodLiteral<"UTF8_TEXT">;
    description: z.ZodNullable<z.ZodObject<{
        meaningState: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            KNOWN: "KNOWN";
            UNKNOWN: "UNKNOWN";
        }>>>>;
        description: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        semanticType: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            TEXT: "TEXT";
            UNKNOWN: "UNKNOWN";
            IDENTIFIER: "IDENTIFIER";
            CATEGORY: "CATEGORY";
            INTEGER: "INTEGER";
            DECIMAL: "DECIMAL";
            BOOLEAN: "BOOLEAN";
            DATE: "DATE";
            DATETIME: "DATETIME";
            COORDINATE: "COORDINATE";
            OTHER: "OTHER";
        }>>>>;
        unitState: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            KNOWN: "KNOWN";
            UNKNOWN: "UNKNOWN";
            NOT_APPLICABLE: "NOT_APPLICABLE";
        }>>>>;
        unit: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetTableDescriptionsPageResponseSchema: z.ZodObject<{
    contentId: z.ZodString;
    contentGeneration: z.ZodNumber;
    preparationGeneration: z.ZodNumber;
    frozen: z.ZodBoolean;
    memberId: z.ZodString;
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    tableId: z.ZodNullable<z.ZodString>;
    table: z.ZodNullable<z.ZodObject<{
        kind: z.ZodLiteral<"TABLE">;
        id: z.ZodString;
        syntaxProfileId: z.ZodEnum<{
            UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
            UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
        }>;
        applicability: z.ZodObject<{
            purpose: z.ZodEnum<{
                PRIMARY: "PRIMARY";
                TRANSCRIPT: "TRANSCRIPT";
                ANNOTATION: "ANNOTATION";
                SENSOR: "SENSOR";
                CALIBRATION: "CALIBRATION";
                DOCUMENTATION: "DOCUMENTATION";
                COMPANION: "COMPANION";
            }>;
            companionPurposes: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                TRANSCRIPT: "TRANSCRIPT";
                ANNOTATION: "ANNOTATION";
                CALIBRATION: "CALIBRATION";
                DOCUMENTATION: "DOCUMENTATION";
            }>>>;
            origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
            basis: z.ZodEnum<{
                SELECTED_FILE_PURPOSE: "SELECTED_FILE_PURPOSE";
                EXACT_ENTRY_RELATIONSHIP: "EXACT_ENTRY_RELATIONSHIP";
            }>;
            definitionsRequired: z.ZodBoolean;
        }, z.core.$strict>;
        headerConvention: z.ZodEnum<{
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
        }>;
        logicalEntryId: z.ZodNullable<z.ZodString>;
        locator: z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
            path: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"WORKBOOK_SHEET">;
            sheetName: z.ZodString;
        }, z.core.$strict>], "kind">>;
        columnCount: z.ZodNumber;
        recordCount: z.ZodString;
        dataRecordCount: z.ZodString;
        description: z.ZodNullable<z.ZodObject<{
            displayName: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
            recordUnit: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
            missingConventionState: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                KNOWN: "KNOWN";
                UNKNOWN: "UNKNOWN";
                NOT_APPLICABLE: "NOT_APPLICABLE";
            }>>>>;
            missingConventionDetails: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    items: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"TABLE">;
        id: z.ZodString;
        syntaxProfileId: z.ZodEnum<{
            UTF8_CSV_SYNTAX_V1: "UTF8_CSV_SYNTAX_V1";
            UTF8_TSV_SYNTAX_V1: "UTF8_TSV_SYNTAX_V1";
        }>;
        applicability: z.ZodObject<{
            purpose: z.ZodEnum<{
                PRIMARY: "PRIMARY";
                TRANSCRIPT: "TRANSCRIPT";
                ANNOTATION: "ANNOTATION";
                SENSOR: "SENSOR";
                CALIBRATION: "CALIBRATION";
                DOCUMENTATION: "DOCUMENTATION";
                COMPANION: "COMPANION";
            }>;
            companionPurposes: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                TRANSCRIPT: "TRANSCRIPT";
                ANNOTATION: "ANNOTATION";
                CALIBRATION: "CALIBRATION";
                DOCUMENTATION: "DOCUMENTATION";
            }>>>;
            origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
            basis: z.ZodEnum<{
                SELECTED_FILE_PURPOSE: "SELECTED_FILE_PURPOSE";
                EXACT_ENTRY_RELATIONSHIP: "EXACT_ENTRY_RELATIONSHIP";
            }>;
            definitionsRequired: z.ZodBoolean;
        }, z.core.$strict>;
        headerConvention: z.ZodEnum<{
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
        }>;
        logicalEntryId: z.ZodNullable<z.ZodString>;
        locator: z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
            path: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"WORKBOOK_SHEET">;
            sheetName: z.ZodString;
        }, z.core.$strict>], "kind">>;
        columnCount: z.ZodNumber;
        recordCount: z.ZodString;
        dataRecordCount: z.ZodString;
        description: z.ZodNullable<z.ZodObject<{
            displayName: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
            recordUnit: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
            missingConventionState: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                KNOWN: "KNOWN";
                UNKNOWN: "UNKNOWN";
                NOT_APPLICABLE: "NOT_APPLICABLE";
            }>>>>;
            missingConventionDetails: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"COLUMN">;
        id: z.ZodString;
        tableId: z.ZodString;
        position: z.ZodNumber;
        observedName: z.ZodNullable<z.ZodString>;
        storageRepresentation: z.ZodLiteral<"UTF8_TEXT">;
        description: z.ZodNullable<z.ZodObject<{
            meaningState: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                KNOWN: "KNOWN";
                UNKNOWN: "UNKNOWN";
            }>>>>;
            description: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
            semanticType: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                TEXT: "TEXT";
                UNKNOWN: "UNKNOWN";
                IDENTIFIER: "IDENTIFIER";
                CATEGORY: "CATEGORY";
                INTEGER: "INTEGER";
                DECIMAL: "DECIMAL";
                BOOLEAN: "BOOLEAN";
                DATE: "DATE";
                DATETIME: "DATETIME";
                COORDINATE: "COORDINATE";
                OTHER: "OTHER";
            }>>>>;
            unitState: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                KNOWN: "KNOWN";
                UNKNOWN: "UNKNOWN";
                NOT_APPLICABLE: "NOT_APPLICABLE";
            }>>>>;
            unit: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
        }, z.core.$strict>>;
    }, z.core.$strict>], "kind">>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        contentId: z.ZodString;
        contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
        expectedPreparationGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
        memberId: z.ZodString;
        tableId: z.ZodOptional<z.ZodString>;
        afterId: z.ZodOptional<z.ZodString>;
        limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetTableDescriptionsMutationResponseSchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    contentId: z.ZodString;
    generation: z.ZodNumber;
    preparationGeneration: z.ZodNumber;
    results: z.ZodArray<z.ZodObject<{
        index: z.ZodNumber;
        operation: z.ZodEnum<{
            SET_TABLE: "SET_TABLE";
            SET_COLUMN: "SET_COLUMN";
        }>;
        memberId: z.ZodString;
        tableId: z.ZodString;
        columnId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type DatasetTableDescriptionsMutationBody = z.infer<typeof DatasetTableDescriptionsMutationBodySchema>;
export type DatasetTableDescriptionsPageQuery = z.infer<typeof DatasetTableDescriptionsPageQuerySchema>;
export type DatasetTableDescriptionsPageResponse = z.infer<typeof DatasetTableDescriptionsPageResponseSchema>;
export type DatasetTableDescriptionsMutationResponse = z.infer<typeof DatasetTableDescriptionsMutationResponseSchema>;
//# sourceMappingURL=tables.schema.d.ts.map