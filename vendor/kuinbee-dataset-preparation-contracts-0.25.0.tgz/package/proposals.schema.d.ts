import { z } from "zod";
export declare const DatasetSupplierProposalsQuerySchema: z.ZodObject<{
    scope: z.ZodDefault<z.ZodEnum<{
        SUBMITTED: "SUBMITTED";
        ALL: "ALL";
    }>>;
    q: z.ZodOptional<z.ZodString>;
    status: z.ZodOptional<z.ZodEnum<{
        REJECTED: "REJECTED";
        SUBMITTED: "SUBMITTED";
        UNDER_REVIEW: "UNDER_REVIEW";
        VERIFIED: "VERIFIED";
        PUBLISHED: "PUBLISHED";
        DELISTED: "DELISTED";
        ARCHIVED: "ARCHIVED";
    }>>;
    verificationStatus: z.ZodOptional<z.ZodEnum<{
        REJECTED: "REJECTED";
        PENDING: "PENDING";
        SUBMITTED: "SUBMITTED";
        CHANGES_REQUESTED: "CHANGES_REQUESTED";
        RESUBMITTED: "RESUBMITTED";
        UNDER_REVIEW: "UNDER_REVIEW";
        VERIFIED: "VERIFIED";
    }>>;
    page: z.ZodDefault<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
    pageSize: z.ZodDefault<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
}, z.core.$strict>;
export declare const DatasetAdminProposalsQuerySchema: z.ZodObject<{
    reviewQueue: z.ZodDefault<z.ZodEnum<{
        ALL: "ALL";
        PROPOSALS: "PROPOSALS";
        UPDATES: "UPDATES";
    }>>;
    assignedTo: z.ZodDefault<z.ZodEnum<{
        ANY: "ANY";
        ME: "ME";
        UNASSIGNED: "UNASSIGNED";
    }>>;
    sort: z.ZodDefault<z.ZodEnum<{
        "createdAt:asc": "createdAt:asc";
        "createdAt:desc": "createdAt:desc";
        "updatedAt:asc": "updatedAt:asc";
        "updatedAt:desc": "updatedAt:desc";
    }>>;
    q: z.ZodOptional<z.ZodString>;
    status: z.ZodOptional<z.ZodEnum<{
        REJECTED: "REJECTED";
        SUBMITTED: "SUBMITTED";
        UNDER_REVIEW: "UNDER_REVIEW";
        VERIFIED: "VERIFIED";
        PUBLISHED: "PUBLISHED";
        DELISTED: "DELISTED";
        ARCHIVED: "ARCHIVED";
    }>>;
    verificationStatus: z.ZodOptional<z.ZodEnum<{
        REJECTED: "REJECTED";
        PENDING: "PENDING";
        SUBMITTED: "SUBMITTED";
        CHANGES_REQUESTED: "CHANGES_REQUESTED";
        RESUBMITTED: "RESUBMITTED";
        UNDER_REVIEW: "UNDER_REVIEW";
        VERIFIED: "VERIFIED";
    }>>;
    page: z.ZodDefault<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
    pageSize: z.ZodDefault<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
}, z.core.$strict>;
export declare const DatasetAdminAssignmentsQuerySchema: z.ZodObject<{
    reviewQueue: z.ZodDefault<z.ZodEnum<{
        ALL: "ALL";
        PROPOSALS: "PROPOSALS";
        UPDATES: "UPDATES";
    }>>;
    status: z.ZodDefault<z.ZodEnum<{
        CANCELLED: "CANCELLED";
        ACTIVE: "ACTIVE";
        COMPLETED: "COMPLETED";
        ALL: "ALL";
        REASSIGNED: "REASSIGNED";
    }>>;
    sort: z.ZodDefault<z.ZodEnum<{
        "assignedAt:asc": "assignedAt:asc";
        "assignedAt:desc": "assignedAt:desc";
        "completedAt:asc": "completedAt:asc";
        "completedAt:desc": "completedAt:desc";
    }>>;
    page: z.ZodDefault<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
    pageSize: z.ZodDefault<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
}, z.core.$strict>;
export declare const DatasetProposalListItemSchema: z.ZodObject<{
    id: z.ZodString;
    datasetUniqueId: z.ZodString;
    title: z.ZodString;
    status: z.ZodEnum<{
        REJECTED: "REJECTED";
        SUBMITTED: "SUBMITTED";
        UNDER_REVIEW: "UNDER_REVIEW";
        VERIFIED: "VERIFIED";
        PUBLISHED: "PUBLISHED";
        DELISTED: "DELISTED";
        ARCHIVED: "ARCHIVED";
    }>;
    verificationStatus: z.ZodNullable<z.ZodEnum<{
        REJECTED: "REJECTED";
        PENDING: "PENDING";
        SUBMITTED: "SUBMITTED";
        CHANGES_REQUESTED: "CHANGES_REQUESTED";
        RESUBMITTED: "RESUBMITTED";
        UNDER_REVIEW: "UNDER_REVIEW";
        VERIFIED: "VERIFIED";
    }>>;
    primaryCategory: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
    }, z.core.$strict>>;
    material: z.ZodDiscriminatedUnion<[z.ZodObject<{
        representation: z.ZodLiteral<"LEGACY">;
        currentUploadId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        representation: z.ZodLiteral<"CONTENT">;
        activeContentId: z.ZodNullable<z.ZodString>;
        reviewedContentId: z.ZodNullable<z.ZodString>;
        publishedContentId: z.ZodNullable<z.ZodString>;
        uploadChoice: z.ZodNullable<z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>>;
        workflowRevision: z.ZodNumber;
    }, z.core.$strict>], "representation">;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, z.core.$strict>;
export declare const DatasetAdminDatasetListItemSchema: z.ZodObject<{
    id: z.ZodString;
    datasetUniqueId: z.ZodString;
    title: z.ZodString;
    status: z.ZodEnum<{
        REJECTED: "REJECTED";
        SUBMITTED: "SUBMITTED";
        UNDER_REVIEW: "UNDER_REVIEW";
        VERIFIED: "VERIFIED";
        PUBLISHED: "PUBLISHED";
        DELISTED: "DELISTED";
        ARCHIVED: "ARCHIVED";
    }>;
    verificationStatus: z.ZodNullable<z.ZodEnum<{
        REJECTED: "REJECTED";
        PENDING: "PENDING";
        SUBMITTED: "SUBMITTED";
        CHANGES_REQUESTED: "CHANGES_REQUESTED";
        RESUBMITTED: "RESUBMITTED";
        UNDER_REVIEW: "UNDER_REVIEW";
        VERIFIED: "VERIFIED";
    }>>;
    primaryCategory: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
    }, z.core.$strict>>;
    material: z.ZodDiscriminatedUnion<[z.ZodObject<{
        representation: z.ZodLiteral<"LEGACY">;
        currentUploadId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        representation: z.ZodLiteral<"CONTENT">;
        activeContentId: z.ZodNullable<z.ZodString>;
        reviewedContentId: z.ZodNullable<z.ZodString>;
        publishedContentId: z.ZodNullable<z.ZodString>;
        uploadChoice: z.ZodNullable<z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>>;
        workflowRevision: z.ZodNumber;
    }, z.core.$strict>], "representation">;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
    managementContext: z.ZodNullable<z.ZodEnum<{
        INITIAL_PROPOSAL: "INITIAL_PROPOSAL";
        MANAGED: "MANAGED";
    }>>;
    submittedAt: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetAdminProposalListItemSchema: z.ZodObject<{
    id: z.ZodString;
    datasetUniqueId: z.ZodString;
    title: z.ZodString;
    status: z.ZodEnum<{
        REJECTED: "REJECTED";
        SUBMITTED: "SUBMITTED";
        UNDER_REVIEW: "UNDER_REVIEW";
        VERIFIED: "VERIFIED";
        PUBLISHED: "PUBLISHED";
        DELISTED: "DELISTED";
        ARCHIVED: "ARCHIVED";
    }>;
    verificationStatus: z.ZodNullable<z.ZodEnum<{
        REJECTED: "REJECTED";
        PENDING: "PENDING";
        SUBMITTED: "SUBMITTED";
        CHANGES_REQUESTED: "CHANGES_REQUESTED";
        RESUBMITTED: "RESUBMITTED";
        UNDER_REVIEW: "UNDER_REVIEW";
        VERIFIED: "VERIFIED";
    }>>;
    primaryCategory: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
    }, z.core.$strict>>;
    material: z.ZodDiscriminatedUnion<[z.ZodObject<{
        representation: z.ZodLiteral<"LEGACY">;
        currentUploadId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        representation: z.ZodLiteral<"CONTENT">;
        activeContentId: z.ZodNullable<z.ZodString>;
        reviewedContentId: z.ZodNullable<z.ZodString>;
        publishedContentId: z.ZodNullable<z.ZodString>;
        uploadChoice: z.ZodNullable<z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>>;
        workflowRevision: z.ZodNumber;
    }, z.core.$strict>], "representation">;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
    managementContext: z.ZodNullable<z.ZodEnum<{
        INITIAL_PROPOSAL: "INITIAL_PROPOSAL";
        MANAGED: "MANAGED";
    }>>;
    submittedAt: z.ZodNullable<z.ZodString>;
    supplier: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        email: z.ZodString;
    }, z.core.$strict>>;
    activeAssignment: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        adminId: z.ZodString;
        status: z.ZodEnum<{
            CANCELLED: "CANCELLED";
            ACTIVE: "ACTIVE";
            COMPLETED: "COMPLETED";
            REASSIGNED: "REASSIGNED";
        }>;
        assignedAt: z.ZodString;
        completedAt: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetSupplierProposalsResponseSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        datasetUniqueId: z.ZodString;
        title: z.ZodString;
        status: z.ZodEnum<{
            REJECTED: "REJECTED";
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            PUBLISHED: "PUBLISHED";
            DELISTED: "DELISTED";
            ARCHIVED: "ARCHIVED";
        }>;
        verificationStatus: z.ZodNullable<z.ZodEnum<{
            REJECTED: "REJECTED";
            PENDING: "PENDING";
            SUBMITTED: "SUBMITTED";
            CHANGES_REQUESTED: "CHANGES_REQUESTED";
            RESUBMITTED: "RESUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
        }>>;
        primaryCategory: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>;
        material: z.ZodDiscriminatedUnion<[z.ZodObject<{
            representation: z.ZodLiteral<"LEGACY">;
            currentUploadId: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            representation: z.ZodLiteral<"CONTENT">;
            activeContentId: z.ZodNullable<z.ZodString>;
            reviewedContentId: z.ZodNullable<z.ZodString>;
            publishedContentId: z.ZodNullable<z.ZodString>;
            uploadChoice: z.ZodNullable<z.ZodEnum<{
                SAMPLE_ONLY: "SAMPLE_ONLY";
                FULL_ONLY: "FULL_ONLY";
                FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
            }>>;
            workflowRevision: z.ZodNumber;
        }, z.core.$strict>], "representation">;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strict>>;
    summary: z.ZodObject<{
        total: z.ZodNumber;
        byVerificationStatus: z.ZodObject<{
            SUBMITTED: z.ZodNumber;
            CHANGES_REQUESTED: z.ZodNumber;
            RESUBMITTED: z.ZodNumber;
            UNDER_REVIEW: z.ZodNumber;
            VERIFIED: z.ZodNumber;
            REJECTED: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>;
    page: z.ZodNumber;
    pageSize: z.ZodNumber;
    total: z.ZodNumber;
}, z.core.$strict>;
export declare const DatasetAdminProposalsResponseSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        datasetUniqueId: z.ZodString;
        title: z.ZodString;
        status: z.ZodEnum<{
            REJECTED: "REJECTED";
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            PUBLISHED: "PUBLISHED";
            DELISTED: "DELISTED";
            ARCHIVED: "ARCHIVED";
        }>;
        verificationStatus: z.ZodNullable<z.ZodEnum<{
            REJECTED: "REJECTED";
            PENDING: "PENDING";
            SUBMITTED: "SUBMITTED";
            CHANGES_REQUESTED: "CHANGES_REQUESTED";
            RESUBMITTED: "RESUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
        }>>;
        primaryCategory: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>;
        material: z.ZodDiscriminatedUnion<[z.ZodObject<{
            representation: z.ZodLiteral<"LEGACY">;
            currentUploadId: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            representation: z.ZodLiteral<"CONTENT">;
            activeContentId: z.ZodNullable<z.ZodString>;
            reviewedContentId: z.ZodNullable<z.ZodString>;
            publishedContentId: z.ZodNullable<z.ZodString>;
            uploadChoice: z.ZodNullable<z.ZodEnum<{
                SAMPLE_ONLY: "SAMPLE_ONLY";
                FULL_ONLY: "FULL_ONLY";
                FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
            }>>;
            workflowRevision: z.ZodNumber;
        }, z.core.$strict>], "representation">;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
        managementContext: z.ZodNullable<z.ZodEnum<{
            INITIAL_PROPOSAL: "INITIAL_PROPOSAL";
            MANAGED: "MANAGED";
        }>>;
        submittedAt: z.ZodNullable<z.ZodString>;
        supplier: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            email: z.ZodString;
        }, z.core.$strict>>;
        activeAssignment: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            adminId: z.ZodString;
            status: z.ZodEnum<{
                CANCELLED: "CANCELLED";
                ACTIVE: "ACTIVE";
                COMPLETED: "COMPLETED";
                REASSIGNED: "REASSIGNED";
            }>;
            assignedAt: z.ZodString;
            completedAt: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    page: z.ZodNumber;
    pageSize: z.ZodNumber;
    total: z.ZodNumber;
}, z.core.$strict>;
export declare const DatasetAdminAssignmentsResponseSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        assignment: z.ZodObject<{
            id: z.ZodString;
            adminId: z.ZodString;
            status: z.ZodEnum<{
                CANCELLED: "CANCELLED";
                ACTIVE: "ACTIVE";
                COMPLETED: "COMPLETED";
                REASSIGNED: "REASSIGNED";
            }>;
            assignedAt: z.ZodString;
            completedAt: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        dataset: z.ZodObject<{
            id: z.ZodString;
            datasetUniqueId: z.ZodString;
            title: z.ZodString;
            status: z.ZodEnum<{
                REJECTED: "REJECTED";
                SUBMITTED: "SUBMITTED";
                UNDER_REVIEW: "UNDER_REVIEW";
                VERIFIED: "VERIFIED";
                PUBLISHED: "PUBLISHED";
                DELISTED: "DELISTED";
                ARCHIVED: "ARCHIVED";
            }>;
            verificationStatus: z.ZodNullable<z.ZodEnum<{
                REJECTED: "REJECTED";
                PENDING: "PENDING";
                SUBMITTED: "SUBMITTED";
                CHANGES_REQUESTED: "CHANGES_REQUESTED";
                RESUBMITTED: "RESUBMITTED";
                UNDER_REVIEW: "UNDER_REVIEW";
                VERIFIED: "VERIFIED";
            }>>;
            primaryCategory: z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>;
            material: z.ZodDiscriminatedUnion<[z.ZodObject<{
                representation: z.ZodLiteral<"LEGACY">;
                currentUploadId: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                representation: z.ZodLiteral<"CONTENT">;
                activeContentId: z.ZodNullable<z.ZodString>;
                reviewedContentId: z.ZodNullable<z.ZodString>;
                publishedContentId: z.ZodNullable<z.ZodString>;
                uploadChoice: z.ZodNullable<z.ZodEnum<{
                    SAMPLE_ONLY: "SAMPLE_ONLY";
                    FULL_ONLY: "FULL_ONLY";
                    FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
                }>>;
                workflowRevision: z.ZodNumber;
            }, z.core.$strict>], "representation">;
            createdAt: z.ZodString;
            updatedAt: z.ZodString;
            managementContext: z.ZodNullable<z.ZodEnum<{
                INITIAL_PROPOSAL: "INITIAL_PROPOSAL";
                MANAGED: "MANAGED";
            }>>;
            submittedAt: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        supplier: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            email: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    page: z.ZodNumber;
    pageSize: z.ZodNumber;
    total: z.ZodNumber;
}, z.core.$strict>;
export type DatasetSupplierProposalsQuery = z.infer<typeof DatasetSupplierProposalsQuerySchema>;
export type DatasetAdminProposalsQuery = z.infer<typeof DatasetAdminProposalsQuerySchema>;
export type DatasetAdminAssignmentsQuery = z.infer<typeof DatasetAdminAssignmentsQuerySchema>;
export type DatasetProposalListItem = z.infer<typeof DatasetProposalListItemSchema>;
//# sourceMappingURL=proposals.schema.d.ts.map