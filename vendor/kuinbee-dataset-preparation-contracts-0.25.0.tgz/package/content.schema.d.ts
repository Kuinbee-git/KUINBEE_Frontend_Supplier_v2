import { z } from "zod";
export declare const DATASET_CONTENT_CONTRACT_VERSION: 1;
export declare const DATASET_CONTENT_LIMITS: {
    readonly operationsPerMutation: 50;
    readonly pageSize: 50;
    readonly snapshotBytes: 131072;
};
export declare const DatasetMaterialComponentSchema: z.ZodEnum<{
    FULL: "FULL";
    SAMPLE: "SAMPLE";
}>;
export declare const DatasetMaterialRoleSchema: z.ZodEnum<{
    SENSOR: "SENSOR";
    PRIMARY: "PRIMARY";
    TRANSCRIPT: "TRANSCRIPT";
    ANNOTATION: "ANNOTATION";
    CALIBRATION: "CALIBRATION";
    DOCUMENTATION: "DOCUMENTATION";
}>;
export declare const DatasetMaterialRelationshipKindSchema: z.ZodEnum<{
    TRANSCRIPT_FOR: "TRANSCRIPT_FOR";
    ANNOTATION_FOR: "ANNOTATION_FOR";
    CALIBRATION_FOR: "CALIBRATION_FOR";
    SYNCHRONIZED_WITH: "SYNCHRONIZED_WITH";
    DOCUMENTATION_FOR: "DOCUMENTATION_FOR";
}>;
export declare const DatasetSafeRelativePathSchema: z.ZodString;
export declare const DatasetLogicalLocatorSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
    path: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"WORKBOOK_SHEET">;
    sheetName: z.ZodString;
}, z.core.$strict>], "kind">;
export type DatasetLogicalLocator = z.infer<typeof DatasetLogicalLocatorSchema>;
export declare function datasetLogicalLocatorKey(locator: DatasetLogicalLocator): string;
export declare const DatasetMaterialTargetSchema: z.ZodObject<{
    memberId: z.ZodString;
    logicalEntryId: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetMaterialOperationSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    operation: z.ZodLiteral<"ADD_MEMBER">;
    uploadObjectId: z.ZodString;
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    role: z.ZodEnum<{
        SENSOR: "SENSOR";
        PRIMARY: "PRIMARY";
        TRANSCRIPT: "TRANSCRIPT";
        ANNOTATION: "ANNOTATION";
        CALIBRATION: "CALIBRATION";
        DOCUMENTATION: "DOCUMENTATION";
    }>;
    relativePath: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    groupId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"REMOVE_MEMBER">;
    memberId: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"SET_MEMBER_ROLE">;
    memberId: z.ZodString;
    role: z.ZodEnum<{
        SENSOR: "SENSOR";
        PRIMARY: "PRIMARY";
        TRANSCRIPT: "TRANSCRIPT";
        ANNOTATION: "ANNOTATION";
        CALIBRATION: "CALIBRATION";
        DOCUMENTATION: "DOCUMENTATION";
    }>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"SET_MEMBER_GROUP">;
    memberId: z.ZodString;
    groupId: z.ZodNullable<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"ADD_GROUP">;
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    label: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"RENAME_GROUP">;
    groupId: z.ZodString;
    label: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"REMOVE_GROUP">;
    groupId: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"ADD_LINK">;
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    kind: z.ZodEnum<{
        TRANSCRIPT_FOR: "TRANSCRIPT_FOR";
        ANNOTATION_FOR: "ANNOTATION_FOR";
        CALIBRATION_FOR: "CALIBRATION_FOR";
        SYNCHRONIZED_WITH: "SYNCHRONIZED_WITH";
        DOCUMENTATION_FOR: "DOCUMENTATION_FOR";
    }>;
    source: z.ZodObject<{
        memberId: z.ZodString;
        logicalEntryId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    target: z.ZodObject<{
        memberId: z.ZodString;
        logicalEntryId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    required: z.ZodBoolean;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"REMOVE_LINK">;
    linkId: z.ZodString;
}, z.core.$strict>], "operation">;
export declare const DatasetMaterialMutationBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedContentId: z.ZodString;
    expectedGeneration: z.ZodNumber;
    expectedPreparationGeneration: z.ZodOptional<z.ZodNumber>;
    editContext: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodLiteral<"EXISTING_DRAFT">;
        expectedContentId: z.ZodString;
        expectedGeneration: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"INITIALIZE">;
        expectedWorkflowRevision: z.ZodNumber;
        context: z.ZodEnum<{
            REQUESTED_CHANGES: "REQUESTED_CHANGES";
            MANAGED_EDIT: "MANAGED_EDIT";
            APPROVED_REEDIT: "APPROVED_REEDIT";
            PLATFORM_WITHDRAWAL: "PLATFORM_WITHDRAWAL";
            PLATFORM_PUBLISHED_METADATA: "PLATFORM_PUBLISHED_METADATA";
        }>;
        expectedBaseContentId: z.ZodString;
    }, z.core.$strict>], "mode">>;
    operations: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        operation: z.ZodLiteral<"ADD_MEMBER">;
        uploadObjectId: z.ZodString;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        role: z.ZodEnum<{
            SENSOR: "SENSOR";
            PRIMARY: "PRIMARY";
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
        }>;
        relativePath: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        groupId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"REMOVE_MEMBER">;
        memberId: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"SET_MEMBER_ROLE">;
        memberId: z.ZodString;
        role: z.ZodEnum<{
            SENSOR: "SENSOR";
            PRIMARY: "PRIMARY";
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"SET_MEMBER_GROUP">;
        memberId: z.ZodString;
        groupId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"ADD_GROUP">;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        label: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"RENAME_GROUP">;
        groupId: z.ZodString;
        label: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"REMOVE_GROUP">;
        groupId: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"ADD_LINK">;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        kind: z.ZodEnum<{
            TRANSCRIPT_FOR: "TRANSCRIPT_FOR";
            ANNOTATION_FOR: "ANNOTATION_FOR";
            CALIBRATION_FOR: "CALIBRATION_FOR";
            SYNCHRONIZED_WITH: "SYNCHRONIZED_WITH";
            DOCUMENTATION_FOR: "DOCUMENTATION_FOR";
        }>;
        source: z.ZodObject<{
            memberId: z.ZodString;
            logicalEntryId: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        target: z.ZodObject<{
            memberId: z.ZodString;
            logicalEntryId: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        required: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"REMOVE_LINK">;
        linkId: z.ZodString;
    }, z.core.$strict>], "operation">>;
}, z.core.$strict>;
export declare const DatasetMaterialCursorSchema: z.ZodObject<{
    contentId: z.ZodString;
    generation: z.ZodNumber;
    afterId: z.ZodString;
}, z.core.$strict>;
export declare const DatasetMaterialPageQuerySchema: z.ZodObject<{
    contentId: z.ZodString;
    generation: z.ZodNumber;
    component: z.ZodOptional<z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export { DatasetCorrectionContextSchema, DatasetCorrectionPreconditionSchema, DatasetEditOperationSchema, DatasetEditContextQuerySchema, DatasetEditContextResponseSchema, type DatasetCorrectionContext, type DatasetCorrectionPrecondition } from "./edit.schema";
export declare const DatasetFrozenMaterialReferenceSchema: z.ZodObject<{
    datasetId: z.ZodString;
    contentId: z.ZodString;
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
}, z.core.$strict>;
export declare const DatasetMemberDownloadRequestSchema: z.ZodObject<{
    expectedMaterial: z.ZodObject<{
        datasetId: z.ZodString;
        contentId: z.ZodString;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
    }, z.core.$strict>;
    memberId: z.ZodString;
    downloadIntentId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
}, z.core.$strict>;
export declare const DatasetLogicalEntryResponseSchema: z.ZodObject<{
    id: z.ZodString;
    inventoryId: z.ZodString;
    uploadObjectId: z.ZodString;
    locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
        path: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"WORKBOOK_SHEET">;
        sheetName: z.ZodString;
    }, z.core.$strict>], "kind">;
}, z.core.$strict>;
export declare const DatasetMaterialMemberResponseSchema: z.ZodObject<{
    id: z.ZodString;
    contentId: z.ZodString;
    uploadObjectId: z.ZodString;
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    role: z.ZodEnum<{
        SENSOR: "SENSOR";
        PRIMARY: "PRIMARY";
        TRANSCRIPT: "TRANSCRIPT";
        ANNOTATION: "ANNOTATION";
        CALIBRATION: "CALIBRATION";
        DOCUMENTATION: "DOCUMENTATION";
    }>;
    relativePath: z.ZodNullable<z.ZodString>;
    groupId: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetMaterialPageResponseSchema: z.ZodObject<{
    contentId: z.ZodString;
    generation: z.ZodNumber;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        contentId: z.ZodString;
        uploadObjectId: z.ZodString;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        role: z.ZodEnum<{
            SENSOR: "SENSOR";
            PRIMARY: "PRIMARY";
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
        }>;
        relativePath: z.ZodNullable<z.ZodString>;
        groupId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        contentId: z.ZodString;
        generation: z.ZodNumber;
        afterId: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetMaterialMutationResponseSchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    contentId: z.ZodString;
    generation: z.ZodNumber;
    results: z.ZodArray<z.ZodObject<{
        index: z.ZodNumber;
        operation: z.ZodEnum<{
            ADD_MEMBER: "ADD_MEMBER";
            REMOVE_MEMBER: "REMOVE_MEMBER";
            SET_MEMBER_ROLE: "SET_MEMBER_ROLE";
            SET_MEMBER_GROUP: "SET_MEMBER_GROUP";
            ADD_GROUP: "ADD_GROUP";
            RENAME_GROUP: "RENAME_GROUP";
            REMOVE_GROUP: "REMOVE_GROUP";
            ADD_LINK: "ADD_LINK";
            REMOVE_LINK: "REMOVE_LINK";
        }>;
        id: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetContentIdentityResponseSchema: z.ZodObject<{
    contractVersion: z.ZodLiteral<1>;
    id: z.ZodString;
    datasetId: z.ZodString;
    generation: z.ZodNumber;
    uploadChoice: z.ZodEnum<{
        SAMPLE_ONLY: "SAMPLE_ONLY";
        FULL_ONLY: "FULL_ONLY";
        FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
    }>;
    frozenAt: z.ZodNullable<z.ZodString>;
    baseContentId: z.ZodNullable<z.ZodString>;
    dependencyFingerprint: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetContentMetadataSchema: z.ZodObject<{
    collectionBoundary: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    limitations: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    collectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    possibleUses: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    modalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
        TABULAR: "TABULAR";
        AUDIO: "AUDIO";
        IMAGE: "IMAGE";
        VIDEO: "VIDEO";
        TEXT: "TEXT";
        SENSOR: "SENSOR";
    }>>>;
    contexts: z.ZodOptional<z.ZodArray<z.ZodEnum<{
        HEALTHCARE: "HEALTHCARE";
        EGOCENTRIC: "EGOCENTRIC";
    }>>>;
    geographicCoverage: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"KNOWN">;
        description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"NOT_APPLICABLE">;
    }, z.core.$strict>], "state">>>;
    collectionPeriod: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"KNOWN">;
        start: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            precision: z.ZodLiteral<"YEAR">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"MONTH">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"DAY">;
            value: z.ZodISODate;
        }, z.core.$strict>], "precision">>>;
        end: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            precision: z.ZodLiteral<"YEAR">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"MONTH">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            precision: z.ZodLiteral<"DAY">;
            value: z.ZodISODate;
        }, z.core.$strict>], "precision">>>;
        notes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodLiteral<"NOT_APPLICABLE">;
    }, z.core.$strict>], "state">>>;
    collectionMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
        metric: z.ZodEnum<{
            RECORD_COUNT: "RECORD_COUNT";
            ROW_COUNT: "ROW_COUNT";
            COLUMN_COUNT: "COLUMN_COUNT";
            AUDIO_DURATION: "AUDIO_DURATION";
            IMAGE_COUNT: "IMAGE_COUNT";
            VIDEO_DURATION: "VIDEO_DURATION";
            DOCUMENT_COUNT: "DOCUMENT_COUNT";
            SESSION_COUNT: "SESSION_COUNT";
            PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
            STREAM_COUNT: "STREAM_COUNT";
            BYTE_SIZE: "BYTE_SIZE";
        }>;
        unit: z.ZodEnum<{
            COUNT: "COUNT";
            SECOND: "SECOND";
            MINUTE: "MINUTE";
            HOUR: "HOUR";
            BYTE: "BYTE";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodEnum<{
            KNOWN: "KNOWN";
            ESTIMATED: "ESTIMATED";
        }>;
        value: z.ZodString;
        metric: z.ZodEnum<{
            RECORD_COUNT: "RECORD_COUNT";
            ROW_COUNT: "ROW_COUNT";
            COLUMN_COUNT: "COLUMN_COUNT";
            AUDIO_DURATION: "AUDIO_DURATION";
            IMAGE_COUNT: "IMAGE_COUNT";
            VIDEO_DURATION: "VIDEO_DURATION";
            DOCUMENT_COUNT: "DOCUMENT_COUNT";
            SESSION_COUNT: "SESSION_COUNT";
            PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
            STREAM_COUNT: "STREAM_COUNT";
            BYTE_SIZE: "BYTE_SIZE";
        }>;
        unit: z.ZodEnum<{
            COUNT: "COUNT";
            SECOND: "SECOND";
            MINUTE: "MINUTE";
            HOUR: "HOUR";
            BYTE: "BYTE";
        }>;
    }, z.core.$strict>], "state">>>;
    fullMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
        metric: z.ZodEnum<{
            RECORD_COUNT: "RECORD_COUNT";
            ROW_COUNT: "ROW_COUNT";
            COLUMN_COUNT: "COLUMN_COUNT";
            AUDIO_DURATION: "AUDIO_DURATION";
            IMAGE_COUNT: "IMAGE_COUNT";
            VIDEO_DURATION: "VIDEO_DURATION";
            DOCUMENT_COUNT: "DOCUMENT_COUNT";
            SESSION_COUNT: "SESSION_COUNT";
            PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
            STREAM_COUNT: "STREAM_COUNT";
            BYTE_SIZE: "BYTE_SIZE";
        }>;
        unit: z.ZodEnum<{
            COUNT: "COUNT";
            SECOND: "SECOND";
            MINUTE: "MINUTE";
            HOUR: "HOUR";
            BYTE: "BYTE";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodEnum<{
            KNOWN: "KNOWN";
            ESTIMATED: "ESTIMATED";
        }>;
        value: z.ZodString;
        metric: z.ZodEnum<{
            RECORD_COUNT: "RECORD_COUNT";
            ROW_COUNT: "ROW_COUNT";
            COLUMN_COUNT: "COLUMN_COUNT";
            AUDIO_DURATION: "AUDIO_DURATION";
            IMAGE_COUNT: "IMAGE_COUNT";
            VIDEO_DURATION: "VIDEO_DURATION";
            DOCUMENT_COUNT: "DOCUMENT_COUNT";
            SESSION_COUNT: "SESSION_COUNT";
            PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
            STREAM_COUNT: "STREAM_COUNT";
            BYTE_SIZE: "BYTE_SIZE";
        }>;
        unit: z.ZodEnum<{
            COUNT: "COUNT";
            SECOND: "SECOND";
            MINUTE: "MINUTE";
            HOUR: "HOUR";
            BYTE: "BYTE";
        }>;
    }, z.core.$strict>], "state">>>;
    sampleMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        state: z.ZodLiteral<"UNKNOWN">;
        metric: z.ZodEnum<{
            RECORD_COUNT: "RECORD_COUNT";
            ROW_COUNT: "ROW_COUNT";
            COLUMN_COUNT: "COLUMN_COUNT";
            AUDIO_DURATION: "AUDIO_DURATION";
            IMAGE_COUNT: "IMAGE_COUNT";
            VIDEO_DURATION: "VIDEO_DURATION";
            DOCUMENT_COUNT: "DOCUMENT_COUNT";
            SESSION_COUNT: "SESSION_COUNT";
            PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
            STREAM_COUNT: "STREAM_COUNT";
            BYTE_SIZE: "BYTE_SIZE";
        }>;
        unit: z.ZodEnum<{
            COUNT: "COUNT";
            SECOND: "SECOND";
            MINUTE: "MINUTE";
            HOUR: "HOUR";
            BYTE: "BYTE";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        state: z.ZodEnum<{
            KNOWN: "KNOWN";
            ESTIMATED: "ESTIMATED";
        }>;
        value: z.ZodString;
        metric: z.ZodEnum<{
            RECORD_COUNT: "RECORD_COUNT";
            ROW_COUNT: "ROW_COUNT";
            COLUMN_COUNT: "COLUMN_COUNT";
            AUDIO_DURATION: "AUDIO_DURATION";
            IMAGE_COUNT: "IMAGE_COUNT";
            VIDEO_DURATION: "VIDEO_DURATION";
            DOCUMENT_COUNT: "DOCUMENT_COUNT";
            SESSION_COUNT: "SESSION_COUNT";
            PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
            STREAM_COUNT: "STREAM_COUNT";
            BYTE_SIZE: "BYTE_SIZE";
        }>;
        unit: z.ZodEnum<{
            COUNT: "COUNT";
            SECOND: "SECOND";
            MINUTE: "MINUTE";
            HOUR: "HOUR";
            BYTE: "BYTE";
        }>;
    }, z.core.$strict>], "state">>>;
    sample: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            DESCRIBED: "DESCRIBED";
            NONE_KNOWN: "NONE_KNOWN";
        }>>>;
        omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            DESCRIBED: "DESCRIBED";
            NONE_DECLARED: "NONE_DECLARED";
        }>>>;
        transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>>;
    fullCompleteness: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    profiles: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        tabular: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
        }, z.core.$strict>>>;
        audio: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                SPEECH: "SPEECH";
                NON_SPEECH: "NON_SPEECH";
                MIXED: "MIXED";
            }>>>;
            languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
            recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
            transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        images: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        video: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        text: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
            annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
            annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        sensors: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                NO_CLAIM: "NO_CLAIM";
                DESCRIBED: "DESCRIBED";
            }>>>;
            synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
            }>>>;
            calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        egocentric: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        healthcare: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export declare const DatasetContentCommonSnapshotSchema: z.ZodObject<{
    title: z.ZodString;
    overview: z.ZodString;
    description: z.ZodString;
    dataQuality: z.ZodString;
    license: z.ZodString;
    primaryCategoryId: z.ZodString;
    sourceId: z.ZodString;
    superType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        CROSS_SECTIONAL: "CROSS_SECTIONAL";
        TIME_SERIES: "TIME_SERIES";
        PANEL: "PANEL";
        POOLED_CROSS_SECTIONAL: "POOLED_CROSS_SECTIONAL";
        REPEATED_CROSS_SECTIONS: "REPEATED_CROSS_SECTIONS";
        SPATIAL: "SPATIAL";
        SPATIO_TEMPORAL: "SPATIO_TEMPORAL";
        EXPERIMENTAL: "EXPERIMENTAL";
        OBSERVATIONAL: "OBSERVATIONAL";
        BIG_DATA: "BIG_DATA";
        EVENT_HISTORY_SURVIVAL: "EVENT_HISTORY_SURVIVAL";
        HIERARCHICAL_MULTILEVEL: "HIERARCHICAL_MULTILEVEL";
    }>>>;
    useCases: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    limitations: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    methodology: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    secondaryCategoryIds: z.ZodArray<z.ZodString>;
    tags: z.ZodArray<z.ZodString>;
    categories: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
    }, z.core.$strict>>;
    source: z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        description: z.ZodNullable<z.ZodString>;
        websiteUrl: z.ZodNullable<z.ZodString>;
        isVerifiedAtFreeze: z.ZodBoolean;
    }, z.core.$strict>;
}, z.core.$strict>;
export type DatasetMaterialComponent = z.infer<typeof DatasetMaterialComponentSchema>;
export type DatasetMaterialOperation = z.infer<typeof DatasetMaterialOperationSchema>;
export type DatasetMaterialMutationBody = z.infer<typeof DatasetMaterialMutationBodySchema>;
export type DatasetFrozenMaterialReference = z.infer<typeof DatasetFrozenMaterialReferenceSchema>;
export type DatasetContentMetadata = z.infer<typeof DatasetContentMetadataSchema>;
export type DatasetContentCommonSnapshot = z.infer<typeof DatasetContentCommonSnapshotSchema>;
export type DatasetMaterialMutationResponse = z.infer<typeof DatasetMaterialMutationResponseSchema>;
//# sourceMappingURL=content.schema.d.ts.map