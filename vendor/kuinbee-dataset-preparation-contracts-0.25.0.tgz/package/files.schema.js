"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetFrozenInventoryResponseSchema = exports.DatasetFrozenInventoryQuerySchema = exports.DatasetFilesOrganizationPageResponseSchema = exports.DatasetFilesOrganizationQuerySchema = exports.DatasetFilesInventoryPageResponseSchema = exports.DatasetFilesInventoryMemberSchema = exports.DatasetFilesInventoryPageQuerySchema = exports.DatasetFilesContextResponseSchema = exports.DatasetFilesUsageSchema = exports.DatasetFilesContextBodySchema = exports.DatasetFilesMutationBodySchema = exports.DATASET_FILES_PAGE_MAX = exports.DATASET_FILES_CONTRACT_VERSION = void 0;
const zod_1 = require("zod");
const preparation_schema_1 = require("./preparation.schema");
const content_schema_1 = require("./content.schema");
const content_schema_2 = require("./content.schema");
const edit_schema_1 = require("./edit.schema");
// Files context is not a supplier-controlled inspection/admission contract.
// Intake remains closed until its independently qualified adapter is enabled.
exports.DATASET_FILES_CONTRACT_VERSION = 1;
exports.DATASET_FILES_PAGE_MAX = 50;
const id = zod_1.z.string().cuid();
const generation = zod_1.z.number().int().min(0).max(2_147_483_647);
const requestId = zod_1.z.string().uuid().transform(value => value.toLowerCase());
exports.DatasetFilesMutationBodySchema = content_schema_2.DatasetMaterialMutationBodySchema.extend({ expectedPreparationGeneration: generation })
    .refine(body => !body.editContext || body.editContext.mode === "EXISTING_DRAFT", "Refresh the Files context before changing selected files");
const canonicalBytes = /^(0|[1-9][0-9]{0,19})$/;
const bytes = zod_1.z.string().regex(canonicalBytes);
exports.DatasetFilesContextBodySchema = zod_1.z.object({
    requestId,
    expectedPreparationGeneration: generation,
    expectedContentId: id.nullable(),
    expectedContentGeneration: generation.nullable(),
    editContext: edit_schema_1.DatasetCorrectionPreconditionSchema.optional(),
}).strict().refine(body => (body.expectedContentId === null) === (body.expectedContentGeneration === null), "Initialization uses a null content identity and generation together");
const account = (limit) => zod_1.z.object({
    limitBytes: zod_1.z.literal(limit),
    retainedBytes: bytes.nullable(),
    reservedBytes: bytes.nullable(),
    chargedBytes: bytes.nullable(),
    remainingBytes: bytes.nullable(),
}).strict();
exports.DatasetFilesUsageSchema = zod_1.z.object({
    state: zod_1.z.enum(["UNAVAILABLE", "RECONCILING", "ACCOUNTED"]),
    dataset: account("5000000000"),
    supplier: account("100000000000"),
}).strict().refine(usage => [usage.dataset, usage.supplier].every(value => {
    const amounts = [value.retainedBytes, value.reservedBytes, value.chargedBytes, value.remainingBytes];
    if (usage.state !== "ACCOUNTED")
        return amounts.every(amount => amount === null);
    if (amounts.some(amount => typeof amount !== "string" || !canonicalBytes.test(amount)))
        return false;
    const charged = BigInt(value.retainedBytes) + BigInt(value.reservedBytes);
    const limit = BigInt(value.limitBytes);
    return charged === BigInt(value.chargedBytes) && BigInt(value.remainingBytes) === (charged < limit ? limit - charged : 0n);
}), "Unknown accounting stays unknown; accounted totals include retained bytes and outstanding reservations");
exports.DatasetFilesContextResponseSchema = zod_1.z.object({
    contractVersion: zod_1.z.literal(exports.DATASET_FILES_CONTRACT_VERSION),
    requestId: requestId.optional(),
    preparationId: id,
    preparationGeneration: generation,
    contentId: id.nullable(),
    contentGeneration: generation.nullable(),
    sourcePreparationGeneration: generation.nullable(),
    serverUploadChoice: preparation_schema_1.DatasetUploadChoiceSchema.nullable(),
    editable: zod_1.z.boolean(),
    synchronizationRequired: zod_1.z.boolean(),
    usage: exports.DatasetFilesUsageSchema,
    admission: zod_1.z.object({ enabled: zod_1.z.literal(false), reason: zod_1.z.literal("INTAKE_NOT_ENABLED") }).strict(),
}).strict().refine(context => {
    if (context.contentId === null)
        return context.contentGeneration === null && context.sourcePreparationGeneration === null && !context.synchronizationRequired;
    return context.contentGeneration !== null && context.sourcePreparationGeneration !== null && context.sourcePreparationGeneration <= context.preparationGeneration &&
        context.synchronizationRequired === (context.sourcePreparationGeneration !== context.preparationGeneration);
}, "Content identity and preparation synchronization must describe one exact context");
const queryGeneration = zod_1.z.union([generation, zod_1.z.string().regex(/^(0|[1-9][0-9]{0,9})$/).transform(Number).pipe(generation)]);
exports.DatasetFilesInventoryPageQuerySchema = zod_1.z.object({
    expectedPreparationGeneration: queryGeneration,
    contentId: id,
    contentGeneration: queryGeneration,
    component: content_schema_1.DatasetMaterialComponentSchema.optional(),
    afterId: id.optional(),
    limit: zod_1.z.coerce.number().int().min(1).max(exports.DATASET_FILES_PAGE_MAX).default(20),
}).strict();
exports.DatasetFilesInventoryMemberSchema = zod_1.z.object({
    id,
    contentId: id,
    uploadObjectId: id,
    component: content_schema_1.DatasetMaterialComponentSchema,
    role: content_schema_1.DatasetMaterialRoleSchema,
    relativePath: content_schema_1.DatasetSafeRelativePathSchema.nullable(),
    groupId: id.nullable(),
    // Old exact objects have no stored original name. Never infer it from a key.
    originalFileName: zod_1.z.string().min(1).max(1_024).nullable(),
    measuredSizeBytes: bytes,
    inspection: zod_1.z.object({
        securityState: zod_1.z.enum(["QUARANTINED", "PROCESSING", "ACCEPTED", "BLOCKED", "FAILED", "CANCELLED", "UNRECONCILED", "UNKNOWN"]),
        currentEvidenceId: id.nullable(),
        recordedOutcome: zod_1.z.enum(["NONE", "PASS", "FAIL", "UNKNOWN"]),
        current: zod_1.z.boolean(),
        // A recorded pass is not a qualified admission/access decision.
        eligibility: zod_1.z.literal("NOT_EVALUATED"),
    }).strict().refine(value => value.currentEvidenceId !== null || (!value.current && value.recordedOutcome === "NONE"), "An absent evidence pointer cannot have a current recorded result"),
}).strict();
exports.DatasetFilesInventoryPageResponseSchema = zod_1.z.object({
    preparationId: id,
    preparationGeneration: generation,
    contentId: id,
    contentGeneration: generation,
    sourcePreparationGeneration: generation,
    items: zod_1.z.array(exports.DatasetFilesInventoryMemberSchema).max(exports.DATASET_FILES_PAGE_MAX),
    nextCursor: zod_1.z.object({ contentId: id, contentGeneration: generation, afterId: id }).strict().nullable(),
}).strict().refine(page => page.sourcePreparationGeneration === page.preparationGeneration &&
    page.items.every(member => member.contentId === page.contentId) &&
    new Set(page.items.map(member => member.id)).size === page.items.length &&
    (!page.nextCursor || (page.nextCursor.contentId === page.contentId && page.nextCursor.contentGeneration === page.contentGeneration &&
        page.items.length > 0 && page.nextCursor.afterId === page.items[page.items.length - 1].id)), "Inventory members and cursor must belong to one synchronized content generation");
// Organization is paginated separately from physical members. Reading page two
// never creates a replacement manifest or loses relationships outside that page.
const organizationSection = zod_1.z.enum(["MEMBERS", "GROUPS", "RELATIONSHIPS", "INVENTORIES", "ENTRIES"]);
const organizationQuery = zod_1.z.object({
    expectedPreparationGeneration: queryGeneration, contentId: id, contentGeneration: queryGeneration,
    section: organizationSection, component: content_schema_1.DatasetMaterialComponentSchema.optional(),
    memberId: id.optional(), inventoryId: id.optional(), afterId: id.optional(),
    limit: zod_1.z.coerce.number().int().min(1).max(exports.DATASET_FILES_PAGE_MAX).default(20),
}).strict();
exports.DatasetFilesOrganizationQuerySchema = organizationQuery.superRefine((query, ctx) => {
    const needsMember = ["INVENTORIES", "ENTRIES"].includes(query.section);
    if (needsMember && !query.memberId || query.section === "GROUPS" && query.memberId !== undefined) {
        ctx.addIssue({ code: "custom", path: ["memberId"], message: "Choose an exact selected member for container inventory" });
    }
    if (query.section === "ENTRIES" ? !query.inventoryId : query.inventoryId !== undefined) {
        ctx.addIssue({ code: "custom", path: ["inventoryId"], message: "Entries require an explicit sealed inventory; no latest-inventory fallback" });
    }
    if (query.section === "MEMBERS" && query.memberId && query.afterId) {
        ctx.addIssue({ code: "custom", path: ["afterId"], message: "An exact selected-file lookup has no page cursor" });
    }
});
const organizationTarget = zod_1.z.object({ memberId: id, logicalEntryId: id.nullable(),
    displayName: zod_1.z.string().min(1).max(1_024).nullable().optional(),
    logicalEntry: zod_1.z.object({ id, inventoryId: id, locator: content_schema_1.DatasetLogicalLocatorSchema }).strict().nullable().optional(),
}).strict().refine(target => !target.logicalEntry || target.logicalEntry.id === target.logicalEntryId, "The displayed logical path must belong to the exact relationship entry");
const organizationItem = zod_1.z.discriminatedUnion("kind", [
    zod_1.z.object({ kind: zod_1.z.literal("MEMBER"), id, uploadObjectId: id, component: content_schema_1.DatasetMaterialComponentSchema,
        role: content_schema_1.DatasetMaterialRoleSchema, originalFileName: zod_1.z.string().min(1).max(1_024).nullable(),
        relativePath: content_schema_1.DatasetSafeRelativePathSchema.nullable(),
        group: zod_1.z.object({ id, label: zod_1.z.string().min(1).max(200) }).strict().nullable() }).strict(),
    zod_1.z.object({ kind: zod_1.z.literal("GROUP"), id, component: content_schema_1.DatasetMaterialComponentSchema, label: zod_1.z.string().min(1).max(200) }).strict(),
    zod_1.z.object({ kind: zod_1.z.literal("RELATIONSHIP"), id, component: content_schema_1.DatasetMaterialComponentSchema,
        relationship: content_schema_1.DatasetMaterialRelationshipKindSchema, required: zod_1.z.boolean(),
        source: organizationTarget, target: organizationTarget }).strict(),
    zod_1.z.object({ kind: zod_1.z.literal("INVENTORY"), id, uploadObjectId: id,
        structuralDigest: zod_1.z.string().regex(/^[a-f0-9]{64}$/), sealedAt: zod_1.z.iso.datetime() }).strict(),
    zod_1.z.object({ kind: zod_1.z.literal("ENTRY"), id, inventoryId: id, uploadObjectId: id,
        locator: content_schema_1.DatasetLogicalLocatorSchema }).strict(),
]);
exports.DatasetFilesOrganizationPageResponseSchema = zod_1.z.object({
    preparationId: id, preparationGeneration: generation, contentId: id, contentGeneration: generation,
    section: organizationSection, component: content_schema_1.DatasetMaterialComponentSchema.nullable(),
    memberId: id.nullable(), inventoryId: id.nullable(), uploadObjectId: id.nullable(),
    items: zod_1.z.array(organizationItem).max(exports.DATASET_FILES_PAGE_MAX),
    nextCursor: organizationQuery.extend({ afterId: id }).nullable(),
}).strict().superRefine((page, ctx) => {
    const kind = { MEMBERS: "MEMBER", GROUPS: "GROUP", RELATIONSHIPS: "RELATIONSHIP", INVENTORIES: "INVENTORY", ENTRIES: "ENTRY" }[page.section];
    if (!exports.DatasetFilesOrganizationQuerySchema.safeParse({ expectedPreparationGeneration: page.preparationGeneration,
        contentId: page.contentId, contentGeneration: page.contentGeneration, section: page.section,
        ...(page.component ? { component: page.component } : {}), ...(page.memberId ? { memberId: page.memberId } : {}),
        ...(page.inventoryId ? { inventoryId: page.inventoryId } : {}) }).success ||
        (["INVENTORIES", "ENTRIES"].includes(page.section) ? page.uploadObjectId === null : page.uploadObjectId !== null)) {
        ctx.addIssue({ code: "custom", path: ["memberId"], message: "Organization scope must identify its exact selected member and sealed inventory" });
    }
    if (page.items.some(item => item.kind !== kind || ("component" in item && page.component !== null && item.component !== page.component)) ||
        page.items.some(item => (item.kind === "INVENTORY" || item.kind === "ENTRY") && item.uploadObjectId !== page.uploadObjectId ||
            item.kind === "MEMBER" && page.memberId !== null && item.id !== page.memberId ||
            item.kind === "ENTRY" && item.inventoryId !== page.inventoryId || item.kind === "RELATIONSHIP" && page.memberId !== null &&
            item.source.memberId !== page.memberId && item.target.memberId !== page.memberId) ||
        new Set(page.items.map(item => item.id)).size !== page.items.length) {
        ctx.addIssue({ code: "custom", path: ["items"], message: "Organization rows must match this exact filtered page" });
    }
    const cursor = page.nextCursor;
    if (cursor && (cursor.contentId !== page.contentId || cursor.contentGeneration !== page.contentGeneration ||
        cursor.expectedPreparationGeneration !== page.preparationGeneration || cursor.section !== page.section ||
        (cursor.component ?? null) !== page.component || (cursor.memberId ?? null) !== page.memberId ||
        (cursor.inventoryId ?? null) !== page.inventoryId || !page.items.length || cursor.afterId !== page.items.at(-1).id)) {
        ctx.addIssue({ code: "custom", path: ["nextCursor"], message: "Cursor belongs to this exact context, filter and final row" });
    }
}).refine(page => new TextEncoder().encode(JSON.stringify(page)).byteLength <= 1_048_576, "Organization metadata must fit the bounded response budget");
// Read-only current submission inventory. Every cursor retains the exact frozen
// content and workflow context; it is never a replacement manifest.
exports.DatasetFrozenInventoryQuerySchema = zod_1.z.object({
    expectedWorkflowRevision: queryGeneration, contentId: id, contentGeneration: queryGeneration,
    inventory: zod_1.z.enum(["FILES", "GROUPS", "RELATIONSHIPS"]).default("FILES"),
    component: content_schema_1.DatasetMaterialComponentSchema.optional(), afterId: id.optional(),
    limit: zod_1.z.union([zod_1.z.number().int().min(1).max(exports.DATASET_FILES_PAGE_MAX),
        zod_1.z.string().regex(/^[1-9][0-9]*$/).transform(Number).pipe(zod_1.z.number().int().min(1).max(exports.DATASET_FILES_PAGE_MAX))]).default(20),
}).strict();
const frozenContext = { datasetId: id, workflowRevision: generation, contentId: id, contentGeneration: generation,
    frozenAt: zod_1.z.string().datetime(), total: zod_1.z.number().int().nonnegative().max(2_000), component: content_schema_1.DatasetMaterialComponentSchema.nullable(),
    nextCursor: zod_1.z.object({ expectedWorkflowRevision: generation, contentId: id, contentGeneration: generation, afterId: id,
        inventory: zod_1.z.enum(["FILES", "GROUPS", "RELATIONSHIPS"]), component: content_schema_1.DatasetMaterialComponentSchema.optional() }).strict().nullable() };
const logical = zod_1.z.object({ id, inventoryId: id, locator: content_schema_1.DatasetLogicalLocatorSchema }).strict().nullable();
const target = zod_1.z.object({ memberId: id, uploadObjectId: id, logicalEntry: logical }).strict();
exports.DatasetFrozenInventoryResponseSchema = zod_1.z.discriminatedUnion("inventory", [
    zod_1.z.object({ ...frozenContext, inventory: zod_1.z.literal("FILES"), items: zod_1.z.array(exports.DatasetFilesInventoryMemberSchema.extend({
            inspectionAtSubmissionId: id,
        })).max(exports.DATASET_FILES_PAGE_MAX) }).strict(),
    zod_1.z.object({ ...frozenContext, inventory: zod_1.z.literal("GROUPS"), items: zod_1.z.array(zod_1.z.object({ id, contentId: id,
            component: content_schema_1.DatasetMaterialComponentSchema, label: zod_1.z.string().min(1).max(200) }).strict()).max(exports.DATASET_FILES_PAGE_MAX) }).strict(),
    zod_1.z.object({ ...frozenContext, inventory: zod_1.z.literal("RELATIONSHIPS"), items: zod_1.z.array(zod_1.z.object({ id, contentId: id,
            component: content_schema_1.DatasetMaterialComponentSchema, kind: content_schema_1.DatasetMaterialRelationshipKindSchema, required: zod_1.z.boolean(),
            source: target, target,
        }).strict()).max(exports.DATASET_FILES_PAGE_MAX) }).strict(),
]).refine(page => page.items.every(item => item.contentId === page.contentId && (!page.component || item.component === page.component)) &&
    new Set(page.items.map(item => item.id)).size === page.items.length && (!page.nextCursor ||
    (page.nextCursor.contentId === page.contentId && page.nextCursor.contentGeneration === page.contentGeneration &&
        page.nextCursor.expectedWorkflowRevision === page.workflowRevision && page.nextCursor.inventory === page.inventory &&
        (page.nextCursor.component ?? null) === page.component && page.items.at(-1)?.id === page.nextCursor.afterId)), "Frozen inventory items and cursor belong to one exact submission context");
