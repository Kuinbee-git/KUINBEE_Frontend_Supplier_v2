"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetInspectionProfileSchema = exports.DatasetInspectionLeafProfileSchema = void 0;
const zod_1 = require("zod");
const content_schema_1 = require("./content.schema");
// Supplier intent describes which qualified backend checks to request. These
// declarations never supply a result, release policy, or scanner authority.
exports.DatasetInspectionLeafProfileSchema = zod_1.z.discriminatedUnion("profileId", [
    zod_1.z.object({ profileId: zod_1.z.enum(["UTF8_CSV_SYNTAX_V1", "UTF8_TSV_SYNTAX_V1"]), header: zod_1.z.enum(["PRESENT", "ABSENT"]) }).strict(),
    zod_1.z.object({ profileId: zod_1.z.literal("UTF8_JSONL_SYNTAX_V1"), recordKind: zod_1.z.enum(["OBJECT", "OBJECT_OR_ARRAY"]) }).strict(),
    zod_1.z.object({ profileId: zod_1.z.literal("RIFF_INTEGER_PCM_WAVE_V1") }).strict(),
    zod_1.z.object({ profileId: zod_1.z.literal("PNG_STATIC_8BIT_V1") }).strict(),
    zod_1.z.object({ profileId: zod_1.z.literal("JPEG_BASELINE_STRUCTURE_V1") }).strict(),
]);
const entryDefaults = zod_1.z.array(zod_1.z.object({ extension: zod_1.z.string().regex(/^\.[a-z0-9]{1,15}$/),
    profile: exports.DatasetInspectionLeafProfileSchema }).strict()).max(8)
    .refine(rules => new Set(rules.map(rule => rule.extension)).size === rules.length, "Archive extension declarations must be unique");
exports.DatasetInspectionProfileSchema = zod_1.z.union([
    exports.DatasetInspectionLeafProfileSchema,
    zod_1.z.object({ profileId: zod_1.z.literal("ZIP32_CONTAINER_V1"), leafProfiles: zod_1.z.array(zod_1.z.object({
            locator: content_schema_1.DatasetLogicalLocatorSchema.refine(value => value.kind === "ARCHIVE_ENTRY", "ZIP entries require archive locators"),
            profile: exports.DatasetInspectionLeafProfileSchema,
        }).strict()).max(1_024), entryDefaults: entryDefaults.optional() }).strict().refine(value => new Set(value.leafProfiles.map(entry => JSON.stringify(entry.locator))).size === value.leafProfiles.length, "Entry profiles must be unique"),
]);
