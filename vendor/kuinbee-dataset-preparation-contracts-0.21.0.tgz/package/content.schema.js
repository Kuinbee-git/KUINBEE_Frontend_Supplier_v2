"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetContentCommonSnapshotSchema = exports.DatasetContentMetadataSchema = exports.DatasetContentIdentityResponseSchema = exports.DatasetMaterialMutationResponseSchema = exports.DatasetMaterialPageResponseSchema = exports.DatasetMaterialMemberResponseSchema = exports.DatasetLogicalEntryResponseSchema = exports.DatasetMemberDownloadRequestSchema = exports.DatasetFrozenMaterialReferenceSchema = exports.DatasetEditContextResponseSchema = exports.DatasetEditContextQuerySchema = exports.DatasetEditOperationSchema = exports.DatasetCorrectionPreconditionSchema = exports.DatasetCorrectionContextSchema = exports.DatasetMaterialPageQuerySchema = exports.DatasetMaterialCursorSchema = exports.DatasetMaterialMutationBodySchema = exports.DatasetMaterialOperationSchema = exports.DatasetMaterialTargetSchema = exports.DatasetLogicalLocatorSchema = exports.DatasetSafeRelativePathSchema = exports.DatasetMaterialRelationshipKindSchema = exports.DatasetMaterialRoleSchema = exports.DatasetMaterialComponentSchema = exports.DATASET_CONTENT_LIMITS = exports.DATASET_CONTENT_CONTRACT_VERSION = void 0;
exports.datasetLogicalLocatorKey = datasetLogicalLocatorKey;
const zod_1 = require("zod");
const preparation_schema_1 = require("./preparation.schema");
const edit_schema_1 = require("./edit.schema");
// Material identity and correction contracts. These schemas do not enable an
// advertised format, accept bytes, grant access, or replace existing workflow.
exports.DATASET_CONTENT_CONTRACT_VERSION = 1;
exports.DATASET_CONTENT_LIMITS = { operationsPerMutation: 50, pageSize: 50, snapshotBytes: 131_072 };
const id = zod_1.z.string().min(1).max(128);
const generatedId = zod_1.z.string().cuid();
const digest = zod_1.z.string().regex(/^[a-f0-9]{64}$/);
const generation = zod_1.z.number().int().min(0).max(2_147_483_647);
const requestId = zod_1.z.string().uuid().transform(value => value.toLowerCase());
exports.DatasetMaterialComponentSchema = zod_1.z.enum(["FULL", "SAMPLE"]);
exports.DatasetMaterialRoleSchema = zod_1.z.enum(["PRIMARY", "TRANSCRIPT", "ANNOTATION", "SENSOR", "CALIBRATION", "DOCUMENTATION"]);
exports.DatasetMaterialRelationshipKindSchema = zod_1.z.enum(["TRANSCRIPT_FOR", "ANNOTATION_FOR", "CALIBRATION_FOR", "SYNCHRONIZED_WITH", "DOCUMENTATION_FOR"]);
// Paths are internal inventory labels, never object-store keys or entitlement.
// Reject ambiguity rather than silently repairing traversal/separator/Unicode.
const hasControlCharacter = (value) => Array.from(value).some(character => {
    const code = character.codePointAt(0);
    return code < 32 || code === 127;
});
exports.DatasetSafeRelativePathSchema = zod_1.z.string().min(1).max(1_024).refine(value => {
    if (value !== value.normalize("NFC") || hasControlCharacter(value) || value.includes("\\") || value.includes(":") || value.startsWith("/"))
        return false;
    return value.split("/").every(part => part.length > 0 && part !== "." && part !== ".." && part === part.trim());
}, "Use an unambiguous NFC relative path without traversal or platform separators");
exports.DatasetLogicalLocatorSchema = zod_1.z.discriminatedUnion("kind", [
    zod_1.z.object({ kind: zod_1.z.literal("ARCHIVE_ENTRY"), path: exports.DatasetSafeRelativePathSchema }).strict(),
    zod_1.z.object({ kind: zod_1.z.literal("WORKBOOK_SHEET"), sheetName: zod_1.z.string().min(1).max(255).refine(value => value === value.normalize("NFC") && !hasControlCharacter(value), "Use an unambiguous NFC sheet name") }).strict(),
]);
function datasetLogicalLocatorKey(locator) {
    const parsed = exports.DatasetLogicalLocatorSchema.parse(locator);
    return parsed.kind === "ARCHIVE_ENTRY" ? `ARCHIVE_ENTRY:${parsed.path}` : `WORKBOOK_SHEET:${parsed.sheetName}`;
}
// A reference to a logical entry always retains its physical membership. A ZIP
// entry is metadata inside that object; it cannot request a separate download.
exports.DatasetMaterialTargetSchema = zod_1.z.object({ memberId: generatedId, logicalEntryId: generatedId.nullable() }).strict();
const label = zod_1.z.string().trim().min(1).max(200);
const addMember = zod_1.z.object({ operation: zod_1.z.literal("ADD_MEMBER"), uploadObjectId: generatedId,
    component: exports.DatasetMaterialComponentSchema, role: exports.DatasetMaterialRoleSchema,
    relativePath: exports.DatasetSafeRelativePathSchema.nullable().optional(), groupId: generatedId.nullable().optional() }).strict();
exports.DatasetMaterialOperationSchema = zod_1.z.discriminatedUnion("operation", [
    addMember,
    zod_1.z.object({ operation: zod_1.z.literal("REMOVE_MEMBER"), memberId: generatedId }).strict(),
    zod_1.z.object({ operation: zod_1.z.literal("SET_MEMBER_ROLE"), memberId: generatedId, role: exports.DatasetMaterialRoleSchema }).strict(),
    zod_1.z.object({ operation: zod_1.z.literal("SET_MEMBER_GROUP"), memberId: generatedId, groupId: generatedId.nullable() }).strict(),
    zod_1.z.object({ operation: zod_1.z.literal("ADD_GROUP"), component: exports.DatasetMaterialComponentSchema, label }).strict(),
    zod_1.z.object({ operation: zod_1.z.literal("RENAME_GROUP"), groupId: generatedId, label }).strict(),
    zod_1.z.object({ operation: zod_1.z.literal("REMOVE_GROUP"), groupId: generatedId }).strict(),
    zod_1.z.object({ operation: zod_1.z.literal("ADD_LINK"), component: exports.DatasetMaterialComponentSchema,
        kind: exports.DatasetMaterialRelationshipKindSchema, source: exports.DatasetMaterialTargetSchema, target: exports.DatasetMaterialTargetSchema,
        required: zod_1.z.boolean() }).strict(),
    zod_1.z.object({ operation: zod_1.z.literal("REMOVE_LINK"), linkId: generatedId }).strict(),
]);
exports.DatasetMaterialMutationBodySchema = zod_1.z.object({ requestId, expectedContentId: generatedId,
    expectedGeneration: generation, expectedPreparationGeneration: generation.optional(),
    editContext: edit_schema_1.DatasetCorrectionPreconditionSchema.optional(),
    operations: zod_1.z.array(exports.DatasetMaterialOperationSchema).min(1).max(exports.DATASET_CONTENT_LIMITS.operationsPerMutation) }).strict();
exports.DatasetMaterialCursorSchema = zod_1.z.object({ contentId: generatedId, generation, afterId: generatedId }).strict();
exports.DatasetMaterialPageQuerySchema = zod_1.z.object({ contentId: generatedId, generation,
    component: exports.DatasetMaterialComponentSchema.optional(), afterId: generatedId.optional(),
    limit: zod_1.z.coerce.number().int().min(1).max(exports.DATASET_CONTENT_LIMITS.pageSize).default(20) }).strict();
// Shared independently of preparation/content to avoid a schema import cycle.
var edit_schema_2 = require("./edit.schema");
Object.defineProperty(exports, "DatasetCorrectionContextSchema", { enumerable: true, get: function () { return edit_schema_2.DatasetCorrectionContextSchema; } });
Object.defineProperty(exports, "DatasetCorrectionPreconditionSchema", { enumerable: true, get: function () { return edit_schema_2.DatasetCorrectionPreconditionSchema; } });
Object.defineProperty(exports, "DatasetEditOperationSchema", { enumerable: true, get: function () { return edit_schema_2.DatasetEditOperationSchema; } });
Object.defineProperty(exports, "DatasetEditContextQuerySchema", { enumerable: true, get: function () { return edit_schema_2.DatasetEditContextQuerySchema; } });
Object.defineProperty(exports, "DatasetEditContextResponseSchema", { enumerable: true, get: function () { return edit_schema_2.DatasetEditContextResponseSchema; } });
exports.DatasetFrozenMaterialReferenceSchema = zod_1.z.object({ datasetId: id, contentId: generatedId,
    component: exports.DatasetMaterialComponentSchema }).strict();
exports.DatasetMemberDownloadRequestSchema = zod_1.z.object({ expectedMaterial: exports.DatasetFrozenMaterialReferenceSchema,
    memberId: generatedId, downloadIntentId: requestId }).strict();
exports.DatasetLogicalEntryResponseSchema = zod_1.z.object({ id: generatedId, inventoryId: generatedId,
    uploadObjectId: generatedId, locator: exports.DatasetLogicalLocatorSchema }).strict();
exports.DatasetMaterialMemberResponseSchema = zod_1.z.object({ id: generatedId, contentId: generatedId,
    uploadObjectId: generatedId, component: exports.DatasetMaterialComponentSchema, role: exports.DatasetMaterialRoleSchema,
    relativePath: exports.DatasetSafeRelativePathSchema.nullable(), groupId: generatedId.nullable() }).strict();
exports.DatasetMaterialPageResponseSchema = zod_1.z.object({ contentId: generatedId, generation,
    items: zod_1.z.array(exports.DatasetMaterialMemberResponseSchema).max(exports.DATASET_CONTENT_LIMITS.pageSize),
    nextCursor: exports.DatasetMaterialCursorSchema.nullable() }).strict().refine(page => page.items.every(item => item.contentId === page.contentId) && (!page.nextCursor ||
    (page.nextCursor.contentId === page.contentId && page.nextCursor.generation === page.generation)), "Each page and cursor must refer to the same content generation");
exports.DatasetMaterialMutationResponseSchema = zod_1.z.object({ requestId, contentId: generatedId, generation,
    results: zod_1.z.array(zod_1.z.object({ index: zod_1.z.number().int().min(0).max(49),
        operation: zod_1.z.enum(["ADD_MEMBER", "REMOVE_MEMBER", "SET_MEMBER_ROLE", "SET_MEMBER_GROUP", "ADD_GROUP", "RENAME_GROUP", "REMOVE_GROUP", "ADD_LINK", "REMOVE_LINK"]),
        id: generatedId }).strict()).min(1).max(exports.DATASET_CONTENT_LIMITS.operationsPerMutation) }).strict()
    .refine(response => response.results.every((result, index) => result.index === index), "Results must acknowledge each operation in order");
exports.DatasetContentIdentityResponseSchema = zod_1.z.object({ contractVersion: zod_1.z.literal(exports.DATASET_CONTENT_CONTRACT_VERSION),
    id: generatedId, datasetId: id, generation, uploadChoice: preparation_schema_1.DatasetUploadChoiceSchema,
    frozenAt: zod_1.z.string().datetime().nullable(), baseContentId: generatedId.nullable(), dependencyFingerprint: digest.nullable() }).strict();
exports.DatasetContentMetadataSchema = preparation_schema_1.DatasetPreparationMetadataSchema.pick({
    collectionBoundary: true, modalities: true, contexts: true, limitations: true, collectionMethod: true, possibleUses: true,
    collectionMeasurements: true, fullMeasurements: true, sampleMeasurements: true, sample: true, fullCompleteness: true, profiles: true,
});
exports.DatasetContentCommonSnapshotSchema = zod_1.z.object({
    title: zod_1.z.string().trim().min(1).max(200), overview: zod_1.z.string().trim().min(1).max(4_000),
    description: zod_1.z.string().trim().min(1).max(4_000), dataQuality: zod_1.z.string().trim().min(1).max(4_000),
    license: zod_1.z.string().trim().min(1).max(1_000), primaryCategoryId: id, sourceId: id,
    // Optional for already frozen historical snapshots; never inject a default
    // into their fingerprints. New submissions retain the entered structure.
    superType: preparation_schema_1.DatasetPreparationMetadataSchema.shape.superType,
    useCases: zod_1.z.string().max(4_000).nullable().optional(),
    limitations: zod_1.z.string().max(4_000).nullable().optional(),
    methodology: zod_1.z.string().max(4_000).nullable().optional(),
    secondaryCategoryIds: zod_1.z.array(id).max(10), tags: zod_1.z.array(zod_1.z.string().trim().min(1).max(80)).max(20),
    categories: zod_1.z.array(zod_1.z.object({ id, name: zod_1.z.string().min(1).max(1_000) }).strict()).min(1).max(11),
    source: zod_1.z.object({ id, name: zod_1.z.string().min(1).max(1_000), description: zod_1.z.string().max(4_000).nullable(),
        websiteUrl: zod_1.z.string().max(2_000).nullable(), isVerifiedAtFreeze: zod_1.z.boolean() }).strict(),
}).strict().refine(value => value.source.id === value.sourceId &&
    new Set(value.categories.map(category => category.id)).size === value.categories.length &&
    new Set(value.secondaryCategoryIds).size === value.secondaryCategoryIds.length &&
    !value.secondaryCategoryIds.includes(value.primaryCategoryId) &&
    value.categories.length === value.secondaryCategoryIds.length + 1 &&
    [value.primaryCategoryId, ...value.secondaryCategoryIds].every(categoryId => value.categories.some(category => category.id === categoryId)), "Snapshot facts must match their exact category/source identities");
