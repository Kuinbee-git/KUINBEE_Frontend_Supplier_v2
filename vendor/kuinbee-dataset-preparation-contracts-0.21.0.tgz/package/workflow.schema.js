"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetSubmissionResponseSchema = exports.DatasetReviewResponseSchema = exports.DatasetReviewFeedbackSchema = exports.DatasetReviewChangesBodySchema = exports.DatasetReviewRejectBodySchema = exports.DatasetReviewApproveBodySchema = exports.DatasetReviewPickBodySchema = exports.DatasetProposalReadinessResponseSchema = exports.DatasetProposalReadinessQuerySchema = exports.DatasetProposalSubmitBodySchema = exports.DatasetPricingSubmitBodySchema = exports.DatasetPricingSaveBodySchema = exports.DatasetWorkflowResponseSchema = exports.DatasetWorkflowStateSchema = exports.DatasetWorkflowPricingSchema = exports.DatasetPricingValuesSchema = exports.DatasetPricingReferenceSchema = exports.DatasetWorkflowPricingStatusSchema = exports.DatasetWorkflowCurrencySchema = exports.DatasetWorkflowIdParamsSchema = void 0;
const zod_1 = require("zod");
const content_schema_1 = require("./content.schema");
const edit_schema_1 = require("./edit.schema");
const id = zod_1.z.string().cuid();
const revision = zod_1.z.number().int().min(0).max(2_147_483_647);
const requestId = zod_1.z.string().uuid().transform(value => value.toLowerCase());
const notes = zod_1.z.string().trim().min(1).max(4_000);
const queryRevision = zod_1.z.union([revision, zod_1.z.string().regex(/^(0|[1-9][0-9]{0,9})$/).transform(Number).pipe(revision)]);
exports.DatasetWorkflowIdParamsSchema = zod_1.z.object({ datasetId: id }).strict();
exports.DatasetWorkflowCurrencySchema = zod_1.z.enum(["INR", "USD", "EUR", "GBP"]);
exports.DatasetWorkflowPricingStatusSchema = zod_1.z.enum([
    "DRAFT", "SUBMITTED", "CHANGES_REQUESTED", "RESUBMITTED", "UNDER_REVIEW", "ACTIVE", "REJECTED", "INACTIVE",
]);
exports.DatasetPricingReferenceSchema = zod_1.z.object({ id, revision }).strict();
const amount = zod_1.z.string().regex(/^(0|[1-9][0-9]{0,7})(\.[0-9]{1,2})?$/);
exports.DatasetPricingValuesSchema = zod_1.z.object({
    isPaid: zod_1.z.boolean(), price: amount.nullable(), currency: exports.DatasetWorkflowCurrencySchema,
}).strict().superRefine((value, context) => {
    if (value.isPaid ? value.price === null || !/[1-9]/.test(value.price) : value.price !== null) {
        context.addIssue({ code: "custom", path: ["price"], message: value.isPaid ? "Enter a positive price" : "A free Dataset has no price" });
    }
});
exports.DatasetWorkflowPricingSchema = zod_1.z.object({
    ...exports.DatasetPricingValuesSchema.shape, id, revision, status: exports.DatasetWorkflowPricingStatusSchema,
    notes: zod_1.z.string().max(4_000).nullable(), rejectionReason: zod_1.z.string().max(4_000).nullable(),
    submittedAt: zod_1.z.string().datetime().nullable(), approvedAt: zod_1.z.string().datetime().nullable(), updatedAt: zod_1.z.string().datetime(),
}).strict();
exports.DatasetWorkflowStateSchema = zod_1.z.object({
    datasetId: id, datasetUniqueId: zod_1.z.string().regex(/^D[0-9]{10,16}$/),
    datasetStatus: zod_1.z.enum(["SUBMITTED", "UNDER_REVIEW", "VERIFIED", "PUBLISHED", "REJECTED", "DELISTED", "ARCHIVED"]),
    verificationStatus: zod_1.z.enum(["PENDING", "SUBMITTED", "CHANGES_REQUESTED", "RESUBMITTED", "UNDER_REVIEW", "VERIFIED", "REJECTED"]),
    preparationGeneration: revision, workflowRevision: revision,
    activeContentId: id.nullable(), reviewedContentId: id.nullable(), publishedContentId: id.nullable(),
    pricing: exports.DatasetWorkflowPricingSchema.nullable(),
}).strict();
exports.DatasetWorkflowResponseSchema = zod_1.z.object({ requestId: requestId.optional(), state: exports.DatasetWorkflowStateSchema }).strict();
const writeContext = { requestId, expectedPreparationGeneration: revision, expectedWorkflowRevision: revision,
    expectedPricingReference: exports.DatasetPricingReferenceSchema };
exports.DatasetPricingSaveBodySchema = zod_1.z.object({ ...writeContext, changes: exports.DatasetPricingValuesSchema,
    editContext: edit_schema_1.DatasetCorrectionPreconditionSchema.optional() }).strict();
exports.DatasetPricingSubmitBodySchema = zod_1.z.object({ ...writeContext, editContext: edit_schema_1.DatasetCorrectionPreconditionSchema.optional() }).strict();
exports.DatasetProposalSubmitBodySchema = zod_1.z.object({ ...writeContext, expectedContentId: id,
    expectedContentGeneration: revision, expectedDependencyFingerprint: zod_1.z.string().regex(/^[a-f0-9]{64}$/) }).strict();
exports.DatasetProposalReadinessQuerySchema = zod_1.z.object({ expectedPreparationGeneration: queryRevision }).strict();
exports.DatasetProposalReadinessResponseSchema = zod_1.z.object({
    state: exports.DatasetWorkflowStateSchema, contentId: id.nullable(), contentGeneration: revision.nullable(),
    dependencyFingerprint: zod_1.z.string().regex(/^[a-f0-9]{64}$/).nullable(), canSubmit: zod_1.z.boolean(),
    issues: zod_1.z.array(zod_1.z.object({ code: zod_1.z.string().min(1).max(100), field: zod_1.z.string().max(200).optional(),
        message: zod_1.z.string().min(1).max(1_000) }).strict()).max(100),
}).strict();
const reviewContext = { requestId, expectedWorkflowRevision: revision, expectedReviewedContentId: id,
    expectedPricingReference: exports.DatasetPricingReferenceSchema };
exports.DatasetReviewPickBodySchema = zod_1.z.object(reviewContext).strict();
exports.DatasetReviewApproveBodySchema = zod_1.z.object({ ...reviewContext, notes: notes.optional() }).strict();
exports.DatasetReviewRejectBodySchema = zod_1.z.object({ ...reviewContext, rejectionReason: notes, notes: notes.optional() }).strict();
exports.DatasetReviewChangesBodySchema = zod_1.z.object({ ...reviewContext, notes, changeRationale: notes.optional() }).strict();
exports.DatasetReviewFeedbackSchema = zod_1.z.object({
    notes: zod_1.z.string().max(4_000).nullable(), rejectionReason: zod_1.z.string().max(4_000).nullable(),
    submittedAt: zod_1.z.string().datetime().nullable(), verifiedAt: zod_1.z.string().datetime().nullable(), rejectedAt: zod_1.z.string().datetime().nullable(),
}).strict();
exports.DatasetReviewResponseSchema = zod_1.z.object({
    // Current management feedback is separate from the frozen content facts.
    // Optional keeps recorded older projections parseable without fabricating it.
    reviewFeedback: exports.DatasetReviewFeedbackSchema.optional(),
    state: exports.DatasetWorkflowStateSchema, submittedContent: zod_1.z.object({
        id, generation: revision, uploadChoice: zod_1.z.enum(["SAMPLE_ONLY", "FULL_ONLY", "FULL_AND_SAMPLE"]),
        frozenAt: zod_1.z.string().datetime(), common: content_schema_1.DatasetContentCommonSnapshotSchema, metadata: content_schema_1.DatasetContentMetadataSchema,
        pricingReference: exports.DatasetPricingReferenceSchema, pricingAtSubmission: exports.DatasetPricingValuesSchema,
        dependencyFingerprint: zod_1.z.string().regex(/^[a-f0-9]{64}$/), dependenciesChanged: zod_1.z.boolean(),
        selectedFiles: zod_1.z.number().int().min(1).max(1_000),
    }).strict(), assignment: zod_1.z.object({ id, adminId: id, status: zod_1.z.enum(["ACTIVE", "COMPLETED", "REVOKED"]),
        assignedAt: zod_1.z.string().datetime() }).strict().nullable(),
}).strict();
exports.DatasetSubmissionResponseSchema = exports.DatasetReviewResponseSchema.pick({ state: true, submittedContent: true, reviewFeedback: true });
