"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetContentFreeClaimResponseSchema = exports.DatasetContentFreeClaimBodySchema = exports.DatasetAcquisitionOfferResponseSchema = exports.DatasetAcquisitionTargetSchema = exports.DatasetAcquisitionOfferQuerySchema = void 0;
const zod_1 = require("zod");
const id = zod_1.z.string().cuid();
const amount = zod_1.z.string().regex(/^(0|[1-9][0-9]{0,9})\.[0-9]{2}$/);
exports.DatasetAcquisitionOfferQuerySchema = zod_1.z.object({}).strict();
exports.DatasetAcquisitionTargetSchema = zod_1.z.object({ datasetId: id, contentId: id, component: zod_1.z.literal("FULL"),
    publicationId: id, pricingVersionId: id, pricingRevision: zod_1.z.number().int().min(0).max(2_147_483_647),
    amount, currency: zod_1.z.enum(["INR", "USD", "EUR", "GBP"]),
}).strict();
exports.DatasetAcquisitionOfferResponseSchema = zod_1.z.object({ target: exports.DatasetAcquisitionTargetSchema,
    accessFlow: zod_1.z.enum(["FREE_CLAIM", "PAID_CHECKOUT"]), baseAmount: amount,
    discountProposalId: id.nullable(), discountAmount: amount.nullable(),
}).strict();
exports.DatasetContentFreeClaimBodySchema = zod_1.z.object({ expectedTarget: exports.DatasetAcquisitionTargetSchema }).strict();
exports.DatasetContentFreeClaimResponseSchema = zod_1.z.object({ success: zod_1.z.literal(true), grantId: id,
    material: zod_1.z.object({ datasetId: id, contentId: id, component: zod_1.z.literal("FULL") }).strict(),
}).strict();
