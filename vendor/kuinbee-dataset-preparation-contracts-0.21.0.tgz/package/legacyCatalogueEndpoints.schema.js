"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketplaceDatasetSampleDownloadUrlResponseSchema = exports.MarketplaceDatasetGetResponseSchema = exports.MarketplaceDatasetIdParamsSchema = exports.MarketplaceDatasetsListResponseSchema = exports.MarketplaceDatasetsListQuerySchema = exports.MarketplaceDatasetsListSortSchema = void 0;
const zod_1 = require("zod");
const cataloguePrimitives_schema_1 = require("./cataloguePrimitives.schema");
const cataloguePrimitives_schema_2 = require("./cataloguePrimitives.schema");
const legacyCatalogue_schema_1 = require("./legacyCatalogue.schema");
exports.MarketplaceDatasetsListSortSchema = zod_1.z.enum([
    "relevance",
    "createdAt:desc",
    "createdAt:asc",
    "updatedAt:desc",
    "price:asc",
    "price:desc",
    "viewCount:desc",
    "downloadCount:desc",
    "rating:desc",
    "kdtsScore:desc",
]);
const TagsQuerySchema = zod_1.z.preprocess((v) => {
    if (v === undefined || v === null || v === "")
        return undefined;
    return Array.isArray(v) ? v : [v];
}, zod_1.z.array(zod_1.z.string().min(1)).min(1));
const CategoryIdsQuerySchema = zod_1.z.preprocess((v) => {
    if (v === undefined || v === null || v === "")
        return undefined;
    return Array.isArray(v) ? v : [v];
}, zod_1.z.array(cataloguePrimitives_schema_1.CuidSchema).min(1));
const BooleanQuerySchema = zod_1.z.preprocess((v) => {
    if (typeof v === "string") {
        const s = v.trim().toLowerCase();
        if (s === "true")
            return true;
        if (s === "false")
            return false;
    }
    return v;
}, zod_1.z.boolean());
exports.MarketplaceDatasetsListQuerySchema = cataloguePrimitives_schema_1.PaginationQuerySchema.extend({
    q: zod_1.z.string().min(1).max(200).optional(),
    search: zod_1.z.string().min(1).max(200).optional(),
    categoryId: cataloguePrimitives_schema_1.CuidSchema.optional(),
    categoryIds: CategoryIdsQuerySchema.optional(),
    isPaid: BooleanQuerySchema.optional(),
    minPrice: cataloguePrimitives_schema_2.DecimalStringSchema.optional(),
    maxPrice: cataloguePrimitives_schema_2.DecimalStringSchema.optional(),
    currency: cataloguePrimitives_schema_2.CurrencySchema.optional(),
    country: zod_1.z.string().min(1).optional(),
    state: zod_1.z.string().min(1).optional(),
    city: zod_1.z.string().min(1).optional(),
    tags: TagsQuerySchema.optional(),
    minKdtsScore: cataloguePrimitives_schema_2.DecimalStringSchema.optional(),
    sort: exports.MarketplaceDatasetsListSortSchema.optional(),
});
exports.MarketplaceDatasetsListResponseSchema = (0, cataloguePrimitives_schema_1.PaginatedResponseSchema)(legacyCatalogue_schema_1.MarketplaceDatasetListItemDtoSchema);
exports.MarketplaceDatasetIdParamsSchema = zod_1.z.object({
    datasetId: cataloguePrimitives_schema_1.CuidSchema,
});
exports.MarketplaceDatasetGetResponseSchema = legacyCatalogue_schema_1.MarketplaceDatasetDetailsDtoSchema;
exports.MarketplaceDatasetSampleDownloadUrlResponseSchema = zod_1.z.object({
    url: zod_1.z.string().min(1),
    expiresAt: zod_1.z.string().min(1),
    upload: zod_1.z.object({
        id: cataloguePrimitives_schema_1.CuidSchema,
        originalFileName: zod_1.z.string().min(1).nullable(),
        contentType: zod_1.z.string().min(1).nullable(),
        sizeBytes: zod_1.z.string().min(1).nullable(),
    }),
});
