"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetEditContextResponseSchema = exports.DatasetEditContextQuerySchema = exports.DatasetEditOperationSchema = exports.DatasetCorrectionPreconditionSchema = exports.DatasetCorrectionContextSchema = void 0;
const zod_1 = require("zod");
const id = zod_1.z.string().cuid();
const generation = zod_1.z.number().int().min(0).max(2_147_483_647);
exports.DatasetCorrectionContextSchema = zod_1.z.enum([
    "REQUESTED_CHANGES", "MANAGED_EDIT", "APPROVED_REEDIT", "PLATFORM_WITHDRAWAL", "PLATFORM_PUBLISHED_METADATA",
]);
exports.DatasetCorrectionPreconditionSchema = zod_1.z.discriminatedUnion("mode", [
    zod_1.z.object({ mode: zod_1.z.literal("EXISTING_DRAFT"), expectedContentId: id, expectedGeneration: generation }).strict(),
    zod_1.z.object({ mode: zod_1.z.literal("INITIALIZE"), expectedWorkflowRevision: generation,
        context: exports.DatasetCorrectionContextSchema, expectedBaseContentId: id }).strict(),
]);
exports.DatasetEditOperationSchema = zod_1.z.enum(["METADATA", "PRICING", "MATERIALS"]);
exports.DatasetEditContextQuerySchema = zod_1.z.object({ operation: exports.DatasetEditOperationSchema }).strict();
exports.DatasetEditContextResponseSchema = zod_1.z.object({ datasetId: id, operation: exports.DatasetEditOperationSchema,
    preparationGeneration: generation, workflowRevision: generation, managementContext: zod_1.z.enum(["INITIAL_PROPOSAL", "MANAGED"]),
    editable: zod_1.z.boolean(), precondition: exports.DatasetCorrectionPreconditionSchema.nullable(), reason: zod_1.z.string().max(100).nullable(),
}).strict();
