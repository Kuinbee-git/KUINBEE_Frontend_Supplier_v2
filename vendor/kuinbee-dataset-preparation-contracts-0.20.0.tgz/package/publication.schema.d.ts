import { z } from "zod";
export declare const DatasetContentAssessmentTargetSchema: z.ZodEnum<{
    REVIEWED: "REVIEWED";
    PUBLISHED: "PUBLISHED";
}>;
export declare const DatasetContentAssessmentQuerySchema: z.ZodObject<{
    target: z.ZodDefault<z.ZodEnum<{
        REVIEWED: "REVIEWED";
        PUBLISHED: "PUBLISHED";
    }>>;
}, z.core.$strict>;
export declare const DatasetContentAssessmentBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedWorkflowRevision: z.ZodNumber;
    expectedContentId: z.ZodString;
    target: z.ZodDefault<z.ZodEnum<{
        REVIEWED: "REVIEWED";
        PUBLISHED: "PUBLISHED";
    }>>;
    Q: z.ZodNumber;
    L: z.ZodNumber;
    P: z.ZodNumber;
    U: z.ZodNumber;
    F: z.ZodNumber;
    note: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetContentAssessmentSchema: z.ZodObject<{
    id: z.ZodString;
    datasetId: z.ZodString;
    contentId: z.ZodString;
    Q: z.ZodNumber;
    L: z.ZodNumber;
    P: z.ZodNumber;
    U: z.ZodNumber;
    F: z.ZodNumber;
    finalScore: z.ZodString;
    adminId: z.ZodString;
    createdAt: z.ZodString;
    note: z.ZodNullable<z.ZodString>;
    scope: z.ZodObject<{
        uploadedComponents: z.ZodArray<z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>>;
        representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetPublicationSchema: z.ZodObject<{
    id: z.ZodString;
    contentId: z.ZodString;
    publishedAt: z.ZodString;
    pricingReference: z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strict>;
    pricingAtPublication: z.ZodObject<{
        isPaid: z.ZodBoolean;
        price: z.ZodNullable<z.ZodString>;
        currency: z.ZodEnum<{
            INR: "INR";
            USD: "USD";
            EUR: "EUR";
            GBP: "GBP";
        }>;
    }, z.core.$strict>;
    assessmentAtPublicationId: z.ZodString;
    currentAssessmentId: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetPublicationResponseSchema: z.ZodObject<{
    requestId: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>;
    state: z.ZodObject<{
        datasetId: z.ZodString;
        preparationGeneration: z.ZodNumber;
        workflowRevision: z.ZodNumber;
        datasetUniqueId: z.ZodString;
        datasetStatus: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            REJECTED: "REJECTED";
            DELISTED: "DELISTED";
            ARCHIVED: "ARCHIVED";
        }>;
        verificationStatus: z.ZodEnum<{
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            REJECTED: "REJECTED";
            PENDING: "PENDING";
            CHANGES_REQUESTED: "CHANGES_REQUESTED";
            RESUBMITTED: "RESUBMITTED";
        }>;
        activeContentId: z.ZodNullable<z.ZodString>;
        reviewedContentId: z.ZodNullable<z.ZodString>;
        publishedContentId: z.ZodNullable<z.ZodString>;
        pricing: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            status: z.ZodEnum<{
                SUBMITTED: "SUBMITTED";
                UNDER_REVIEW: "UNDER_REVIEW";
                REJECTED: "REJECTED";
                CHANGES_REQUESTED: "CHANGES_REQUESTED";
                RESUBMITTED: "RESUBMITTED";
                DRAFT: "DRAFT";
                ACTIVE: "ACTIVE";
                INACTIVE: "INACTIVE";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    visibility: z.ZodEnum<{
        PUBLIC: "PUBLIC";
        PRIVATE: "PRIVATE";
        UNLISTED: "UNLISTED";
    }>;
    publication: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        contentId: z.ZodString;
        publishedAt: z.ZodString;
        pricingReference: z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
        }, z.core.$strict>;
        pricingAtPublication: z.ZodObject<{
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
        }, z.core.$strict>;
        assessmentAtPublicationId: z.ZodString;
        currentAssessmentId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    reviewedAssessment: z.ZodNullable<z.ZodObject<{
        Q: z.ZodNumber;
        L: z.ZodNumber;
        P: z.ZodNumber;
        U: z.ZodNumber;
        F: z.ZodNumber;
        id: z.ZodString;
        datasetId: z.ZodString;
        contentId: z.ZodString;
        adminId: z.ZodString;
        finalScore: z.ZodString;
        createdAt: z.ZodString;
        scope: z.ZodObject<{
            uploadedComponents: z.ZodArray<z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>>;
            representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    publishedAssessment: z.ZodNullable<z.ZodObject<{
        Q: z.ZodNumber;
        L: z.ZodNumber;
        P: z.ZodNumber;
        U: z.ZodNumber;
        F: z.ZodNumber;
        id: z.ZodString;
        datasetId: z.ZodString;
        contentId: z.ZodString;
        adminId: z.ZodString;
        finalScore: z.ZodString;
        createdAt: z.ZodString;
        scope: z.ZodObject<{
            uploadedComponents: z.ZodArray<z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>>;
            representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    assessmentChange: z.ZodOptional<z.ZodObject<{
        target: z.ZodEnum<{
            REVIEWED: "REVIEWED";
            PUBLISHED: "PUBLISHED";
        }>;
        assessment: z.ZodObject<{
            id: z.ZodString;
            datasetId: z.ZodString;
            contentId: z.ZodString;
            Q: z.ZodNumber;
            L: z.ZodNumber;
            P: z.ZodNumber;
            U: z.ZodNumber;
            F: z.ZodNumber;
            finalScore: z.ZodString;
            adminId: z.ZodString;
            createdAt: z.ZodString;
            note: z.ZodNullable<z.ZodString>;
            scope: z.ZodObject<{
                uploadedComponents: z.ZodArray<z.ZodEnum<{
                    FULL: "FULL";
                    SAMPLE: "SAMPLE";
                }>>;
                representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
            }, z.core.$strict>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetPublicationReadinessResponseSchema: z.ZodObject<{
    requestId: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>;
    state: z.ZodObject<{
        datasetId: z.ZodString;
        preparationGeneration: z.ZodNumber;
        workflowRevision: z.ZodNumber;
        datasetUniqueId: z.ZodString;
        datasetStatus: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            REJECTED: "REJECTED";
            DELISTED: "DELISTED";
            ARCHIVED: "ARCHIVED";
        }>;
        verificationStatus: z.ZodEnum<{
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            REJECTED: "REJECTED";
            PENDING: "PENDING";
            CHANGES_REQUESTED: "CHANGES_REQUESTED";
            RESUBMITTED: "RESUBMITTED";
        }>;
        activeContentId: z.ZodNullable<z.ZodString>;
        reviewedContentId: z.ZodNullable<z.ZodString>;
        publishedContentId: z.ZodNullable<z.ZodString>;
        pricing: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            status: z.ZodEnum<{
                SUBMITTED: "SUBMITTED";
                UNDER_REVIEW: "UNDER_REVIEW";
                REJECTED: "REJECTED";
                CHANGES_REQUESTED: "CHANGES_REQUESTED";
                RESUBMITTED: "RESUBMITTED";
                DRAFT: "DRAFT";
                ACTIVE: "ACTIVE";
                INACTIVE: "INACTIVE";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    visibility: z.ZodEnum<{
        PUBLIC: "PUBLIC";
        PRIVATE: "PRIVATE";
        UNLISTED: "UNLISTED";
    }>;
    publication: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        contentId: z.ZodString;
        publishedAt: z.ZodString;
        pricingReference: z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
        }, z.core.$strict>;
        pricingAtPublication: z.ZodObject<{
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
        }, z.core.$strict>;
        assessmentAtPublicationId: z.ZodString;
        currentAssessmentId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    reviewedAssessment: z.ZodNullable<z.ZodObject<{
        Q: z.ZodNumber;
        L: z.ZodNumber;
        P: z.ZodNumber;
        U: z.ZodNumber;
        F: z.ZodNumber;
        id: z.ZodString;
        datasetId: z.ZodString;
        contentId: z.ZodString;
        adminId: z.ZodString;
        finalScore: z.ZodString;
        createdAt: z.ZodString;
        scope: z.ZodObject<{
            uploadedComponents: z.ZodArray<z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>>;
            representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    publishedAssessment: z.ZodNullable<z.ZodObject<{
        Q: z.ZodNumber;
        L: z.ZodNumber;
        P: z.ZodNumber;
        U: z.ZodNumber;
        F: z.ZodNumber;
        id: z.ZodString;
        datasetId: z.ZodString;
        contentId: z.ZodString;
        adminId: z.ZodString;
        finalScore: z.ZodString;
        createdAt: z.ZodString;
        scope: z.ZodObject<{
            uploadedComponents: z.ZodArray<z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>>;
            representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    assessmentChange: z.ZodOptional<z.ZodObject<{
        target: z.ZodEnum<{
            REVIEWED: "REVIEWED";
            PUBLISHED: "PUBLISHED";
        }>;
        assessment: z.ZodObject<{
            id: z.ZodString;
            datasetId: z.ZodString;
            contentId: z.ZodString;
            Q: z.ZodNumber;
            L: z.ZodNumber;
            P: z.ZodNumber;
            U: z.ZodNumber;
            F: z.ZodNumber;
            finalScore: z.ZodString;
            adminId: z.ZodString;
            createdAt: z.ZodString;
            note: z.ZodNullable<z.ZodString>;
            scope: z.ZodObject<{
                uploadedComponents: z.ZodArray<z.ZodEnum<{
                    FULL: "FULL";
                    SAMPLE: "SAMPLE";
                }>>;
                representedCollection: z.ZodLiteral<"SUPPLIER_DECLARATION">;
            }, z.core.$strict>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    contentId: z.ZodNullable<z.ZodString>;
    contentGeneration: z.ZodNullable<z.ZodNumber>;
    dependencyFingerprint: z.ZodNullable<z.ZodString>;
    canPublish: z.ZodBoolean;
    issues: z.ZodArray<z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetContentPublishBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedWorkflowRevision: z.ZodNumber;
    expectedContentId: z.ZodString;
    expectedContentGeneration: z.ZodNumber;
    expectedPricingReference: z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strict>;
    expectedAssessmentId: z.ZodString;
    expectedDependencyFingerprint: z.ZodString;
}, z.core.$strict>;
export declare const DatasetContentLifecycleBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedWorkflowRevision: z.ZodNumber;
    expectedPublishedContentId: z.ZodNullable<z.ZodString>;
    expectedPublicationId: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetContentVisibilityBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedWorkflowRevision: z.ZodNumber;
    expectedPublishedContentId: z.ZodNullable<z.ZodString>;
    expectedPublicationId: z.ZodNullable<z.ZodString>;
    visibility: z.ZodEnum<{
        PUBLIC: "PUBLIC";
        PRIVATE: "PRIVATE";
        UNLISTED: "UNLISTED";
    }>;
}, z.core.$strict>;
export type DatasetContentAssessmentBody = z.infer<typeof DatasetContentAssessmentBodySchema>;
export type DatasetContentPublishBody = z.infer<typeof DatasetContentPublishBodySchema>;
export type DatasetContentLifecycleBody = z.infer<typeof DatasetContentLifecycleBodySchema>;
export type DatasetContentVisibilityBody = z.infer<typeof DatasetContentVisibilityBodySchema>;
//# sourceMappingURL=publication.schema.d.ts.map