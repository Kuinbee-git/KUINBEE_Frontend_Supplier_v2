import { z } from "zod";
export declare const DatasetWorkflowIdParamsSchema: z.ZodObject<{
    datasetId: z.ZodString;
}, z.core.$strict>;
export declare const DatasetWorkflowCurrencySchema: z.ZodEnum<{
    INR: "INR";
    USD: "USD";
    EUR: "EUR";
    GBP: "GBP";
}>;
export declare const DatasetWorkflowPricingStatusSchema: z.ZodEnum<{
    REJECTED: "REJECTED";
    DRAFT: "DRAFT";
    SUBMITTED: "SUBMITTED";
    CHANGES_REQUESTED: "CHANGES_REQUESTED";
    RESUBMITTED: "RESUBMITTED";
    UNDER_REVIEW: "UNDER_REVIEW";
    ACTIVE: "ACTIVE";
    INACTIVE: "INACTIVE";
}>;
export declare const DatasetPricingReferenceSchema: z.ZodObject<{
    id: z.ZodString;
    revision: z.ZodNumber;
}, z.core.$strict>;
export type DatasetPricingReference = z.infer<typeof DatasetPricingReferenceSchema>;
export declare const DatasetPricingValuesSchema: z.ZodObject<{
    isPaid: z.ZodBoolean;
    price: z.ZodNullable<z.ZodString>;
    currency: z.ZodEnum<{
        INR: "INR";
        USD: "USD";
        EUR: "EUR";
        GBP: "GBP";
    }>;
}, z.core.$strict>;
export declare const DatasetWorkflowPricingSchema: z.ZodObject<{
    id: z.ZodString;
    revision: z.ZodNumber;
    status: z.ZodEnum<{
        REJECTED: "REJECTED";
        DRAFT: "DRAFT";
        SUBMITTED: "SUBMITTED";
        CHANGES_REQUESTED: "CHANGES_REQUESTED";
        RESUBMITTED: "RESUBMITTED";
        UNDER_REVIEW: "UNDER_REVIEW";
        ACTIVE: "ACTIVE";
        INACTIVE: "INACTIVE";
    }>;
    notes: z.ZodNullable<z.ZodString>;
    rejectionReason: z.ZodNullable<z.ZodString>;
    submittedAt: z.ZodNullable<z.ZodString>;
    approvedAt: z.ZodNullable<z.ZodString>;
    updatedAt: z.ZodString;
    isPaid: z.ZodBoolean;
    price: z.ZodNullable<z.ZodString>;
    currency: z.ZodEnum<{
        INR: "INR";
        USD: "USD";
        EUR: "EUR";
        GBP: "GBP";
    }>;
}, z.core.$strict>;
export declare const DatasetWorkflowStateSchema: z.ZodObject<{
    datasetId: z.ZodString;
    datasetUniqueId: z.ZodString;
    datasetStatus: z.ZodEnum<{
        REJECTED: "REJECTED";
        SUBMITTED: "SUBMITTED";
        UNDER_REVIEW: "UNDER_REVIEW";
        VERIFIED: "VERIFIED";
        PUBLISHED: "PUBLISHED";
        DELISTED: "DELISTED";
        ARCHIVED: "ARCHIVED";
    }>;
    verificationStatus: z.ZodEnum<{
        REJECTED: "REJECTED";
        PENDING: "PENDING";
        SUBMITTED: "SUBMITTED";
        CHANGES_REQUESTED: "CHANGES_REQUESTED";
        RESUBMITTED: "RESUBMITTED";
        UNDER_REVIEW: "UNDER_REVIEW";
        VERIFIED: "VERIFIED";
    }>;
    preparationGeneration: z.ZodNumber;
    workflowRevision: z.ZodNumber;
    activeContentId: z.ZodNullable<z.ZodString>;
    reviewedContentId: z.ZodNullable<z.ZodString>;
    publishedContentId: z.ZodNullable<z.ZodString>;
    pricing: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
        status: z.ZodEnum<{
            REJECTED: "REJECTED";
            DRAFT: "DRAFT";
            SUBMITTED: "SUBMITTED";
            CHANGES_REQUESTED: "CHANGES_REQUESTED";
            RESUBMITTED: "RESUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            ACTIVE: "ACTIVE";
            INACTIVE: "INACTIVE";
        }>;
        notes: z.ZodNullable<z.ZodString>;
        rejectionReason: z.ZodNullable<z.ZodString>;
        submittedAt: z.ZodNullable<z.ZodString>;
        approvedAt: z.ZodNullable<z.ZodString>;
        updatedAt: z.ZodString;
        isPaid: z.ZodBoolean;
        price: z.ZodNullable<z.ZodString>;
        currency: z.ZodEnum<{
            INR: "INR";
            USD: "USD";
            EUR: "EUR";
            GBP: "GBP";
        }>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetWorkflowResponseSchema: z.ZodObject<{
    requestId: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>;
    state: z.ZodObject<{
        datasetId: z.ZodString;
        datasetUniqueId: z.ZodString;
        datasetStatus: z.ZodEnum<{
            REJECTED: "REJECTED";
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            PUBLISHED: "PUBLISHED";
            DELISTED: "DELISTED";
            ARCHIVED: "ARCHIVED";
        }>;
        verificationStatus: z.ZodEnum<{
            REJECTED: "REJECTED";
            PENDING: "PENDING";
            SUBMITTED: "SUBMITTED";
            CHANGES_REQUESTED: "CHANGES_REQUESTED";
            RESUBMITTED: "RESUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
        }>;
        preparationGeneration: z.ZodNumber;
        workflowRevision: z.ZodNumber;
        activeContentId: z.ZodNullable<z.ZodString>;
        reviewedContentId: z.ZodNullable<z.ZodString>;
        publishedContentId: z.ZodNullable<z.ZodString>;
        pricing: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
            status: z.ZodEnum<{
                REJECTED: "REJECTED";
                DRAFT: "DRAFT";
                SUBMITTED: "SUBMITTED";
                CHANGES_REQUESTED: "CHANGES_REQUESTED";
                RESUBMITTED: "RESUBMITTED";
                UNDER_REVIEW: "UNDER_REVIEW";
                ACTIVE: "ACTIVE";
                INACTIVE: "INACTIVE";
            }>;
            notes: z.ZodNullable<z.ZodString>;
            rejectionReason: z.ZodNullable<z.ZodString>;
            submittedAt: z.ZodNullable<z.ZodString>;
            approvedAt: z.ZodNullable<z.ZodString>;
            updatedAt: z.ZodString;
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetPricingSaveBodySchema: z.ZodObject<{
    changes: z.ZodObject<{
        isPaid: z.ZodBoolean;
        price: z.ZodNullable<z.ZodString>;
        currency: z.ZodEnum<{
            INR: "INR";
            USD: "USD";
            EUR: "EUR";
            GBP: "GBP";
        }>;
    }, z.core.$strict>;
    editContext: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodLiteral<"EXISTING_DRAFT">;
        expectedContentId: z.ZodString;
        expectedGeneration: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"INITIALIZE">;
        expectedWorkflowRevision: z.ZodNumber;
        context: z.ZodEnum<{
            REQUESTED_CHANGES: "REQUESTED_CHANGES";
            MANAGED_EDIT: "MANAGED_EDIT";
            APPROVED_REEDIT: "APPROVED_REEDIT";
            PLATFORM_WITHDRAWAL: "PLATFORM_WITHDRAWAL";
            PLATFORM_PUBLISHED_METADATA: "PLATFORM_PUBLISHED_METADATA";
        }>;
        expectedBaseContentId: z.ZodString;
    }, z.core.$strict>], "mode">>;
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedPreparationGeneration: z.ZodNumber;
    expectedWorkflowRevision: z.ZodNumber;
    expectedPricingReference: z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetPricingSubmitBodySchema: z.ZodObject<{
    editContext: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodLiteral<"EXISTING_DRAFT">;
        expectedContentId: z.ZodString;
        expectedGeneration: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"INITIALIZE">;
        expectedWorkflowRevision: z.ZodNumber;
        context: z.ZodEnum<{
            REQUESTED_CHANGES: "REQUESTED_CHANGES";
            MANAGED_EDIT: "MANAGED_EDIT";
            APPROVED_REEDIT: "APPROVED_REEDIT";
            PLATFORM_WITHDRAWAL: "PLATFORM_WITHDRAWAL";
            PLATFORM_PUBLISHED_METADATA: "PLATFORM_PUBLISHED_METADATA";
        }>;
        expectedBaseContentId: z.ZodString;
    }, z.core.$strict>], "mode">>;
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedPreparationGeneration: z.ZodNumber;
    expectedWorkflowRevision: z.ZodNumber;
    expectedPricingReference: z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetProposalSubmitBodySchema: z.ZodObject<{
    expectedContentId: z.ZodString;
    expectedContentGeneration: z.ZodNumber;
    expectedDependencyFingerprint: z.ZodString;
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedPreparationGeneration: z.ZodNumber;
    expectedWorkflowRevision: z.ZodNumber;
    expectedPricingReference: z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetProposalReadinessQuerySchema: z.ZodObject<{
    expectedPreparationGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
}, z.core.$strict>;
export declare const DatasetProposalReadinessResponseSchema: z.ZodObject<{
    state: z.ZodObject<{
        datasetId: z.ZodString;
        datasetUniqueId: z.ZodString;
        datasetStatus: z.ZodEnum<{
            REJECTED: "REJECTED";
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            PUBLISHED: "PUBLISHED";
            DELISTED: "DELISTED";
            ARCHIVED: "ARCHIVED";
        }>;
        verificationStatus: z.ZodEnum<{
            REJECTED: "REJECTED";
            PENDING: "PENDING";
            SUBMITTED: "SUBMITTED";
            CHANGES_REQUESTED: "CHANGES_REQUESTED";
            RESUBMITTED: "RESUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
        }>;
        preparationGeneration: z.ZodNumber;
        workflowRevision: z.ZodNumber;
        activeContentId: z.ZodNullable<z.ZodString>;
        reviewedContentId: z.ZodNullable<z.ZodString>;
        publishedContentId: z.ZodNullable<z.ZodString>;
        pricing: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
            status: z.ZodEnum<{
                REJECTED: "REJECTED";
                DRAFT: "DRAFT";
                SUBMITTED: "SUBMITTED";
                CHANGES_REQUESTED: "CHANGES_REQUESTED";
                RESUBMITTED: "RESUBMITTED";
                UNDER_REVIEW: "UNDER_REVIEW";
                ACTIVE: "ACTIVE";
                INACTIVE: "INACTIVE";
            }>;
            notes: z.ZodNullable<z.ZodString>;
            rejectionReason: z.ZodNullable<z.ZodString>;
            submittedAt: z.ZodNullable<z.ZodString>;
            approvedAt: z.ZodNullable<z.ZodString>;
            updatedAt: z.ZodString;
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    contentId: z.ZodNullable<z.ZodString>;
    contentGeneration: z.ZodNullable<z.ZodNumber>;
    dependencyFingerprint: z.ZodNullable<z.ZodString>;
    canSubmit: z.ZodBoolean;
    issues: z.ZodArray<z.ZodObject<{
        code: z.ZodString;
        field: z.ZodOptional<z.ZodString>;
        message: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetReviewPickBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedWorkflowRevision: z.ZodNumber;
    expectedReviewedContentId: z.ZodString;
    expectedPricingReference: z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetReviewApproveBodySchema: z.ZodObject<{
    notes: z.ZodOptional<z.ZodString>;
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedWorkflowRevision: z.ZodNumber;
    expectedReviewedContentId: z.ZodString;
    expectedPricingReference: z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetReviewRejectBodySchema: z.ZodObject<{
    rejectionReason: z.ZodString;
    notes: z.ZodOptional<z.ZodString>;
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedWorkflowRevision: z.ZodNumber;
    expectedReviewedContentId: z.ZodString;
    expectedPricingReference: z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetReviewChangesBodySchema: z.ZodObject<{
    notes: z.ZodString;
    changeRationale: z.ZodOptional<z.ZodString>;
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedWorkflowRevision: z.ZodNumber;
    expectedReviewedContentId: z.ZodString;
    expectedPricingReference: z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetReviewResponseSchema: z.ZodObject<{
    state: z.ZodObject<{
        datasetId: z.ZodString;
        datasetUniqueId: z.ZodString;
        datasetStatus: z.ZodEnum<{
            REJECTED: "REJECTED";
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            PUBLISHED: "PUBLISHED";
            DELISTED: "DELISTED";
            ARCHIVED: "ARCHIVED";
        }>;
        verificationStatus: z.ZodEnum<{
            REJECTED: "REJECTED";
            PENDING: "PENDING";
            SUBMITTED: "SUBMITTED";
            CHANGES_REQUESTED: "CHANGES_REQUESTED";
            RESUBMITTED: "RESUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
        }>;
        preparationGeneration: z.ZodNumber;
        workflowRevision: z.ZodNumber;
        activeContentId: z.ZodNullable<z.ZodString>;
        reviewedContentId: z.ZodNullable<z.ZodString>;
        publishedContentId: z.ZodNullable<z.ZodString>;
        pricing: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
            status: z.ZodEnum<{
                REJECTED: "REJECTED";
                DRAFT: "DRAFT";
                SUBMITTED: "SUBMITTED";
                CHANGES_REQUESTED: "CHANGES_REQUESTED";
                RESUBMITTED: "RESUBMITTED";
                UNDER_REVIEW: "UNDER_REVIEW";
                ACTIVE: "ACTIVE";
                INACTIVE: "INACTIVE";
            }>;
            notes: z.ZodNullable<z.ZodString>;
            rejectionReason: z.ZodNullable<z.ZodString>;
            submittedAt: z.ZodNullable<z.ZodString>;
            approvedAt: z.ZodNullable<z.ZodString>;
            updatedAt: z.ZodString;
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    submittedContent: z.ZodObject<{
        id: z.ZodString;
        generation: z.ZodNumber;
        uploadChoice: z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>;
        frozenAt: z.ZodString;
        common: z.ZodObject<{
            title: z.ZodString;
            overview: z.ZodString;
            description: z.ZodString;
            dataQuality: z.ZodString;
            license: z.ZodString;
            primaryCategoryId: z.ZodString;
            sourceId: z.ZodString;
            superType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                CROSS_SECTIONAL: "CROSS_SECTIONAL";
                TIME_SERIES: "TIME_SERIES";
                PANEL: "PANEL";
                POOLED_CROSS_SECTIONAL: "POOLED_CROSS_SECTIONAL";
                REPEATED_CROSS_SECTIONS: "REPEATED_CROSS_SECTIONS";
                SPATIAL: "SPATIAL";
                SPATIO_TEMPORAL: "SPATIO_TEMPORAL";
                EXPERIMENTAL: "EXPERIMENTAL";
                OBSERVATIONAL: "OBSERVATIONAL";
                BIG_DATA: "BIG_DATA";
                EVENT_HISTORY_SURVIVAL: "EVENT_HISTORY_SURVIVAL";
                HIERARCHICAL_MULTILEVEL: "HIERARCHICAL_MULTILEVEL";
            }>>>;
            useCases: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            limitations: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            methodology: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            secondaryCategoryIds: z.ZodArray<z.ZodString>;
            tags: z.ZodArray<z.ZodString>;
            categories: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>;
            source: z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
                description: z.ZodNullable<z.ZodString>;
                websiteUrl: z.ZodNullable<z.ZodString>;
                isVerifiedAtFreeze: z.ZodBoolean;
            }, z.core.$strict>;
        }, z.core.$strict>;
        metadata: z.ZodObject<{
            collectionBoundary: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            limitations: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            collectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            possibleUses: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            modalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                TABULAR: "TABULAR";
                AUDIO: "AUDIO";
                IMAGE: "IMAGE";
                VIDEO: "VIDEO";
                TEXT: "TEXT";
                SENSOR: "SENSOR";
            }>>>;
            contexts: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                HEALTHCARE: "HEALTHCARE";
                EGOCENTRIC: "EGOCENTRIC";
            }>>>;
            collectionMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>>;
            fullMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>>;
            sampleMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>>;
            sample: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    DESCRIBED: "DESCRIBED";
                    NONE_KNOWN: "NONE_KNOWN";
                }>>>;
                omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    DESCRIBED: "DESCRIBED";
                    NONE_DECLARED: "NONE_DECLARED";
                }>>>;
                transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            fullCompleteness: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            profiles: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                tabular: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                }, z.core.$strict>>>;
                audio: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        SPEECH: "SPEECH";
                        NON_SPEECH: "NON_SPEECH";
                        MIXED: "MIXED";
                    }>>>;
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                images: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                video: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                text: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                sensors: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>>;
                    channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        NO_CLAIM: "NO_CLAIM";
                        DESCRIBED: "DESCRIBED";
                    }>>>;
                    synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                egocentric: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                healthcare: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        pricingReference: z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
        }, z.core.$strict>;
        pricingAtSubmission: z.ZodObject<{
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
        }, z.core.$strict>;
        dependencyFingerprint: z.ZodString;
        dependenciesChanged: z.ZodBoolean;
        selectedFiles: z.ZodNumber;
    }, z.core.$strict>;
    assignment: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        adminId: z.ZodString;
        status: z.ZodEnum<{
            ACTIVE: "ACTIVE";
            COMPLETED: "COMPLETED";
            REVOKED: "REVOKED";
        }>;
        assignedAt: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type DatasetWorkflowResponse = z.infer<typeof DatasetWorkflowResponseSchema>;
export declare const DatasetSubmissionResponseSchema: z.ZodObject<{
    state: z.ZodObject<{
        datasetId: z.ZodString;
        datasetUniqueId: z.ZodString;
        datasetStatus: z.ZodEnum<{
            REJECTED: "REJECTED";
            SUBMITTED: "SUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
            PUBLISHED: "PUBLISHED";
            DELISTED: "DELISTED";
            ARCHIVED: "ARCHIVED";
        }>;
        verificationStatus: z.ZodEnum<{
            REJECTED: "REJECTED";
            PENDING: "PENDING";
            SUBMITTED: "SUBMITTED";
            CHANGES_REQUESTED: "CHANGES_REQUESTED";
            RESUBMITTED: "RESUBMITTED";
            UNDER_REVIEW: "UNDER_REVIEW";
            VERIFIED: "VERIFIED";
        }>;
        preparationGeneration: z.ZodNumber;
        workflowRevision: z.ZodNumber;
        activeContentId: z.ZodNullable<z.ZodString>;
        reviewedContentId: z.ZodNullable<z.ZodString>;
        publishedContentId: z.ZodNullable<z.ZodString>;
        pricing: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
            status: z.ZodEnum<{
                REJECTED: "REJECTED";
                DRAFT: "DRAFT";
                SUBMITTED: "SUBMITTED";
                CHANGES_REQUESTED: "CHANGES_REQUESTED";
                RESUBMITTED: "RESUBMITTED";
                UNDER_REVIEW: "UNDER_REVIEW";
                ACTIVE: "ACTIVE";
                INACTIVE: "INACTIVE";
            }>;
            notes: z.ZodNullable<z.ZodString>;
            rejectionReason: z.ZodNullable<z.ZodString>;
            submittedAt: z.ZodNullable<z.ZodString>;
            approvedAt: z.ZodNullable<z.ZodString>;
            updatedAt: z.ZodString;
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    submittedContent: z.ZodObject<{
        id: z.ZodString;
        generation: z.ZodNumber;
        uploadChoice: z.ZodEnum<{
            SAMPLE_ONLY: "SAMPLE_ONLY";
            FULL_ONLY: "FULL_ONLY";
            FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
        }>;
        frozenAt: z.ZodString;
        common: z.ZodObject<{
            title: z.ZodString;
            overview: z.ZodString;
            description: z.ZodString;
            dataQuality: z.ZodString;
            license: z.ZodString;
            primaryCategoryId: z.ZodString;
            sourceId: z.ZodString;
            superType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                CROSS_SECTIONAL: "CROSS_SECTIONAL";
                TIME_SERIES: "TIME_SERIES";
                PANEL: "PANEL";
                POOLED_CROSS_SECTIONAL: "POOLED_CROSS_SECTIONAL";
                REPEATED_CROSS_SECTIONS: "REPEATED_CROSS_SECTIONS";
                SPATIAL: "SPATIAL";
                SPATIO_TEMPORAL: "SPATIO_TEMPORAL";
                EXPERIMENTAL: "EXPERIMENTAL";
                OBSERVATIONAL: "OBSERVATIONAL";
                BIG_DATA: "BIG_DATA";
                EVENT_HISTORY_SURVIVAL: "EVENT_HISTORY_SURVIVAL";
                HIERARCHICAL_MULTILEVEL: "HIERARCHICAL_MULTILEVEL";
            }>>>;
            useCases: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            limitations: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            methodology: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            secondaryCategoryIds: z.ZodArray<z.ZodString>;
            tags: z.ZodArray<z.ZodString>;
            categories: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>;
            source: z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
                description: z.ZodNullable<z.ZodString>;
                websiteUrl: z.ZodNullable<z.ZodString>;
                isVerifiedAtFreeze: z.ZodBoolean;
            }, z.core.$strict>;
        }, z.core.$strict>;
        metadata: z.ZodObject<{
            collectionBoundary: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            limitations: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            collectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            possibleUses: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            modalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                TABULAR: "TABULAR";
                AUDIO: "AUDIO";
                IMAGE: "IMAGE";
                VIDEO: "VIDEO";
                TEXT: "TEXT";
                SENSOR: "SENSOR";
            }>>>;
            contexts: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                HEALTHCARE: "HEALTHCARE";
                EGOCENTRIC: "EGOCENTRIC";
            }>>>;
            collectionMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>>;
            fullMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>>;
            sampleMeasurements: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                state: z.ZodLiteral<"UNKNOWN">;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                state: z.ZodEnum<{
                    KNOWN: "KNOWN";
                    ESTIMATED: "ESTIMATED";
                }>;
                value: z.ZodString;
                metric: z.ZodEnum<{
                    RECORD_COUNT: "RECORD_COUNT";
                    ROW_COUNT: "ROW_COUNT";
                    COLUMN_COUNT: "COLUMN_COUNT";
                    AUDIO_DURATION: "AUDIO_DURATION";
                    IMAGE_COUNT: "IMAGE_COUNT";
                    VIDEO_DURATION: "VIDEO_DURATION";
                    DOCUMENT_COUNT: "DOCUMENT_COUNT";
                    SESSION_COUNT: "SESSION_COUNT";
                    PARTICIPANT_COUNT: "PARTICIPANT_COUNT";
                    STREAM_COUNT: "STREAM_COUNT";
                    BYTE_SIZE: "BYTE_SIZE";
                }>;
                unit: z.ZodEnum<{
                    COUNT: "COUNT";
                    SECOND: "SECOND";
                    MINUTE: "MINUTE";
                    HOUR: "HOUR";
                    BYTE: "BYTE";
                }>;
            }, z.core.$strict>], "state">>>;
            sample: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                selectionMethod: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                omissions: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    DESCRIBED: "DESCRIBED";
                    NONE_KNOWN: "NONE_KNOWN";
                }>>>;
                omissionNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                transformations: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    UNKNOWN: "UNKNOWN";
                    DESCRIBED: "DESCRIBED";
                    NONE_DECLARED: "NONE_DECLARED";
                }>>>;
                transformationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                relationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            fullCompleteness: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            profiles: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                tabular: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    columnMeaningNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    unitNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    missingValueConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    tableRelationshipNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    dictionaryAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                }, z.core.$strict>>>;
                audio: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    content: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        SPEECH: "SPEECH";
                        NON_SPEECH: "NON_SPEECH";
                        MIXED: "MIXED";
                    }>>>;
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    recordingContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    transcriptAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    transcriptMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    speakerCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    alignmentNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                images: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    subject: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    captureContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    classDefinitions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    coverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                video: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    content: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    viewpoint: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    audioContext: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timingConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                text: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    recordUnit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    languages: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    annotationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    annotationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    recordConvention: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                sensors: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    channels: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        meaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                        unit: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>>;
                    channelNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    sessionRelationships: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timestampMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    timeOrigin: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    synchronization: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        UNKNOWN: "UNKNOWN";
                        NO_CLAIM: "NO_CLAIM";
                        DESCRIBED: "DESCRIBED";
                    }>>>;
                    synchronizationNotes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    calibrationAvailability: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                        PRESENT: "PRESENT";
                        ABSENT: "ABSENT";
                        UNKNOWN: "UNKNOWN";
                    }>>>;
                    calibrationMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    coordinateConventions: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                egocentric: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    mounting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    activities: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    environment: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    additionalStreams: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                healthcare: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    recordMeaning: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    setting: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    identifierHandling: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    participantCoverage: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        pricingReference: z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
        }, z.core.$strict>;
        pricingAtSubmission: z.ZodObject<{
            isPaid: z.ZodBoolean;
            price: z.ZodNullable<z.ZodString>;
            currency: z.ZodEnum<{
                INR: "INR";
                USD: "USD";
                EUR: "EUR";
                GBP: "GBP";
            }>;
        }, z.core.$strict>;
        dependencyFingerprint: z.ZodString;
        dependenciesChanged: z.ZodBoolean;
        selectedFiles: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>;
export type DatasetWorkflowState = z.infer<typeof DatasetWorkflowStateSchema>;
export type DatasetPricingSaveBody = z.infer<typeof DatasetPricingSaveBodySchema>;
export type DatasetPricingSubmitBody = z.infer<typeof DatasetPricingSubmitBodySchema>;
export type DatasetProposalSubmitBody = z.infer<typeof DatasetProposalSubmitBodySchema>;
export type DatasetProposalReadinessQuery = z.infer<typeof DatasetProposalReadinessQuerySchema>;
export type DatasetReviewPickBody = z.infer<typeof DatasetReviewPickBodySchema>;
export type DatasetReviewApproveBody = z.infer<typeof DatasetReviewApproveBodySchema>;
export type DatasetReviewRejectBody = z.infer<typeof DatasetReviewRejectBodySchema>;
export type DatasetReviewChangesBody = z.infer<typeof DatasetReviewChangesBodySchema>;
//# sourceMappingURL=workflow.schema.d.ts.map