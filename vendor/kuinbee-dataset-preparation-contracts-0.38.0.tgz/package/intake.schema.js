"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetUploadPartQuerySchema = exports.DatasetUploadPartParamsSchema = exports.DatasetUploadPartsPageResponseSchema = exports.DatasetUploadPartStatusSchema = exports.DatasetUploadPartsPageQuerySchema = exports.DatasetUploadsPageResponseSchema = exports.DatasetUploadsPageQuerySchema = exports.DatasetMemberInspectionResponseSchema = exports.DatasetUploadInspectionResponseSchema = exports.DatasetInspectionReportPageSchema = exports.DatasetMemberInspectionIdParamsSchema = exports.DatasetMemberInspectionQuerySchema = exports.DatasetUploadInspectionQuerySchema = exports.DatasetInspectionReportPageQuerySchema = exports.DatasetUploadAttemptIdParamsSchema = exports.DatasetIntakeConfigResponseSchema = exports.DatasetIntakeTransportSchema = exports.DatasetIntakeCapabilitySchema = exports.DatasetIntakeProfileSchema = exports.DatasetIntakeConfigQuerySchema = exports.DATASET_UPLOAD_STATUS_PAGE_MAX = exports.DatasetUploadAttemptStatusResponseSchema = exports.DatasetUploadAttemptResponseSchema = exports.DatasetUploadCancelBodySchema = exports.DatasetUploadActionBodySchema = exports.DatasetUploadAdmissionBodySchema = exports.DATASET_UPLOAD_FILE_LIMIT_BYTES = void 0;
const zod_1 = require("zod");
const content_schema_1 = require("./content.schema");
const files_schema_1 = require("./files.schema");
const access_schema_1 = require("./access.schema");
const inspectionProfile_schema_1 = require("./inspectionProfile.schema");
const id = zod_1.z.string().cuid();
const generation = zod_1.z.number().int().min(0).max(2_147_483_647);
const requestId = zod_1.z.string().uuid().transform(value => value.toLowerCase());
// Decimal product ceiling for each new physical file, shared by all roles.
// Keep historical receipt/status sizes readable under their original allowance.
exports.DATASET_UPLOAD_FILE_LIMIT_BYTES = "5000000000";
const bytes = zod_1.z.string().regex(/^[1-9][0-9]{0,9}$/).refine(value => {
    return /^[1-9][0-9]{0,9}$/.test(value) && BigInt(value) <= 5000000000n;
}, "A file must fit the shared Dataset allowance");
const uploadBytes = bytes.refine(value => /^[1-9][0-9]{0,9}$/.test(value) &&
    BigInt(value) <= BigInt(exports.DATASET_UPLOAD_FILE_LIMIT_BYTES), "Each uploaded file must be at most 5 GB (5,000,000,000 bytes)");
const hasControl = (value) => Array.from(value).some(character => {
    const code = character.codePointAt(0);
    return code < 32 || code === 127;
});
const name = zod_1.z.string().min(1).max(1_024).refine(value => !hasControl(value) && !value.includes("/") && !value.includes("\\") &&
    new TextEncoder().encode(value).length <= 1_024 && value !== "." && value !== "..", "Supply a plain original filename");
const context = {
    expectedPreparationGeneration: generation,
    expectedContentId: id,
    expectedContentGeneration: generation,
};
exports.DatasetUploadAdmissionBodySchema = zod_1.z.object({
    requestId, ...context,
    component: content_schema_1.DatasetMaterialComponentSchema,
    role: content_schema_1.DatasetMaterialRoleSchema,
    inspectionProfile: inspectionProfile_schema_1.DatasetInspectionProfileSchema,
    originalName: name,
    claimedMime: zod_1.z.string().max(256).refine(value => !hasControl(value)).nullable().optional(),
    expectedBytes: uploadBytes,
}).strict().refine(value => new TextEncoder().encode(JSON.stringify(value.inspectionProfile)).length <= 4096, "File check declarations exceed 4 KiB; use compact archive type declarations");
exports.DatasetUploadActionBodySchema = zod_1.z.object({ requestId, ...context }).strict();
// Stopping an exact incomplete attempt must remain possible after metadata or
// upload-choice edits. Its authority is independent of current draft sync.
exports.DatasetUploadCancelBodySchema = zod_1.z.object({
    requestId,
    expectedAttemptRevision: generation,
    expectedRecoveryEpoch: generation,
}).strict();
const attemptFields = zod_1.z.object({
    requestId: requestId.optional(), id, rootId: id, contentId: id,
    component: content_schema_1.DatasetMaterialComponentSchema, role: content_schema_1.DatasetMaterialRoleSchema,
    inspectionProfile: inspectionProfile_schema_1.DatasetInspectionProfileSchema.optional(),
    originalName: name,
    expectedBytes: bytes,
    retainedBytes: zod_1.z.string().regex(/^(0|[1-9][0-9]{0,9})$/),
    reservedBytes: zod_1.z.string().regex(/^(0|[1-9][0-9]{0,9})$/),
    partBytes: zod_1.z.number().int().min(1).max(8 * 1_024 * 1_024),
    totalParts: zod_1.z.number().int().min(1).max(10_000),
    state: zod_1.z.enum(["ADMITTED", "RECEIVING", "FINALIZING", "RECEIVED", "CHECKING", "ACCEPTED", "REJECTED", "CANCEL_REQUESTED", "RECONCILIATION_REQUIRED", "CLOSED"]),
    revision: generation,
    // New status responses always supply the epoch. Older immutable receipts
    // replay without adding fields; callers fetch status before a new cancel.
    recoveryEpoch: generation.optional(),
    expiresAt: zod_1.z.string().datetime(),
    // Receipt and recognition are not successful format/malware inspection.
    eligibility: zod_1.z.enum(["NOT_ACCEPTED", "ACCEPTED"]),
}).strict();
const validAttemptBytes = (value) => [value.retainedBytes, value.reservedBytes, value.expectedBytes].every(entry => /^(0|[1-9][0-9]{0,9})$/.test(entry)) &&
    BigInt(value.retainedBytes) + BigInt(value.reservedBytes) <= BigInt(value.expectedBytes);
const attemptBytesMessage = "Part receipts convert reservation without adding unaccounted capacity";
exports.DatasetUploadAttemptResponseSchema = attemptFields.extend({ eligibility: zod_1.z.literal("NOT_ACCEPTED") })
    .refine(validAttemptBytes, attemptBytesMessage);
// Fresh GET status is separate from immutable original control receipts. It
// always includes the attempt's recorded epoch and never adds a request ID.
exports.DatasetUploadAttemptStatusResponseSchema = attemptFields.omit({ requestId: true })
    .extend({ uploadObjectId: id.nullable().optional() })
    .required({ recoveryEpoch: true, inspectionProfile: true })
    .refine(value => value.eligibility === (value.state === "ACCEPTED" ? "ACCEPTED" : "NOT_ACCEPTED"), "Only the backend's accepted inspection state is eligible for selection")
    .refine(value => value.state === "ACCEPTED" ? Boolean(value.uploadObjectId) : !value.uploadObjectId, "Only an accepted status supplies the opaque object identity for file selection")
    .refine(validAttemptBytes, attemptBytesMessage);
const queryInteger = (minimum, maximum) => zod_1.z.union([
    zod_1.z.number().int().min(minimum).max(maximum),
    zod_1.z.string().regex(/^(0|[1-9][0-9]{0,9})$/).transform(Number).pipe(zod_1.z.number().int().min(minimum).max(maximum)),
]);
const queryGeneration = queryInteger(0, 2_147_483_647);
exports.DATASET_UPLOAD_STATUS_PAGE_MAX = 50;
exports.DatasetIntakeConfigQuerySchema = zod_1.z.object({ expectedPreparationGeneration: queryGeneration }).strict();
exports.DatasetIntakeProfileSchema = zod_1.z.enum([
    "UTF8_CSV_SYNTAX_V1", "UTF8_TSV_SYNTAX_V1", "UTF8_JSONL_SYNTAX_V1",
    "RIFF_INTEGER_PCM_WAVE_V1", "PNG_STATIC_8BIT_V1", "ZIP32_CONTAINER_V1",
    "JPEG_BASELINE_STRUCTURE_V1", "MPEG_AUDIO_UPLOAD_V1", "ISO_BMFF_VIDEO_UPLOAD_V1", "UTF8_TEXT_UPLOAD_V1",
]);
const uploadChoiceTuple = zod_1.z.tuple([
    zod_1.z.literal("SAMPLE_ONLY"), zod_1.z.literal("FULL_ONLY"), zod_1.z.literal("FULL_AND_SAMPLE"),
]);
exports.DatasetIntakeCapabilitySchema = zod_1.z.object({
    profileId: exports.DatasetIntakeProfileSchema,
    maximumObjectBytes: uploadBytes,
    choices: uploadChoiceTuple,
    extensions: zod_1.z.array(zod_1.z.string().regex(/^\.[a-z0-9]{1,15}$/)).min(1).max(8),
    mimeTypes: zod_1.z.array(zod_1.z.string().regex(/^[a-z0-9][a-z0-9.+-]*\/[a-z0-9][a-z0-9.+-]*$/)).min(1).max(16),
    archiveContents: zod_1.z.enum(["DECLARED_ENTRIES", "PACKAGED_FILE"]).optional(),
}).strict();
const disabledAdmission = zod_1.z.object({
    enabled: zod_1.z.literal(false),
    reason: zod_1.z.enum([
        "INTAKE_NOT_CONFIGURED", "INTAKE_NOT_QUALIFIED", "CAPACITY_UNAVAILABLE",
        "CAPACITY_RECONCILIATION_REQUIRED", "DRAFT_NOT_READY", "INTAKE_PAUSED",
    ]),
    policyVersion: zod_1.z.string().min(1).max(128).nullable(),
}).strict();
const enabledAdmission = zod_1.z.object({
    enabled: zod_1.z.literal(true), reason: zod_1.z.null(), policyVersion: zod_1.z.string().min(1).max(128),
}).strict();
exports.DatasetIntakeTransportSchema = zod_1.z.object({
    kind: zod_1.z.literal("BOUNDED_PARTS_V1"),
    partBytes: zod_1.z.number().int().min(5 * 1_024 * 1_024).max(8 * 1_024 * 1_024),
    maximumParts: zod_1.z.literal(10_000),
    mediaType: zod_1.z.literal("application/octet-stream"),
    partPathTemplate: zod_1.z.literal("/api/v2/supplier/dataset-drafts/{draftId}/uploads/{attemptId}/parts/{partNumber}"),
}).strict();
exports.DatasetIntakeConfigResponseSchema = zod_1.z.object({
    context: files_schema_1.DatasetFilesContextResponseSchema,
    // The supplier client is deployed before the backend. It must parse the
    // existing 2 GB response until this additive cap and database guard ship.
    maximumFileBytes: zod_1.z.enum(["2000000000", exports.DATASET_UPLOAD_FILE_LIMIT_BYTES]),
    admission: zod_1.z.discriminatedUnion("enabled", [disabledAdmission, enabledAdmission]),
    capabilities: zod_1.z.array(exports.DatasetIntakeCapabilitySchema).max(10),
    transport: exports.DatasetIntakeTransportSchema.nullable(),
}).strict().superRefine((value, issue) => {
    const open = value.admission.enabled;
    if ((open && (!value.capabilities.length || value.transport === null)) ||
        (!open && (value.capabilities.length || value.transport !== null))) {
        issue.addIssue({ code: "custom", message: "Only an enabled qualified release advertises capabilities and transport" });
    }
    if (new Set(value.capabilities.map(capability => capability.profileId)).size !== value.capabilities.length) {
        issue.addIssue({ code: "custom", message: "Intake capability profiles must be unique" });
    }
    if (value.capabilities.some(capability => BigInt(capability.maximumObjectBytes) > BigInt(value.maximumFileBytes))) {
        issue.addIssue({ code: "custom", message: "A format cannot exceed the currently advertised per-file limit" });
    }
});
exports.DatasetUploadAttemptIdParamsSchema = zod_1.z.object({ draftId: id, attemptId: id }).strict();
// Private recorded-format reports are independent of selection/delivery
// eligibility. They contain no malware configuration, raw worker diagnostics or
// preview/download URLs. Continuations pin the exact current evidence.
exports.DatasetInspectionReportPageQuerySchema = zod_1.z.object({ expectedEvidenceId: id.optional(), afterId: id.optional(),
    limit: queryInteger(1, 20).default(5) }).strict().refine(value => !value.afterId || Boolean(value.expectedEvidenceId), "Pin the evidence before continuing");
exports.DatasetUploadInspectionQuerySchema = exports.DatasetInspectionReportPageQuerySchema.safeExtend({
    expectedAttemptRevision: queryGeneration, expectedRecoveryEpoch: queryGeneration
});
exports.DatasetMemberInspectionQuerySchema = exports.DatasetInspectionReportPageQuerySchema.safeExtend({
    contentId: id, contentGeneration: queryGeneration, expectedPreparationGeneration: queryGeneration
});
exports.DatasetMemberInspectionIdParamsSchema = zod_1.z.object({ draftId: id, memberId: id }).strict();
exports.DatasetInspectionReportPageSchema = zod_1.z.object({ uploadObjectId: id.nullable(), evidenceId: id.nullable(),
    state: zod_1.z.enum(["NOT_RECEIVED", "NOT_RECORDED", "CURRENT", "STALE"]),
    inspection: files_schema_1.DatasetFilesInventoryMemberSchema.shape.inspection.nullable(), total: zod_1.z.number().int().min(0).max(16_384),
    items: zod_1.z.array(access_schema_1.DatasetFileObservationSchema).max(20), nextCursor: exports.DatasetInspectionReportPageQuerySchema.nullable(),
}).strict().refine(value => {
    if (value.state === "NOT_RECEIVED")
        return value.uploadObjectId === null && value.inspection === null && value.evidenceId === null && !value.items.length && value.total === 0 && value.nextCursor === null;
    if (!value.uploadObjectId || !value.inspection)
        return false;
    if (value.state !== "CURRENT")
        return !value.inspection.current && value.evidenceId === null && !value.items.length && value.total === 0 && value.nextCursor === null &&
            (value.state === "STALE" ? value.inspection.currentEvidenceId !== null : value.inspection.currentEvidenceId === null);
    return value.inspection.current && value.evidenceId === value.inspection.currentEvidenceId && value.evidenceId !== null &&
        value.total >= value.items.length && new Set(value.items.map(item => item.id)).size === value.items.length &&
        value.items.every(item => item.evidenceId === value.evidenceId && item.source.uploadObjectId === value.uploadObjectId) &&
        (!value.nextCursor || Boolean(value.nextCursor.afterId) && value.items.length > 0 && value.nextCursor.expectedEvidenceId === value.evidenceId && value.nextCursor.afterId === value.items.at(-1)?.id && value.items.length <= value.nextCursor.limit);
}, "Recorded results retain one exact object/evidence; unrecorded or stale checks contain no invented measurements");
exports.DatasetUploadInspectionResponseSchema = zod_1.z.object({ preparationId: id, attemptId: id,
    attemptRevision: generation, recoveryEpoch: generation, component: content_schema_1.DatasetMaterialComponentSchema,
    page: exports.DatasetInspectionReportPageSchema }).strict();
exports.DatasetMemberInspectionResponseSchema = zod_1.z.object({ preparationId: id, memberId: id,
    preparationGeneration: generation, contentId: id, contentGeneration: generation, component: content_schema_1.DatasetMaterialComponentSchema,
    page: exports.DatasetInspectionReportPageSchema }).strict().refine(value => value.page.uploadObjectId !== null, "A selected member retains its exact stored object");
exports.DatasetUploadsPageQuerySchema = zod_1.z.object({
    component: content_schema_1.DatasetMaterialComponentSchema.optional(), afterId: id.optional(),
    limit: queryInteger(1, exports.DATASET_UPLOAD_STATUS_PAGE_MAX).default(20),
}).strict();
exports.DatasetUploadsPageResponseSchema = zod_1.z.object({
    preparationId: id,
    items: zod_1.z.array(exports.DatasetUploadAttemptStatusResponseSchema).max(exports.DATASET_UPLOAD_STATUS_PAGE_MAX),
    nextCursor: zod_1.z.object({ afterId: id }).strict().nullable(),
}).strict().refine(page => page.items.every(attempt => attempt.rootId === page.preparationId) &&
    new Set(page.items.map(attempt => attempt.id)).size === page.items.length &&
    (!page.nextCursor || (page.items.length > 0 && page.nextCursor.afterId === page.items[page.items.length - 1].id)), "Attempt status pages and cursors belong to one owned draft");
exports.DatasetUploadPartsPageQuerySchema = zod_1.z.object({
    expectedAttemptRevision: queryGeneration, expectedRecoveryEpoch: queryGeneration,
    afterPartNumber: queryInteger(0, 10_000).optional(),
    limit: queryInteger(1, exports.DATASET_UPLOAD_STATUS_PAGE_MAX).default(20),
}).strict();
exports.DatasetUploadPartStatusSchema = zod_1.z.object({
    partNumber: zod_1.z.number().int().min(1).max(10_000),
    expectedBytes: zod_1.z.number().int().min(1).max(8 * 1_024 * 1_024),
    measuredBytes: zod_1.z.number().int().min(1).max(8 * 1_024 * 1_024).nullable(),
    state: zod_1.z.enum(["PENDING", "CLAIMED", "RECEIVED", "UNCERTAIN"]),
    receivedAt: zod_1.z.string().datetime().nullable(),
    // Owner-scoped byte identity for safe local-file reselection. This is the
    // backend's committed receipt, never a client claim or inspection verdict.
    checksumSha256: zod_1.z.string().regex(/^[a-f0-9]{64}$/).nullable(),
}).strict().refine(part => part.state === "RECEIVED" ? part.measuredBytes === part.expectedBytes && part.receivedAt !== null :
    part.measuredBytes === null && part.receivedAt === null, "Only an exact committed part receipt reports measured bytes and receipt time")
    .refine(part => part.state === "RECEIVED" ? part.checksumSha256 !== null : part.checksumSha256 === null, "Only an exact committed part receipt supplies its byte digest");
exports.DatasetUploadPartsPageResponseSchema = zod_1.z.object({
    preparationId: id, attemptId: id, attemptRevision: generation, recoveryEpoch: generation,
    totalParts: zod_1.z.number().int().min(1).max(10_000),
    items: zod_1.z.array(exports.DatasetUploadPartStatusSchema).max(exports.DATASET_UPLOAD_STATUS_PAGE_MAX),
    nextCursor: zod_1.z.object({ afterPartNumber: zod_1.z.number().int().min(1).max(10_000) }).strict().nullable(),
}).strict().refine(page => page.items.every((part, index) => part.partNumber <= page.totalParts &&
    (index === 0 || part.partNumber > page.items[index - 1].partNumber)) &&
    (!page.nextCursor || (page.items.length > 0 && page.nextCursor.afterPartNumber === page.items[page.items.length - 1].partNumber)), "Part pages must stay ordered within one exact attempt revision and epoch");
exports.DatasetUploadPartParamsSchema = zod_1.z.object({
    draftId: id, attemptId: id, partNumber: queryInteger(1, 10_000),
}).strict();
// Raw bytes do not pass through JSON parsing. Their bounded claim context is
// carried in a strict query, with no provider or inspection facts accepted.
exports.DatasetUploadPartQuerySchema = zod_1.z.object({
    requestId, expectedPreparationGeneration: queryGeneration,
    expectedContentId: id, expectedContentGeneration: queryGeneration,
}).strict();
